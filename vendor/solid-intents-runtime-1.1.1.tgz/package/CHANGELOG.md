# Changelog

## 1.1.1

HTTP scheduling now adapts automatically to Pod overload. Each exact origin starts at its configured interval and concurrency. A 429 episode doubles the effective interval to between 1 and 30 seconds, halves concurrency to at least one, and pauses queued dispatch. An explicitly slower baseline remains respected. Concurrent 429s extend cooldown without applying repeated reductions. After cooldown, each 20 non-429 responses recover one concurrency slot and reduce the interval to 75%, without exceeding configured capacity. Requests already in flight finish normally; queued requests remain spaced as dispatch resumes.

Valid delta-seconds and HTTP-date `Retry-After` instructions are honored without the former 60-second cap. Exponential fallback delays add 0–25% positive jitter and remain capped at 60 seconds. Retry limits and the existing 429-only retry policy are unchanged. A final 429 still protects later requests through the origin cooldown. Adaptive state is transient.

`diagnostics.status().requestScheduling` exposes origin-only scheduling snapshots. `diagnostics.subscribeRateLimits()` emits one structured event per overload episode. Built-in OIDC transport, supplied authenticated fetches, discovery, storage, sharing, and writes use the runtime scheduler.

`share.resolvePermissions()` reports final rate limiting as `unknown` with reason `rate-limited` and an optional `retryAt`. It does not infer denied access or accept a fallback grant after a rate-limited ACL read. The compatibility `share.permissions()` wrapper still returns an empty array for unknown access.

No adaptive scheduling configuration or persisted-data migration is required. Catalog schema v2 and v1 migration, transactional catalog deltas, discovery reconciliation/settling/cancellation, native Vtodo-to-Task mapping, fallback ACL provenance, and write-plan version 2 remain in place.

Known packaging limitation: standalone npm consumers on Node 22 must apply the workspace's existing `@digitalbazaar/http-client: 4.3.0` override to avoid the legacy JSON-LD dependency's obsolete `esm` loader. See the README. The overload policy itself requires no configuration.
