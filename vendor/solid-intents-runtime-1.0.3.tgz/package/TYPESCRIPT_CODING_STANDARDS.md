# TypeScript Coding Standards

This document is the writing standard for ongoing implementation work in this repository, with primary focus on `@solid-intents/runtime`.

## Language & Configuration

- TypeScript, `"strict": true`, targeting ES2022, ESM modules
- All local imports use explicit `.js` extensions: `import { X } from "./file.js"`
- `import type` for type-only imports, separate from value imports
- Import order: node built-ins -> external packages -> local files, blank line between groups

---

## File & Directory Layout

- Files: `snake_case` — `user_service.ts`, `process_cleanup.ts`
- Test files colocated with source, suffixed `.spec.ts` — never a separate `test/` directory
- Directories group by concern, not by type — no `models/`, `controllers/` dumping grounds
- Barrel files (`index.ts`) use explicit named re-exports only — never `export * from`

---

## Naming

| Thing | Convention | Example |
|---|---|---|
| Classes | PascalCase | `UserService`, `RequestHandler` |
| Interfaces | PascalCase, no `I` prefix by default | `UserRepository`, `RequestHandlerContract` |
| Files | snake_case | `user_service.ts` |
| Variables / params | camelCase | `userId`, `requestPayload` |
| Methods | camelCase, long and descriptive | `fetchUserById`, `formatResponsePayload` |
| Getters | `get` prefix | `get config()`, `get isConnected()` |

Method names read like sentences. Never abbreviate. Optimize for the reader, not the typist.
Use an `I` prefix only for explicit injected testing seams where that naming materially improves readability in that module.

---

## Class Design

Constructor injection is the default. Every stateful class receives dependencies through the constructor, typed against contracts.

```typescript
export class UserService {
  private userRepository: UserRepository;
  private emailSender: EmailSender;

  constructor(userRepository: UserRepository, emailSender: EmailSender) {
    this.userRepository = userRepository;
    this.emailSender = emailSender;
  }
}
```

Do not define an interface for every class by default. Define a contract when there is a real seam (for example: injected dependency used in tests, or multiple implementations).
Reuse existing shared contracts (for example `Logger`) rather than redefining equivalent local interfaces.
When a module grows, split it into a concern folder with one major class per file, a `types.ts` file for shared contracts, and a helper/util file only for logic shared across classes.

Abstract base classes for shared behavior across a family of concrete implementations. No more than one level of inheritance beyond the base.

Fields are `private` by default. Expose state only through methods or getters. Never return mutable internal references.

---

## What Goes in a Class

A class has one reason to exist and one reason to change. Before adding a method, ask: is this genuinely this class's responsibility, or am I just putting it here because it's convenient?

A class should:
- Manage one piece of state or coordinate one workflow
- Have a name that fully describes its purpose without the word "and"
- Depend on abstractions (interfaces), not on other concrete classes directly

A method belongs in a class when it directly operates on that class's own state or dependencies. Prefer private methods over file-level helper functions for class-specific behavior. Extract to a helper/util file only when the same logic is used by multiple classes.

Keep classes small enough that you can hold the whole thing in your head. If you find yourself scrolling to remember what fields exist, the class is doing too much.

When to create a new class:
- A distinct piece of state needs to be encapsulated and managed over time
- A responsibility is growing large enough that it obscures the host class's primary purpose
- You need a seam for testing — a new class with an interface lets you inject a mock
- A concept in the domain deserves a name of its own

When not to create a new class:
- You're grouping functions that share no state — use a module instead
- You're wrapping a single method call — just call it directly
- You're creating it "for future flexibility" — wait until the need is real

---

## Simplicity

The simplest implementation that correctly solves the problem is the right one. Complexity is only justified when the domain itself demands it — never imposed in anticipation of requirements that don't exist yet.

Write for the problem in front of you. Don't design for hypothetical callers, future requirements, or edge cases that haven't been asked for. If a function takes two arguments today, it takes two arguments — not an options object in case more are needed later.

Three similar lines is not a problem. Extract shared logic only when a genuine third usage appears with the same shape. Premature extraction creates indirection without payoff.

If the solution feels complicated, that's a signal. Step back and ask whether the approach is wrong, not whether the complication can be hidden better.

Depth of abstraction should match depth of the problem. Layers of abstraction are earned by genuine complexity, not added by default.

```typescript
// Wrong — wrapping for no reason
private buildUserId(id: string): string {
  return id;
}

// Right — just use the value directly
const user = await this.repository.findById(id);
```

---

## Types

- Strict mode always
- Use `interface` for contracts and object shapes; `type` for unions and aliases
- Do not create one-off parameter interfaces for single methods unless the fields form a cohesive domain concept or the same shape is reused in multiple places
- Prefer direct named parameters for simple method inputs (especially 1-3 values) instead of wrapping them in `{ input: ... }` objects
- Union types for constrained string domains:

```typescript
export type Status = "pending" | "active" | "archived";
```

- Annotate return types explicitly on all public methods
- Generics only when genuinely needed — not speculatively

On `any`: avoid it. Prefer `unknown` and narrow with a type guard. At external API or library boundaries where types are unavailable, use `Record<string, unknown>` for objects. If `any` is truly unavoidable, add a one-line comment explaining why. Never use primitive wrapper types (`Number`, `String`, `Boolean`).

---

## Error Handling

Throw exceptions for failures — don't swallow errors or return status objects.

Enrich errors with context before re-throwing:

```typescript
catch (error: unknown) {
  if (error instanceof Error) {
    error.message = `Failed to load config from '${path}': ${error.message}`;
  }
  throw error;
}
```

Use `finally` for teardown — connections, locks, temp state:

```typescript
try {
  return await this.execute(args);
} finally {
  this.connection.release();
}
```

Process-level unhandled exception handlers belong at the entry point only — never inside library or service code.

---

## Async

- Every async function is declared `async`
- Always `await` before returning a Promise — never `return promise` from an `async` function
- No `.then()` chains — always `async/await`

---

## Comments

Write no comments by default. A comment earns its place only when the why would surprise a competent TypeScript reader.

Write a comment when:
- There is a hidden constraint or external assumption the code can't express
- You're working around a specific bug or library quirk
- The behaviour would be unintuitive without the explanation

Never write a comment that:
- Restates what the code says
- Describes what a method does (the name should do that)
- References the current task, fix, or caller

On interfaces — add a single-line JSDoc to every exported interface method. One line, states the contract not the implementation:

```typescript
export interface UserRepository {
  /** Returns the user matching the given ID, or null if not found. */
  findById(id: string): Promise<User | null>;
  /** Persists a new user and returns the saved record. */
  create(data: CreateUserInput): Promise<User>;
}
```

---

## Testing

Structure tests to mirror class -> method — outer describe names the class, inner describes name the method, `it` describes the scenario.

Mocks implement interfaces as classes. No magic, no monkey-patching — if you need a test double, write a class that implements the interface:

```typescript
class MockUserRepository implements UserRepository {
  async findById(_id: string): Promise<User | null> { return null; }
  async create(data: CreateUserInput): Promise<User> { return { id: "1", ...data }; }
}
```

Shared test utilities go in `test_helpers/`. Nothing else lives there.

---

## What Never to Do

- `export * from` — always name what you export
- Mock libraries — implement the interface
- `.then()` chains
- Comments that describe what the code does
- Validation inside private methods — trust your own types
- Duplicating shared contracts (for example creating a local logger interface when a shared `Logger` already exists)
- Premature abstraction — extract only when a third instance appears with the same shape
- Multi-paragraph docstrings — one line or nothing
- `any` without a comment explaining why it's unavoidable
- Classes that exist for future flexibility — build for now
