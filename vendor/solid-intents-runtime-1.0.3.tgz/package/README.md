# Solid Intents Runtime

Semantic runtime API for building Solid applications over RDF data, ordinary files, and Solid type indexes.

## Import

```ts
import {
  SolidGraphRuntime,
  hasLink,
  hasProperty,
  profiles,
  queries,
  runtime,
  vocab,
  views,
} from "@solid-intents/runtime";
import type { SolidRuntime, Thing } from "@solid-intents/runtime";
```

The package export map exposes one public entrypoint. Applications should not import runtime internals directly.

## Public Entry Point

The package value exports are:

- `SolidGraphRuntime`
- `runtime`
- `queries`
- `profiles`
- `views`
- `vocab`
- `findVocabularyTerm`
- `listVocabularyTerms`
- `hasProperty`
- `hasLink`
- `RuntimeError`
- `ThingNotFoundError`
- `GraphLinkWriteError`

## Runtime Areas

- `runtime.boot(options)` composes runtime services for one pod/session.
- `runtime.auth` handles login, redirect completion, logout, session state, and authenticated fetch.
- `runtime.types` registers app-owned runtime types and RDF class mappings.
- `runtime.layouts` defines app-owned containers and type profiles.
- `runtime.writes` plans reviewable writes and commits approved plans.
- `runtime.things` creates, reads, queries, updates, deletes, subscribes to, and reads content for meaningful Things.
- `runtime.resources` reads raw pod resource metadata and bodies when an app intentionally wants storage-level access.
- `runtime.graph` writes RDF predicate links and reads directly related Things.
- `runtime.context` returns bounded context around one Thing, grouped by RDF predicate.
- `runtime.discovery` indexes configured containers, graph entrypoints, storage roots, and type-index registrations.
- `runtime.storage` lists pod roots and containers.
- `runtime.share` applies read/write access intent.
- `runtime.validation` validates readable resources or runtime-managed Thing RDF.
- `runtime.diagnostics` explains runtime health, indexed knowledge, type-index state, Thing/content/source identity, and query decisions.

Most applications should start with `things`, `context`, and `discovery`. Use `resources` only when you deliberately want raw Solid storage access outside the Thing model.

## Boot And Auth

Browser applications can use `runtime.auth.login()`, `runtime.auth.handleRedirect()`, and `runtime.auth.restoreSession()` to manage a Solid OIDC session backed by browser storage.

Headless Node applications should provide their own authenticated fetch and boot the runtime with the resolved pod URL:

```ts
await runtime.boot({
  podUrl,
  fetch: authenticatedFetch,
});
```

`runtime.boot({ restoreSession: true })` restores a browser session when one is available. It is not a server-side credential store or headless login flow.

Use `runtime.auth.capabilities()` or `runtime.diagnostics.status().authCapabilities` to report the active auth environment:

```ts
const capabilities = runtime.auth.capabilities();

if (!capabilities.browserSessionRestore && !capabilities.suppliedFetch) {
  showSetupHint(capabilities.message);
}
```

## Things, Content, Source, Facts, And Facets

A `Thing` is the runtime snapshot for one meaningful item. That item can be an RDF subject, an image, a markdown file, a PDF, a text file, or another file-backed resource.

The runtime separates three ideas:

- `thing.uri` is the stable Thing identity.
- `thing.content` is the readable body when the Thing has bytes: image, markdown, HTML, JSON, PDF, audio, video, and so on.
- `thing.source` is the resource that described or discovered the Thing: an RDF document, a file resource, inferred storage metadata, or runtime-managed RDF.

```ts
const thing = await runtime.things.get(uri);

if (thing) {
  renderTitle(thing.facets.title);

  const body = await runtime.things.content(thing, { as: "blob" });
  renderBody(body);

  renderNames(thing.property(vocab.schema.name.uri));
  renderLinks(thing.objects(vocab.schema.about.uri));
}
```

Snapshots expose:

- `uri` for the Thing URI.
- `content` for the body resource, content kind, media type, filename, and whether it was file-backed or RDF-described.
- `source` for the description/discovery resource and metadata quality.
- `types` for RDF classes and runtime type hints.
- `facets` for ergonomic fields such as `title`, `description`, `kind`, `status`, image, URL, and timestamps.
- `properties` for literal and structured RDF values keyed by predicate URI.
- `links` for URI-valued RDF facts keyed by predicate URI.
- `known` for vocabulary-grouped fact buckets.
- `freshness.source`, currently `"catalog"` or `"pod"`, showing where the snapshot came from.

`things.get(uri)` is catalog-first. It accepts a Thing URI or a known content/file URI and returns the same Thing snapshot. It falls back to direct runtime-managed reads only for Things created by this runtime before they have been cataloged.

## Content

Use `things.content()` to read the body for any Thing or known Thing/content URI.

```ts
const markdown = await runtime.things.content(readmeThing, { as: "text" });
const image = await runtime.things.content(photo, { as: "blob" });
const pdf = await runtime.things.content(documentThing, { as: "arrayBuffer" });
const preview = await runtime.things.previewContentUrl(photo);
```

Use `thing.content.kind` and `thing.content.mediaType` to choose presentation. The lookup stays the same for RDF subjects, RDF-described files, and ordinary file-backed Things: pass the Thing to `things.content()`.

Do not use `runtime.resources` to render a Thing. `resources` is the low-level escape hatch for raw pod URIs, HTTP metadata, storage diagnostics, or tools that intentionally operate below the semantic Thing model.

`things.content()` returns one of four body shapes:

- `{ as: "text", text, metadata }`
- `{ as: "blob", blob, metadata }`
- `{ as: "arrayBuffer", arrayBuffer, metadata }`
- `{ as: "json", json, metadata }`

Creating a content-backed Thing writes the bytes and an RDF description that points to them with ordinary RDF facts.

```ts
const readme = await runtime.things.create({
  title: "Project Readme",
  type: "MarkdownDocument",
  content: {
    filename: "README.md",
    mediaType: "text/markdown",
    body: "# Project\n\nEverything is a Thing.",
  },
});
```

Use `target.containerUri` when an app owns a deterministic container layout:

```ts
const readme = await runtime.things.create({
  title: "Project Readme",
  type: "MarkdownDocument",
  target: {
    containerUri: `${podUrl}workspace/docs/`,
  },
  content: {
    filename: "README.md",
    mediaType: "text/markdown",
    body: "# Project\n\nEverything is a Thing.",
  },
});
```

Relative target containers resolve from the runtime pod URL, and missing trailing slashes are normalized.

Updating content writes the content resource, not the RDF metadata resource.

```ts
await runtime.things.update(readme.uri, {
  content: {
    body: "# Project\n\nUpdated notes.",
  },
});
```

Deleting a file-backed/content-backed Thing deletes its content resource. RDF metadata is not treated as writable content unless it actually is the content.

## Discovery And Queries

Discovery indexes externally created RDF subjects, file resources, and runtime-managed Things into the catalog. RDF subjects do not need `rdf:type` to be meaningful: labels, titles, descriptions, links, dates, and other non-structural facts are enough evidence for indexing.

```ts
await runtime.boot({ podUrl });

await runtime.discovery.start({
  entrypoints: [`${podUrl}workspace/things/`],
  mode: "balanced",
});

const photos = await runtime.things.query(
  queries.photos(),
  { scope: { kind: "container", uri: `${podUrl}workspace/photos/` } },
);

for (const photo of photos.things) {
  const preview = await runtime.things.previewContentUrl(photo);
  renderImage(preview.url);
}

for (const diagnostic of photos.metadata.diagnostics) {
  console.info(diagnostic.code, diagnostic.message);
}
```

Queries are catalog-first. Metadata reports completeness, freshness, stale counts, refresh state, and diagnostics such as `scope-unscanned`, `type-index-results`, and `fallback-discovery-results`.

Use query presets for common content categories:

```ts
await runtime.things.query(queries.images());
await runtime.things.query(queries.documents());
await runtime.things.query(queries.markdown());
```

Use `hasProperty` and `hasLink` when a query needs explicit RDF predicates:

```ts
const result = await runtime.things.query({
  where: [
    hasProperty(vocab.schema.name.uri, "Project Apollo"),
    hasLink(vocab.schema.about.uri, topicUri),
  ],
});
```

`relatedTo` is the predicate-agnostic shortcut for "anything linked to this target URI." Use `hasLink(predicateUri, targetUri)` when the predicate matters:

```ts
const broad = await runtime.things.query({
  relatedTo: topicUri,
});

const aboutTopic = await runtime.things.query({
  where: [
    hasLink(vocab.schema.about.uri, topicUri),
  ],
});
```

## Type Indexes

Runtime-managed writes try to register created and updated Things in the user's private Solid type index. Type-index write failures are observable and non-fatal by default.

```ts
const photo = await runtime.things.create({
  title: "Beach Sunset",
  type: "Photo",
  status: "active",
});

const write = runtime.diagnostics.status().typeIndexWrites.latest;
console.info(write?.status, write?.message);
```

`discoverType(runtimeType)` uses type-index registrations first. If the type index has no matching instance or container registrations, discovery performs bounded fallback traversal/storage discovery. Query diagnostics report which path produced results.

```ts
await runtime.discovery.discoverType("Photo");

const result = await runtime.things.query({ type: "Photo" }, { autoDiscover: false });
const codes = result.metadata.diagnostics.map((diagnostic) => diagnostic.code);
```

Promoted native types use stable RDF classes in type indexes where natural: for example `Photo` uses `schema:ImageObject`, `Event` uses `schema:Event`, `Note` uses ActivityStreams `Note`, `Task` uses iCalendar `Vtodo`, and `Person` accepts schema.org, FOAF, and vCard classes. Runtime-owned app concepts such as `Area`, `Bookmark`, `Conversation`, `HealthLog`, and `Meal` use runtime-owned classes.

Register an app-owned type before creating Things when the app owns the RDF class:

```ts
runtime.types.register({
  type: "AgentSession",
  classUri: "https://cairn.dev/ns#AgentSession",
});
```

Created `AgentSession` Things will then use that class URI in type-index registrations instead of a runtime-owned fallback class.

`runtime.diagnostics.typeIndexes(runtimeType)` returns read-only type-index registrations and failures for inspection.

## App-Owned Layouts

Use a layout descriptor when an app owns multiple containers and type profiles. Define layouts after boot so relative container paths resolve from the active pod URL.

```ts
const cairnLayout = runtime.layouts.define({
  namespace: "https://cairn.dev/ns#",
  containers: {
    sessions: "cairn/sessions/",
    memories: "cairn/memories/",
  },
  types: {
    AgentSession: {
      container: "sessions",
      defaultStatus: "active",
    },
    AgentMemory: {
      container: "memories",
    },
  },
});

const session = await runtime.things.create({
  profile: cairnLayout.types.AgentSession,
  facets: {
    title: "Planning session",
  },
});
```

When a layout has a namespace, type entries without an explicit `classUri` register `${namespace}${type}` for type-index writes. Use `classUri` when an app type has a different RDF class URI.

For apps with their own durable ids, define the container and RDF vocabulary in the runtime, then pass `target.resourceName` to place the RDF metadata resource at a stable pod URL. Also store the app id as an explicit RDF fact so discovery and queries do not depend on URL parsing.

```ts
const sp = {
  id: "https://super-productivity.com/ns#id",
  isDone: "https://super-productivity.com/ns#isDone",
};

const superProductivityLayout = runtime.layouts.define({
  namespace: "https://super-productivity.com/ns#",
  containers: {
    tasks: "super-productivity/tasks/",
  },
  types: {
    Task: {
      container: "tasks",
      defaultStatus: "active",
    },
  },
});

await runtime.things.create({
  profile: superProductivityLayout.types.Task,
  target: {
    containerUri: superProductivityLayout.containers.tasks,
    resourceName: task.id,
  },
  facets: {
    title: task.title,
  },
  properties: {
    [sp.id]: [task.id],
    [sp.isDone]: [task.isDone],
  },
});

const existing = await runtime.things.query({
  type: "Task",
  where: [
    hasProperty(sp.id, task.id),
  ],
});
```

With `task.id === "task-1"`, this creates the Thing at `${podUrl}super-productivity/tasks/task-1.ttl#it`. Resource names are sanitized as file names and receive a `.ttl` suffix when needed. Creates fail with `RuntimeError` code `resource-already-exists` if the target RDF resource is already present.

This keeps storage, auth, RDF parsing, discovery, and type-index behavior in the runtime. Application code owns only its vocabulary and projection layer.

## Profiles, Facets, And Views

Write profiles provide named creation defaults without changing the RDF fact model. Facets are ergonomic inputs for common predicates; `properties` and `links` accept explicit predicate URIs.

```ts
const task = await runtime.things.create({
  profile: profiles.Task,
  facets: {
    title: "Prepare release notes",
    status: "active",
  },
  links: {
    [vocab.schema.about.uri]: [project.uri],
  },
});
```

Native profiles and views cover the common app layer:

- Workspace: `Note`, `Task`, `Project`, `Goal`, `Area`
- Knowledge and learning: `Concept`, `Topic`, `Skill`, `Course`, `Book`, `Article`
- People and places: `Person`, `Organization`, `Place`, `Event`
- Media and documents: `Photo`, `Document`, `WebPage`, `Bookmark`
- Conversation: `Conversation`, `Message`
- Material records: `Product`, `Invoice`
- Lightweight life records: `PhysicalActivity`, `HealthLog`, `Meal`

Apps can store their own vocabulary without waiting for a native runtime profile. Use a stable app-owned type string, explicit RDF properties, explicit RDF links, and an app-owned read view in application code:

```ts
runtime.types.register({
  type: "AgentSession",
  classUri: "https://cairn.dev/ns#AgentSession",
});

const session = await runtime.things.create({
  type: "AgentSession",
  target: {
    containerUri: `${podUrl}cairn/sessions/`,
  },
  facets: {
    title: "Planning session",
    status: "active",
  },
  properties: {
    ["https://cairn.dev/ns#startedAt"]: [new Date()],
  },
  links: {
    ["https://cairn.dev/ns#workspace"]: [workspaceUri],
  },
});
```

Unknown type strings are application vocabulary from the runtime API perspective. Native runtime profiles are for concepts that are broadly useful across Solid applications.

URLs are RDF facts, not scalar runtime fields. Use `vocab.schema.url.uri` through `properties`:

```ts
const bookmark = await runtime.things.create({
  profile: profiles.Bookmark,
  facets: {
    title: "Runtime API",
    description: "Saved reference page",
  },
  properties: {
    [vocab.schema.url.uri]: ["https://example.com/runtime-api"],
  },
  links: {
    [vocab.schema.about.uri]: [topic.uri],
  },
});
```

On updates, `properties` and `links` add facts. Use the explicit replace/delete inputs when a predicate should behave like a current scalar or set value.

```ts
await runtime.things.update(task.uri, {
  replaceProperties: {
    ["https://super-productivity.com/ns#isDone"]: [task.isDone],
    ["https://super-productivity.com/ns#timeEstimate"]: [task.timeEstimate],
  },
  replaceLinks: {
    ["https://super-productivity.com/ns#tag"]: task.tagUris,
  },
  deleteProperties: {
    ["https://super-productivity.com/ns#plannedAt"]: [],
  },
});
```

An empty array in `deleteProperties` or `deleteLinks` deletes all values for that predicate. A non-empty array deletes only those exact values.

Read views project a `Thing` snapshot into a typed shape for application code.

```ts
const taskView = task.as(views.Task);
const bookmarkView = bookmark.as(views.Bookmark);
const documentView = readme.as(views.Document);
```

## Graph Writes

`graph.link` and `graph.unlink` write RDF predicates directly. Known ergonomic aliases resolve through the vocabulary/policy registry, and absolute URI strings are accepted as arbitrary predicates.
Aliases are convenience labels only; write results and stored facts are expressed as RDF predicate URIs.

```ts
const write = await runtime.graph.link(
  project.uri,
  task.uri,
  "contains",
);

console.info(write.predicateUri, write.inversePredicateUri);
console.info(write.sourceChanged, write.targetChanged);
```

Use absolute predicate URIs for app-owned links:

```ts
await runtime.graph.link(
  session.uri,
  workspaceUri,
  "https://cairn.dev/ns#workspace",
);
```

The native alias set includes common app workflow links such as `contains`, `references`, `dependsOn`, `belongsToArea`, `tracksGoal`, `documentsProject`, `aboutTopic`, `taggedWith`, `authorship`, `membership`, `located`, `attends`, `knows`, `enrolledIn`, `completedCourse`, `requiresSkill`, `teaches`, `learnedFrom`, `owns`, `purchasedProduct`, `boughtFrom`, `billingFor`, `paidBy`, `repliedTo`, `attachedTo`, `savedFrom`, `associatedMood`, and `improves`.

The result shape is predicate-based:

- `predicateUri` is the RDF predicate written on the source.
- `inversePredicateUri` is present when an inverse predicate was written on the target.
- `sourceChanged` and `targetChanged` report which resources changed.
- `repairedExistingDrift` reports whether the write repaired previously inconsistent RDF.

No public graph write API exposes storage-specific field names.

## Write Plans

Use `runtime.writes` when a user or agent needs to review mutations before they happen. Planning does not mutate the pod.

```ts
const plan = runtime.writes.planCreate({
  profile: cairnLayout.types.AgentSession,
  facets: {
    title: "Planning session",
  },
});

renderReview({
  operations: plan.operations,
  affectedResources: plan.affectedResources,
  diagnostics: plan.diagnostics,
});

const commit = await runtime.writes.commit(plan);
```

Graph links can be planned through the same surface:

```ts
const plan = runtime.writes.planGraphLink(
  project.uri,
  task.uri,
  "contains",
);
```

Thing updates can also be planned, including RDF replacement and delete operations:

```ts
const plan = runtime.writes.planUpdate(task.uri, {
  replaceProperties: {
    ["https://super-productivity.com/ns#isDone"]: [task.isDone],
  },
  deleteLinks: {
    ["https://super-productivity.com/ns#dependency"]: [],
  },
});
```

Commits reuse `things.create()`, `things.update()`, and `graph.link()` so planned writes and direct writes share the same runtime semantics.

Write failures throw `RuntimeError` or a more specific subclass with stable `code` and optional `details` fields. Write-related codes include `content-write-failed`, `rdf-patch-failed`, `graph-link-write-failed`, `unknown-predicate`, `validation-failed`, `invalid-thing-input`, `resource-already-exists`, `content-update-unavailable`, and `resource-delete-failed`.

## Context

`context.get(uri)` returns the root Thing, connected Things grouped by predicate URI, missing references, and omitted references. Catalog link hints live under diagnostics.

```ts
const context = await runtime.context.get(project.uri, { maxNeighbors: 20 });

for (const task of context.connected[vocab.schema.hasPart.uri] ?? []) {
  renderTask(task);
}

for (const hint of context.diagnostics.sources.linkHints) {
  console.info(hint.predicateUri, hint.targetUri, hint.recordStatus);
}
```

Context is built from `Thing.links` and URI-valued facts. Structural RDF predicates are filtered out of ergonomic link groups.

## Validation

Readable validation is the default. It verifies that RDF parses when semantic data is present and reports unsupported content when semantic checks do not apply.

```ts
const readable = await runtime.validation.validate(uri);
```

Runtime-managed validation checks saved RDF against the runtime Thing shape and reports structured issue codes such as `malformed-rdf`, `unsupported-content`, and `runtime-managed-shape`.

```ts
const managed = await runtime.validation.validate(thing.uri, {
  mode: "runtime-managed",
  repairHints: true,
});

for (const issue of managed.issues) {
  renderValidationIssue(issue.code, issue.message, issue.repairHint);
}
```

Runtime-managed `things.create` and `things.update` validate write output before returning.

## Diagnostics And Inspection

Use diagnostics when a UI needs to explain why a Thing did or did not appear.

```ts
const inspection = await runtime.diagnostics.inspectThing(thingOrContentUri);
const explanation = await runtime.diagnostics.explainQuery(queries.photos());
```

`inspectThing()` reports:

- whether the inspected URI resolved to a Thing
- content identity, kind, media type, and whether it is writable
- source identity, source kind, and metadata quality
- source/content/requested read status when the runtime knows it
- Thing identity, aliases, and source discovery state
- RDF predicate summaries
- type-index membership

`explainQuery()` reports matched URIs and per-record inclusion or exclusion decisions.

## Development Checks

From the workspace root:

```sh
npm run verify
```

`npm run verify` is the release readiness gate. It builds the package through `npm run smoke:app`, imports it from a temporary consumer app through the package export map, runs the unit suite, runs the deterministic local HTTP pod and Community Solid Server integration suite, runs the slower live CSS discovery budget checks, and runs `npm audit --omit=dev`.

`npm audit --omit=dev` is the runtime dependency security gate. Full `npm audit` currently reports a dev-only Community Solid Server transitive `nodemailer` advisory from the local E2E fixture; the latest CSS package does not yet expose a non-vulnerable `nodemailer` range.

## Local Consumer Packages

When consuming the runtime through `file:../solid-runtime/packages/runtime`, install dependencies from the consumer app after the file dependency is present. The runtime declares its own runtime dependencies, but some bundlers resolve symlinked package imports from the app root during local development. A published package or packed tarball should not require the consumer to duplicate `@solid-intents/runtime` dependencies.

If a local app cannot resolve packages such as `n3`, `soukai`, or `soukai-solid`, first run a clean install in the app. Treat duplicating those dependencies in the app package as a local bundler workaround, not as part of the runtime integration contract.

## Minimal Flow

```ts
await runtime.boot({ podUrl });

const stopPhotos = runtime.things.subscribe(queries.photos(), renderPhotos);
await runtime.discovery.start();

const context = await runtime.context.get(selectedUri);
const body = await runtime.things.content(context.thing, { as: "blob" });

stopPhotos();
```
