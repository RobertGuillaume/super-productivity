# Durable progressive discovery implementation

Status: **discovery complete and engineering-qualified; release blocked by the
upstream production dependency audit. Not published.**

Branch: `feat/durable-progressive-discovery`. Baseline: `ebed7d0`.
Write plans remain version 3; this migration introduces catalog schema 3.
The existing upstream production dependency audit remains a separate release gate.

## Ordered commits

- [x] 1. Compatibility fixtures and baselines (build; 60 existing and 4 fixture tests)
- [x] 2. Observations separated from committed effects (build; 98 targeted tests)
- [x] 3. Transactional catalog/discovery persistence (build; 123 targeted tests,
  including schema-1/schema-2 migration, journal rollback, quarantine and upgrade lifecycle)
- [x] 4. Cross-context ownership and catalog mirrors (build; 183 discovery/runtime
  tests, 212 catalog/discovery tests before final lease wiring, 87 runtime/auth tests)
- [x] 5. Durable work, receipts, and retry continuation (build; 41 persistence,
  coordination, and durable-execution tests, including 10,000-entry indexed selection)
- [x] 6. Container snapshots and expansion cursors (build; 242 regression tests,
  then 14 targeted tests including foreign-membership deletion safety)
- [x] 7. Type-index coverage and fallback (build; 277 catalog/discovery/type-index
  tests, including 14 durable protocol, restart, fallback, and atomicity cases)
- [x] 8. Bounded cross-Pod graph traversal (build; 94 graph, protocol, container,
  coordinator, and storage tests, including depth improvements and redirect boundaries)
- [x] 9. Public resumable sessions (build; 412 checks passed in the broad regression
  run, then all 20 session checks passed after correcting the remaining error classification)
- [x] 10. Progressive fair execution (build; 297 discovery/watch/runtime/API checks,
  including fake-clock publication and controlled foreground/background scheduling)
- [x] 11. Session-scoped queries and honest coverage (build; 420 broad regression
  checks, then 74 affected checks and 6 public restart checks after alias-scope refinement)
- [x] 12. Incremental catalog read performance (build; 793 full-suite checks,
  then all 15 affected checks after updating observer isolation and large-IDB
  fixture deadlines, plus 10 final query/index checks). Startup freshness is a
  local overlay; indexed candidates and source-alias deltas avoid full-catalog
  work on narrow queries and resource changes. No normal store clears.
- [x] 13. Legacy API unification and cleanup (build; 262 broad regression checks,
  31 affected checks after retirement-race/fixture corrections, and 108 compatibility
  checks plus all 8 final adapter checks). One coordinator owns all discovery reads.
  Old queue/progress/graph/type-worker characterization is superseded by durable
  work, graph, type, session, adapter, maintenance, and architectural suites.
  Listing completeness no longer masquerades as completed legacy traversal.
- [x] 14. Real-browser integration qualification (build, strict browser fixture
  declarations, 18 Chromium/Firefox cases against two local CSS origins, and 97
  runtime/auth checks). Covers real IndexedDB/Web Locks, tab and browser-process
  restart, missed broadcast hints, 304 continuation, interrupted transactions,
  schema upgrades, identities, cancellation, native/custom types and inverse links.
  Browser qualification exposed and fixed logout navigation preceding durable
  cleanup; the fix was committed independently.
- [x] 15. Large-catalog performance gates (build; cold/warm comparison; complete
  public-API 10,000-resource run; 40 structural checks plus 6 incremental-read
  checks; 35 affected query/session checks). Cold improved 66.4% and warm 9.6%
  against same-machine baseline medians. Complete coverage required 111 bounded
  turns with 10,001 GETs and a peak of 12 materialized jobs. Detailed timings,
  failed initial warm comparison, and full retained-memory costs are recorded in
  [the performance report](./scripts/DISCOVERY_PERFORMANCE.md).
- [x] 16. Documentation and final verification (Node 22.12.0 and 22.23.2:
  isolated packed Node/strict TypeScript/browser consumers, 756 unit tests,
  73 local-Pod integration tests, 2 live CSS performance tests, 18 real-browser
  cases, the 10,000-resource performance gates, and 46 structural checks).
  `npm run verify` still fails at the upstream production audit; subsequent
  stages were run independently without waiving that release gate.

## Contracts

Discovery persistence matches catalog support: IndexedDB where available, memory
otherwise. Built-in auth supplies identity; supplied authenticated fetch requires
an application-provided stable identity key for persistent discovery. Restoration
is network-free and unfinished sessions resume only on explicit execution.

Cross-Pod HTTP(S) graph traversal is enabled within declared budgets. Type discovery
automatically falls back to the current Pod when registrations are unusable.
Catalog knowledge is synchronized, not binary bodies. Soukai never executes I/O.

Observations must commit catalog effects, receipts and further discovery obligations
atomically. Complete listings are immutable 256-entry pages, materialized in batches
of ten. A 304 cannot strand pending children or prove that child resources are unchanged.
Coverage completion and work idleness are distinct. Cached degraded knowledge remains
visible; only authoritative absence hides Things.

## Baseline measurements

Node 22.23.2, median of three isolated measurements, 10,000 records:

| Read implementation | Cold query | Warm query | Retained projection heap | Pod reads |
| --- | ---: | ---: | ---: | ---: |
| Before semantic migration | 21.38 ms | 8.87 ms | 83,984 bytes | 0 |
| `ebed7d0` | 193.98 ms | 16.05 ms | 2,441,864 bytes | 0 |

These are local Node microbenchmarks, not browser latency or total heap guarantees.
Six existing targeted discovery/catalog suites passed 60 tests during planning.

Slice 12 same-machine comparison (Node 22.23.2, medians of three; working tree):
`ebed7d0` cold 329.18 ms / warm 15.62 ms; new reads cold 54.39 ms / warm
9.40 ms. Both made zero Pod requests. Retained projection heap was 2,441,744
versus 2,497,720 bytes; this excludes catalog indexes and persistence, which the
end-to-end qualification must measure separately. Timing varies with host load;
the final performance slice reruns this comparison and structural gates.

## Compatibility execution and cleanup

Legacy calls prepare generated sessions locally and dispatch through the same
coordinator as explicit sessions. They retain a 100-job turn budget; `settle()`
continues those passes without implicitly resuming unrelated restored sessions.
Synchronous global stop methods retire live work with asynchronous persistence
barriers; explicit session stop methods remain awaitable. Logout retires legacy
intents before draining the coordinator, including query-triggered preparation.

Superseded generations are removed in indexed batches of 100 with cleanup
checkpoints. Removing snapshot references creates durable garbage obligations;
unreferenced pages are reclaimed in bounded transactions only after active reads
drain under the ownership fence. Current authoritative snapshots remain available
for conditional reads. Session deletion never deletes cataloged Things.

## Final qualification

The implementation through `0e91e3a` passed the following matrix on both the
declared minimum Node 22.12.0 and supported Node 22.23.2. This final documentation
commit adds the consumer guide, packaged reports, and the new gates to `verify`;
it does not change production code or package versions.

| Gate | Node 22.12.0 | Node 22.23.2 |
| --- | --- | --- |
| Isolated packed Node CRUD/discovery consumer | Pass | Pass |
| Strict public declarations and packed browser build | Pass | Pass |
| Unit tests | 756 / 88 suites | 756 / 88 suites |
| Local Pod/CSS integration | 73 / 15 suites | 73 / 15 suites |
| Live CSS performance | 2 passed | 2 passed |
| Chromium and Firefox integration | 18 passed | 18 passed |
| 10,000-record cold/warm comparison | Pass; cold 53.4% faster | Pass; cold 69.1% faster |
| Public-API 10,000-resource discovery | Complete; 12 peak materialized jobs | Complete; 12 peak materialized jobs |
| Structural catalog/discovery checks | 46 passed | 46 passed |
| Isolated production audit | Fail: 5 moderate, 1 high | Fail: 5 moderate, 1 high |
| Workspace production audit | Fail: 4 moderate, 1 high | Fail: 4 moderate, 1 high |

`npm run verify` stops at the isolated production audit on both versions. The
unit, integration, browser, and performance commands above were therefore also
run independently. Structural checks overlap the unit suite; they are not 46
additional distinct tests. Full same-run performance comparisons, request counts,
early-result measurements, and retained-memory costs are in
[the performance report](./scripts/DISCOVERY_PERFORMANCE.md).

Qualification exposed and fixed scoped subscription declarations, an N3
development-type leak into public declarations, logout navigation preceding
durable cleanup, and a terminal-publication refresh race. Refresh requests now
wait for the preceding execution barrier, and background failures are observed
rather than left as unhandled rejections. The 10,000-entry fake-IDB fixture needed
a larger initialization deadline. Integration fixtures now explicitly settle
bounded collection passes and advance lease-renewal intervals alongside their
virtual Date. Final full runs pass without unhandled errors; no HTTP request
budget, cold/warm performance threshold, or lease-fencing guarantee was relaxed.

The remaining release blocker is the existing upstream chain:
`soukai-solid@0.7.1` → `@noeldemartin/solid-utils@0.6.1` → JSON-LD 8 →
`@digitalbazaar/http-client` → Undici 5. The isolated consumer reports six affected
packages because it also counts the dependent runtime; the workspace reports
five. No fork, consumer override, dependency downgrade, audit waiver, version
bump, or publication was used to qualify this discovery work. Engineering
qualification does not make the failed release gate green.

Development installation note: the pre-existing dev-only `jsdom@29.1.1` declares
Node 22.13+ on the Node 22 line. Workspace dependencies were installed on 22.23.2;
the same unmodified test dependencies were also exercised on the runtime's actual
minimum 22.12.0. Isolated packed consumers install their own dependencies and do
not install jsdom. Prefer 22.23.2 for development installation; this observation
does not raise the runtime's minimum, add a consumer override, or waive an audit.
