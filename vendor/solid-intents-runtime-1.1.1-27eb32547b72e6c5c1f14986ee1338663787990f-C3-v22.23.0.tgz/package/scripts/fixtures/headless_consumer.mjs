import assert from "node:assert/strict";
import { SolidGraphRuntime } from "@solid-intents/runtime";

class AuthorizedPod {
  resources = new Map();
  requests = [];
  revision = 0;

  constructor(root) { this.root = root; }

  fetch = async (input, init) => {
    const request = new Request(input, init);
    assert(request.url.startsWith(this.root), `Unexpected destination: ${request.url}`);
    this.requests.push({ method: request.method, uri: request.url });
    const current = this.resources.get(request.url);
    if (request.headers.get("If-Match") && request.headers.get("If-Match") !== current?.etag) return new Response(null, { status: 412 });
    if (request.headers.get("If-None-Match") === "*" && current) return new Response(null, { status: 412 });
    if (request.method === "PUT") {
      const body = await request.arrayBuffer();
      const resource = { body, contentType: request.headers.get("Content-Type") ?? "application/octet-stream", etag: `"${++this.revision}"` };
      this.resources.set(request.url, resource);
      return new Response(null, { status: current ? 205 : 201, headers: { ETag: resource.etag } });
    }
    if (request.method === "DELETE") {
      this.resources.delete(request.url);
      return new Response(null, { status: current ? 205 : 404 });
    }
    assert(["GET", "HEAD"].includes(request.method), `Unsupported fixture method: ${request.method}`);
    if (!current) return new Response(null, { status: 404 });
    const headers = { "Content-Type": current.contentType, ETag: current.etag };
    if (request.headers.get("If-None-Match") === current.etag) return new Response(null, { status: 304, headers });
    return new Response(request.method === "HEAD" ? null : current.body.slice(0), { headers });
  };
}

assert.equal(typeof window, "undefined");
assert.equal(typeof indexedDB, "undefined");
const pod = new AuthorizedPod("https://headless.example/alice/");
const runtime = new SolidGraphRuntime();
await runtime.boot({ podUrl: pod.root, fetch: pod.fetch, discoveryIdentityKey: "baseline-alice", requestScheduling: { minIntervalMs: 0, maxRetries: 0 } });
assert.equal(pod.requests.length, 0);
runtime.types.register({ type: "ArchiveEntry", classUri: "https://example.org/ArchiveEntry", fields: { score: { predicateUri: "https://example.org/score", valueType: "number" } } });
const thing = await runtime.things.create({ type: "ArchiveEntry", fields: { title: "Supplied fetch", score: 7 }, target: { containerUri: pod.root, resourceName: "entry" } });
assert.equal(thing.as(runtime.types.view("ArchiveEntry")).fields.score, 7);
const source = await runtime.resources.read(thing.source.uri, { as: "text" });
assert(source.text.includes("https://example.org/ArchiveEntry"));
const replacement = await runtime.writes.planResourceReplace(thing.source.uri, { body: source.text.replace("Supplied fetch", "Updated entry"), mediaType: "text/turtle" });
await runtime.writes.commit(JSON.parse(JSON.stringify(replacement)));
assert.equal((await runtime.things.get(thing.uri)).facets.title, "Updated entry");
const session = await runtime.discovery.createSession({ id: "baseline", targets: [{ kind: "graph", uri: thing.uri, maxDepth: 0 }] });
assert.equal(session.snapshot().persistence.kind, "memory");
const before = pod.requests.length;
await runtime.things.query({}, { scope: { kind: "discovery-session", id: session.id } });
assert.equal(pod.requests.length, before);
assert.equal((await session.run()).reason, "settled");
assert.equal((await runtime.things.query({}, { scope: { kind: "discovery-session", id: session.id } })).metadata.discovery.coverage.status, "complete");
await runtime.writes.commit(await runtime.writes.planResourceDelete(thing.source.uri));
await assert.rejects(runtime.resources.read(thing.source.uri), { code: "resource-read-failed" });
await runtime.auth.logout();
console.info(JSON.stringify({ bundle: "baseline", status: "passed", node: process.version, requests: pod.requests.length, persistence: "memory", qualifiedBundles: [] }));
