import assert from "node:assert/strict";
import { SolidGraphRuntime } from "@solid-intents/runtime";
import { runPortableTurn } from "../examples/portable_agent.mjs";

const root = "https://portable.example/alice/", container = `${root}notes/`, checkpoints = `${root}checkpoints/`;
class PortablePod {
  resources = new Map(); revision = 0; sourceRequests = 0; checkpointRequests = 0; loseRoot = false; lostResponses = 0;
  constructor() {
    this.set(container, `<${container}> a <http://www.w3.org/ns/ldp#BasicContainer>; <http://www.w3.org/ns/ldp#contains> <${container}one.ttl>, <${container}two.ttl>.`);
    this.set(`${container}one.ttl`, '<#it> a <https://www.w3.org/ns/activitystreams#Note>; <https://www.w3.org/ns/activitystreams#name> "Native note".');
    this.set(`${container}two.ttl`, `<#it> a <urn:unknown:Archive>; <urn:label> "préserver"@fr; <urn:score> "01"^^<http://www.w3.org/2001/XMLSchema#integer>; <urn:detail> [ <urn:value> "blank" ]. <https://external.example/subject> a <urn:unknown:Archive>.`);
  }
  set(uri, body, mediaType = "text/turtle") {
    const value = { bytes: typeof body === "string" ? new TextEncoder().encode(body) : body, mediaType, etag: `"${++this.revision}"` }; this.resources.set(uri, value); return value;
  }
  fetch = async (input, init) => {
    const request = new Request(input, init), checkpoint = request.url.startsWith(checkpoints);
    if (checkpoint) this.checkpointRequests++; else this.sourceRequests++;
    if (request.method === "HEAD" && request.url === checkpoints) return new Response(null, { headers: { Link: '<http://www.w3.org/ns/ldp#BasicContainer>; rel="type"' } });
    const current = this.resources.get(request.url);
    if (request.headers.has("If-Match") && request.headers.get("If-Match") !== current?.etag || request.headers.get("If-None-Match") === "*" && current) return new Response(null, { status: 412 });
    if (["PUT", "PATCH"].includes(request.method)) {
      assert(checkpoint, "Portable state may only write its explicitly selected namespace");
      let bytes = new Uint8Array(await request.arrayBuffer()), mediaType = request.headers.get("Content-Type");
      if (request.method === "PATCH") {
        assert.equal(request.url, `${checkpoints}manifest.ttl`); assert.equal(mediaType, "text/n3");
        const insertion = new TextDecoder().decode(bytes).match(/solid:inserts \{ ([\s\S]*) \}\.\n$/u);
        assert(insertion, "The fixture requires the complete pinned manifest patch body");
        if (current) assert(new TextDecoder().decode(bytes).includes("solid:where"));
        bytes = new TextEncoder().encode(insertion[1]); mediaType = "text/turtle";
      }
      const next = this.set(request.url, bytes, mediaType);
      if (this.loseRoot && request.url.endsWith("manifest.ttl")) { this.loseRoot = false; this.lostResponses++; throw new Error("Lost a committed root response"); }
      return new Response(null, { status: current ? 204 : 201, headers: { ETag: next.etag } });
    }
    if (request.method === "DELETE") { assert(checkpoint); this.resources.delete(request.url); return new Response(null, { status: 204 }); }
    assert.equal(request.method, "GET");
    if (!current) return new Response(null, { status: 404 });
    if (request.headers.get("If-None-Match") === current.etag) return new Response(null, { status: 304, headers: { ETag: current.etag } });
    return new Response(Uint8Array.from(current.bytes), { headers: { ETag: current.etag, "Content-Type": current.mediaType } });
  };
}
const pod = new PortablePod(), clients = [];
async function boot(mode) {
  const runtime = new SolidGraphRuntime(); clients.push(runtime);
  await runtime.boot({ podUrl: root, fetch: pod.fetch, execution: "explicit", requestScheduling: { minIntervalMs: 0, maxConcurrent: 2 },
    identity: { principalWebId: "https://agent.example/#me", ownerWebId: `${root}profile#me`, applicationNamespace: "packed-C3" },
    persistence: { kind: "pod", containerUri: checkpoints, mode },
  });
  assert.equal(runtime.diagnostics.status().requestScheduling.find((status) => status.origin === new URL(checkpoints).origin)?.reservedCheckpointSlots, 1, "C3 requires capacity for checkpoint dependencies while source bodies are retained");
  return runtime;
}
try {
  assert.equal(typeof indexedDB, "undefined"); assert.equal(typeof window, "undefined");
  const initial = await boot("create");
  assert.equal(typeof initial.things.queryPage, "function", "C3 requires bounded catalog pages");
  assert.equal(typeof initial.checkpoints.compact, "function", "C3 requires resumable checkpoint cleanup");
  assert.equal(typeof initial.checkpoints.maintenanceStatus, "function", "C3 requires checkpoint maintenance visibility");
  assert.equal(typeof initial.checkpoints.maintain, "function", "C3 requires bounded checkpoint reclamation");
  assert.equal((await initial.checkpoints.maintenanceStatus()).reason, "idle");
  assert.deepEqual(await initial.checkpoints.maintain(), { due: false, reason: "idle", uploadedPagesSinceSweep: 0, uploadedBytesSinceSweep: 0, completedCycles: 0, started: false, complete: true, steps: 0, deletedPages: 0, deletedMetadata: 0 });
  assert(initial.diagnostics.status().checkpointActivity?.effectiveDiscoveryConcurrency >= 1);
  const session = await initial.discovery.createSession({ id: "portable", targets: [{ kind: "container", uri: container }] });
  assert.equal(session.snapshot().persistence.kind, "pod", "Pod persistence must never fall back to memory");
  const beforeZero = pod.checkpointRequests + pod.sourceRequests;
  assert.equal((await session.run({ maxRequests: 0 })).reason, "insufficient-budget");
  assert.equal(pod.checkpointRequests + pod.sourceRequests, beforeZero);
  pod.loseRoot = true;
  const before = pod.checkpointRequests + pod.sourceRequests, first = await session.run({ maxJobs: 1 });
  assert.equal(first.reason, "budget-exhausted"); assert.equal(first.usage.requests, pod.checkpointRequests + pod.sourceRequests - before);
  const output = await session.readOutput(); assert(output); assert.deepEqual(await session.readOutput(), output);
  await initial.close(); const sourcesBefore = pod.sourceRequests;
  const restored = await boot("open"), reopened = await restored.discovery.getSession("portable"); assert(reopened);
  assert.equal(pod.sourceRequests, sourcesBefore, "Opening checkpoint state must not discover sources");
  assert.deepEqual(await reopened.readOutput({ maxObservations: 1 }), output);
  await reopened.acknowledgeOutput(output.receipt); await reopened.acknowledgeOutput(output.receipt);
  assert.equal((await reopened.run()).reason, "settled");
  const batches = [], facts = [];
  for (let batch = await reopened.readOutput(); batch; batch = await reopened.readOutput()) {
    batches.push(batch.receipt); facts.push(...batch.observations.flatMap((observation) => observation.facts));
    assert.deepEqual(await reopened.readOutput(), batch); await reopened.acknowledgeOutput(batch.receipt);
  }
  assert(facts.some((quad) => quad.object.termType === "Literal" && quad.object.language === "fr" && quad.object.value === "préserver"));
  assert(facts.some((quad) => quad.object.termType === "Literal" && quad.object.value === "01" && quad.object.datatype.value.endsWith("#integer")));
  assert(facts.some((quad) => quad.subject.termType === "BlankNode" || quad.object.termType === "BlankNode"));
  assert(facts.some((quad) => quad.subject.value === "https://external.example/subject"));
  const sourceCount = pod.sourceRequests, firstPage = await restored.things.queryPage({}, { pageSize: 1 });
  assert.equal(firstPage.things.length, 1); assert(firstPage.nextCursor);
  assert.equal((await restored.things.queryPage({}, { pageSize: 1, cursor: firstPage.nextCursor })).things.length, 1);
  let cleanup;
  for (let turn = 0; ; turn++) { assert(turn < 1000); cleanup = await restored.checkpoints.compact({ maxSteps: 64 }); if (cleanup.complete) break; }
  assert.equal(pod.sourceRequests, sourceCount); assert.equal(await reopened.readOutput(), null);
  assert.equal(pod.lostResponses, 1);
  assert.equal(pod.resources.get(`${checkpoints}manifest.ttl`).mediaType, "text/turtle");
  assert.equal(pod.resources.has(`${checkpoints}manifest.json`), false);
  await restored.close();
  const example = await runPortableTurn({ authenticatedFetch: pod.fetch, podUrl: root,
    identity: { principalWebId: "https://agent.example/#me", ownerWebId: `${root}profile#me`, applicationNamespace: "packed-C3" },
    checkpointContainer: checkpoints, sessionId: "portable", targets: [{ kind: "container", uri: container }],
    runOptions: { maxRequests: 0 }, acceptBatch: async () => { throw new Error("Already acknowledged output must remain acknowledged"); },
  });
  assert.equal(example.turn.reason, "insufficient-budget"); assert(example.page.things.length > 0);
  assert.equal(pod.sourceRequests, sourceCount);
  console.info(JSON.stringify({ bundle: "C3", passed: true, checkpointVersion: 1, observationVersion: 1, restoredWithoutSourceReads: true, stableRedelivery: true, unknownClasses: true, publicExample: true, checkpointRequests: pod.checkpointRequests, sourceRequests: pod.sourceRequests, cleanup, archiveQualification: "separate-100000-resource-gate" }));
} finally { for (const runtime of clients) await runtime.close(); }
