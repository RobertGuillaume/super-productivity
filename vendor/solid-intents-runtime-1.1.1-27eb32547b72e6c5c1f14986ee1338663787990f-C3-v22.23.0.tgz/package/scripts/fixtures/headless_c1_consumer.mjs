import assert from "node:assert/strict";
import { SolidGraphRuntime } from "@solid-intents/runtime";

const root = "https://headless.example/alice/", otherRoot = "https://headless.example/bob/";
const owner = `${root}profile/card#me`, otherOwner = `${otherRoot}profile/card#me`;
const principal = "https://agents.example/one#me", otherPrincipal = "https://agents.example/two#me";
const note = (uri, title) => `<${uri}#it> a <https://www.w3.org/ns/activitystreams#Note>; <https://www.w3.org/ns/activitystreams#name> ${JSON.stringify(title)}.`;

class SuppliedTransport {
  constructor(pod, principalWebId) { this.pod = pod; this.principalWebId = principalWebId; }
  fetch = async (input, init) => await this.pod.dispatch(new Request(input, init), this.principalWebId);
}

class PathPods {
  resources = new Map(); requests = []; revision = 0; posts = 0; losePost = false;
  redirects = new Map(); patchBodies = new Map(); holdUri; entered = Promise.withResolvers(); release = Promise.withResolvers();
  put(uri, body, contentType = "text/turtle") {
    const bytes = typeof body === "string" ? new TextEncoder().encode(body) : Uint8Array.from(body);
    this.resources.set(uri, { bytes, contentType, etag: `"${++this.revision}"` });
  }
  async dispatch(request, actor) {
    const body = ["PUT", "POST", "PATCH"].includes(request.method) ? new Uint8Array(await request.arrayBuffer()) : undefined;
    this.requests.push({ method: request.method, uri: request.url, headers: request.headers, redirect: request.redirect, body, actor });
    const current = this.resources.get(request.url);
    if (this.redirects.has(request.url)) return new Response(null, { status: 307, headers: { Location: this.redirects.get(request.url) } });
    if (request.headers.has("If-Match") && request.headers.get("If-Match") !== current?.etag) return new Response(null, { status: 412 });
    if (request.headers.get("If-None-Match") === "*" && current) return new Response(null, { status: 412 });
    if (request.method === "PUT") {
      this.put(request.url, body, request.headers.get("Content-Type"));
      if (request.url === this.holdUri) { this.entered.resolve(); await this.release.promise; }
      return new Response(null, { status: current ? 204 : 201 });
    }
    if (request.method === "POST") {
      this.posts++;
      const location = new URL(request.headers.get("Slug") ?? `message-${this.posts}`, request.url).href;
      this.put(location, body, request.headers.get("Content-Type"));
      if (this.losePost) throw new TypeError("Lost successful POST response");
      return new Response(null, { status: 201, headers: { Location: location } });
    }
    if (request.method === "PATCH") {
      assert.equal(request.headers.get("Content-Type"), "text/n3");
      const approved = this.patchBodies.get(new TextDecoder().decode(body));
      assert(approved, "Unexpected patch bytes in transport fixture");
      this.put(request.url, approved);
      return new Response(null, { status: 204 });
    }
    if (request.method === "DELETE") { this.resources.delete(request.url); return new Response(null, { status: current ? 204 : 404 }); }
    assert(["HEAD", "GET"].includes(request.method));
    if (!current) return new Response(null, { status: 404 });
    const headers = { ETag: current.etag, "Content-Type": current.contentType };
    if (request.headers.get("If-None-Match") === current.etag) return new Response(null, { status: 304, headers });
    return new Response(request.method === "HEAD" ? null : current.bytes.slice(), { headers });
  }
}

assert.equal(typeof window, "undefined"); assert.equal(typeof indexedDB, "undefined");
const pod = new PathPods(), clients = [];
async function boot(changes = {}) {
  const identity = { principalWebId: principal, ownerWebId: owner, applicationNamespace: "C1-contract", ...changes.identity };
  const transport = new SuppliedTransport(pod, identity.principalWebId);
  const runtime = new SolidGraphRuntime(); clients.push(runtime);
  await runtime.boot({ podUrl: changes.podUrl ?? root, fetch: transport.fetch, identity, execution: "explicit", persistence: { kind: "memory" }, requestScheduling: { minIntervalMs: 0 } });
  for (const method of ["planResourceCreate", "planResourcePost", "planRdfPatch", "commit"]) assert.equal(typeof runtime.writes[method], "function", `C1 requires writes.${method}`);
  assert.equal(typeof runtime.close, "function", "C1 requires awaited context close");
  return runtime;
}
try {
  const first = await boot();
  const uri = `${root}entry.ttl`; pod.put(uri, note(uri, "Alice")); pod.put(`${otherRoot}entry.ttl`, note(`${otherRoot}entry.ttl`, "Bob"));
  const session = await first.discovery.createSession({ id: "isolated", targets: [{ kind: "graph", uri: `${uri}#it`, maxDepth: 0 }] });
  assert.equal(session.snapshot().persistence.kind, "memory");
  const beforeQuery = pod.requests.length;
  assert.deepEqual((await first.things.query({ type: "Note" }, { autoDiscover: true })).things, []);
  assert.equal(pod.requests.length, beforeQuery);
  await session.run(); assert.equal((await first.things.query({})).things.length, 1);
  const second = await boot({ identity: { principalWebId: otherPrincipal } });
  for (const isolated of [second, await boot({ identity: { ownerWebId: otherOwner } }), await boot({ identity: { applicationNamespace: "second-app" } }), await boot({ podUrl: otherRoot, identity: { ownerWebId: otherOwner } })]) {
    assert.deepEqual((await isolated.things.query({})).things, []); assert.deepEqual(await isolated.discovery.listSessions(), []);
  }
  const ownerSession = await clients.at(-1).discovery.createSession({ targets: [{ kind: "type", type: "Note" }], fallbackStorageRoots: [] });
  const ownerReads = pod.requests.length; await ownerSession.run();
  assert(pod.requests.slice(ownerReads).some((request) => request.uri === otherOwner.split("#")[0]));
  assert(pod.requests.slice(ownerReads).every((request) => !request.uri.startsWith("https://agents.example/")));
  await assert.rejects(first.boot({ podUrl: root, fetch: new SuppliedTransport(pod, principal).fetch, identity: { principalWebId: otherPrincipal, ownerWebId: owner, applicationNamespace: "C1-contract" } }), { code: "runtime-identity-mismatch" });
  const redirect = `${root}redirect.ttl`; pod.redirects.set(redirect, `${otherRoot}entry.ttl`);
  const beforeRedirect = pod.requests.length;
  await assert.rejects(first.resources.read(redirect, { readScope: { allowedContainerRoots: [root] } }));
  assert.deepEqual(pod.requests.slice(beforeRedirect).map((request) => request.uri), [redirect]);
  assert((await first.resources.read(`${otherRoot}entry.ttl`)).text.includes("Bob"));

  const raw = `${root}exact.json`, initial = '{ "unicode": "préserver" }\n';
  const creation = await first.writes.planResourceCreate(raw, { body: initial, mediaType: "application/json" });
  assert.equal(creation.version, 4); assert.equal(creation.identity.principalWebId, principal);
  await first.writes.commit(JSON.parse(JSON.stringify(creation)));
  assert.equal((await first.resources.read(raw)).text, initial);
  await assert.rejects(first.writes.commit(creation), (error) => error.outcomes[0].failure.kind === "conflict");
  const readA = await first.resources.read(raw); pod.put(raw, "current", "application/json");
  const original = await first.writes.planResourceReplace(raw, { body: "current", mediaType: "application/json", validator: { kind: "etag", etag: readA.metadata.etag } });
  await assert.rejects(first.writes.commit(original), (error) => error.outcomes[0].httpStatus === 412);
  const legacy = new SolidGraphRuntime(); clients.push(legacy);
  await legacy.boot({ podUrl: root, fetch: new SuppliedTransport(pod, principal).fetch, execution: "explicit", persistence: { kind: "memory" }, requestScheduling: { minIntervalMs: 0 } });
  const legacyReviewed = await legacy.writes.planResourceReplace(raw, { body: "legacy accepted", mediaType: "text/plain" });
  const { identity: ignoredBinding, http: ignoredHttp, ...legacyEnvelope } = legacyReviewed;
  const versionThree = { ...legacyEnvelope, version: 3 };
  const beforeLegacy = pod.requests.length;
  await assert.rejects(first.writes.commit(versionThree), { code: "write-plan-invalid" });
  assert.equal(pod.requests.length, beforeLegacy);
  await legacy.writes.commit(versionThree);
  assert.equal((await legacy.resources.read(raw)).text, "legacy accepted");
  const binary = new Uint8Array([0, 1, 127, 255]);
  await first.writes.commit(await first.writes.planResourceCreate(`${root}exact.bin`, { body: binary, mediaType: "application/octet-stream" }));
  assert.deepEqual(pod.resources.get(`${root}exact.bin`).bytes, binary);
  const patch = '[] a <http://www.w3.org/ns/solid/terms#InsertDeletePatch>; <http://www.w3.org/ns/solid/terms#inserts> { <#it> <urn:extra> "added". }.\n';
  pod.patchBodies.set(patch, `${note(uri, "Alice")} <#it> <urn:extra> "added".`);
  const approvedPatch = await first.writes.planRdfPatch(uri, { body: patch, validator: { kind: "etag", etag: (await first.resources.read(uri)).metadata.etag } });
  await first.writes.commit(JSON.parse(JSON.stringify(approvedPatch)));
  assert.equal(pod.requests.findLast((request) => request.method === "PATCH").headers.get("Content-Type"), "text/n3");
  const peer = "https://peer.example/inbox/", post = await first.writes.planResourcePost(peer, { body: initial, mediaType: "application/json", slug: "message.json" });
  const sent = await first.writes.commit(post); assert.equal(sent.result.location, `${peer}message.json`);
  pod.losePost = true;
  await assert.rejects(first.writes.commit(await first.writes.planResourcePost(peer, { body: "once", mediaType: "text/plain" })), (error) => error.outcomes[0].status === "unknown");
  assert.equal(pod.posts, 2); pod.losePost = false;
  const controller = new AbortController(); controller.abort(); const beforeAbort = pod.requests.length;
  await assert.rejects(first.writes.commit(post, { signal: controller.signal }), { code: "operation-aborted" });
  assert.equal(pod.requests.length, beforeAbort);
  const changedBinding = pod.requests.length;
  await assert.rejects(second.writes.commit(creation), { code: "write-plan-invalid" }); assert.equal(pod.requests.length, changedBinding);

  pod.holdUri = `${root}late.txt`;
  const latePlan = await first.writes.planResourceCreate(pod.holdUri, { body: "remote effect", mediaType: "text/plain" });
  const lateWrite = first.writes.commit(latePlan); const lateResult = assert.rejects(lateWrite);
  await pod.entered.promise;
  const closing = first.close({ timeoutMs: 20 }); const duplicate = first.close();
  const closed = await Promise.allSettled([closing, duplicate]);
  assert(closed.every((result) => result.status === "rejected"));
  assert.equal(closed[0].reason, closed[1].reason);
  assert.equal(closed[0].reason.code, "runtime-close-timeout");
  assert(closed[0].reason.details.unsettled.some((operation) => operation.outcome === "unknown"));
  await assert.rejects(first.resources.read(uri), { code: "runtime-closed" });
  pod.release.resolve(); await lateResult;
  assert((await second.resources.read(uri)).text.includes("Alice"));
  console.info(JSON.stringify({ bundle: "C1", status: "passed", node: process.version, completedContractBundles: ["C1"], writePlanVersions: [3, 4], checkpointVersions: [], persistence: "memory", principals: 2, owners: 2, pathPods: 2, requests: pod.requests.length, automaticPostReplays: 0 }));
} finally {
  pod.release.resolve();
  await Promise.allSettled(clients.map(async (client) => await client.close()));
}
