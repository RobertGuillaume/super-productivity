import assert from "node:assert/strict";
import { RuntimeWriteCommitError, SolidGraphRuntime } from "@solid-intents/runtime";

const root = "https://publication.example/alice/", owner = `${root}profile/card#me`;
const preferences = `${root}settings/preferences.ttl`, indexUri = `${root}settings/private.ttl`, publicIndex = `${root}settings/inaccessible-public.ttl`;
const solid = "http://www.w3.org/ns/solid/terms#", xsd = "http://www.w3.org/2001/XMLSchema#";
function named(value) { return { termType: "NamedNode", value }; }
function triple(subject, predicate, object) { return { subject: named(subject), predicate: named(predicate), object: typeof object === "string" ? named(object) : object, graph: { termType: "DefaultGraph", value: "" } }; }
function literal(value, datatype = `${xsd}string`, language = "") { return { termType: "Literal", value, language, datatype: named(datatype) }; }
function termText(term) {
  if (term.termType === "NamedNode") return `<${term.value}>`;
  assert.equal(term.termType, "Literal");
  return `${JSON.stringify(term.value)}${term.language ? `@${term.language}` : `^^<${term.datatype.value}>`}`;
}
function tripleText(quad) { return `${termText(quad.subject)} ${termText(quad.predicate)} ${termText(quad.object)} .`; }

class SelectedIndexTransport {
  requests = []; revision = 1; patches = 0; loseNextResponse = false; approved = new Map();
  quads = new Map();
  constructor() {
    for (const quad of [triple(`${indexUri}#manual`, `${solid}forClass`, "urn:manual"), triple(`${indexUri}#manual`, `${solid}instance`, `${root}manual#it`), triple(`${indexUri}#manual`, "urn:label", literal("préserver", "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString", "fr"))]) this.quads.set(tripleText(quad), quad);
  }
  approve(plan) {
    assert.equal(plan.kind, "type-index.patch");
    assert.equal(plan.request.privacy, "private");
    assert.equal(plan.request.ownerWebId, owner);
    assert.equal(plan.http.length, 1);
    this.approved.set(plan.http[0].payload.value, structuredClone(plan));
  }
  fetch = async (input, init) => {
    const request = new Request(input, init); this.requests.push({ uri: request.url, method: request.method });
    if (request.method === "PATCH") {
      this.patches++;
      assert.equal(request.url, indexUri); assert.equal(request.redirect, "manual");
      assert.equal(request.headers.get("Content-Type"), "text/n3");
      const plan = this.approved.get(await request.text()); assert(plan, "Transport accepts only explicitly approved exact patch bytes");
      if (request.headers.get("If-Match") !== `"${this.revision}"`) return new Response(null, { status: 412 });
      for (const quad of plan.request.deletions) this.quads.delete(tripleText(quad));
      for (const quad of plan.request.insertions) this.quads.set(tripleText(quad), quad);
      this.revision++;
      if (this.loseNextResponse) { this.loseNextResponse = false; throw new TypeError("Lost a successful publication response"); }
      return new Response(null, { status: 205 });
    }
    assert.equal(request.method, "GET");
    const body = request.url === owner.split("#")[0] ? `<${owner}> <http://www.w3.org/ns/pim/space#preferencesFile> <${preferences}>.`
      : request.url === preferences ? `<${owner}> <${solid}privateTypeIndex> <${indexUri}>; <${solid}publicTypeIndex> <${publicIndex}>.`
      : request.url === indexUri ? `${[...this.quads.keys()].join("\n")}\n_:manual <urn:unknown-link> <https://external.example/item>.` : undefined;
    return body === undefined ? new Response(null, { status: 403 }) : new Response(body, { headers: { "Content-Type": "text/turtle", ETag: `"${this.revision}"` } });
  };
}

class ConsumerPublication {
  constructor(runtime, index) { this.runtime = runtime; this.index = index; this.markerUri = `${index}#my-publication-revision`; }
  marker(revision) { return triple(this.markerUri, "urn:publication-revision", literal(String(revision), `${xsd}integer`)); }
  async prepare(changes, revision, previousRevision) {
    const observed = await this.runtime.typeIndexes.read(this.index);
    return await this.runtime.writes.planTypeIndexPatch(this.index, {
      ownerWebId: owner, privacy: "private", validator: { kind: "etag", etag: observed.source.metadata.etag }, changes,
      markers: { insertions: [this.marker(revision)], deletions: previousRevision === undefined ? [] : [this.marker(previousRevision)] },
    });
  }
  async commitOrReconcile(plan, revision) {
    try { await this.runtime.writes.commit(JSON.parse(JSON.stringify(plan))); return "confirmed"; }
    catch (error) {
      if (!(error instanceof RuntimeWriteCommitError) || error.outcomes[0]?.status !== "unknown") throw error;
      const observed = await this.runtime.typeIndexes.read(this.index);
      const accepted = observed.quads.some((quad) => quad.subject.value === this.markerUri && quad.predicate.value === "urn:publication-revision" && quad.object.termType === "Literal" && quad.object.value === String(revision));
      if (!accepted) throw error;
      return "reconciled-by-consumer-marker";
    }
  }
}

const transport = new SelectedIndexTransport(), runtime = new SolidGraphRuntime();
try {
  assert.equal(typeof window, "undefined"); assert.equal(typeof indexedDB, "undefined");
  await runtime.boot({ podUrl: root, fetch: transport.fetch, identity: { principalWebId: "https://agent.example/worker#me", ownerWebId: owner, applicationNamespace: "C2-consumer" }, execution: "explicit", persistence: { kind: "memory" }, requestScheduling: { minIntervalMs: 0 } });
  for (const name of ["discover", "read"]) assert.equal(typeof runtime.typeIndexes[name], "function", `C2 requires typeIndexes.${name}`);
  assert.equal(typeof runtime.resources.readRdf, "function"); assert.equal(typeof runtime.writes.planTypeIndexPatch, "function");
  const discovery = await runtime.typeIndexes.discover(owner);
  assert.equal(discovery.complete, true);
  assert.deepEqual(transport.requests.map((request) => request.uri), [owner.split("#")[0], preferences]);
  const selected = discovery.links.find((link) => link.privacy === "private"); assert.equal(selected.uri, indexUri);
  assert.equal(selected.source.uri, preferences);
  const publication = new ConsumerPublication(runtime, selected.uri), registrationUri = `${indexUri}#consumer-owned`;
  const first = await publication.prepare([{ kind: "register", registrationUri, classUris: ["urn:unknown-class"], targets: [{ kind: "instance", uri: `${root}one#it` }] }], 1);
  transport.approve(first); assert.equal(await publication.commitOrReconcile(first, 1), "confirmed");
  const second = await publication.prepare([{ kind: "register", registrationUri, classUris: ["urn:unknown-class"], targets: [{ kind: "instance", uri: `${root}two#it` }] }], 2, 1);
  transport.approve(second); transport.loseNextResponse = true;
  assert.equal(await publication.commitOrReconcile(second, 2), "reconciled-by-consumer-marker");
  assert.equal(transport.patches, 2, "Consumer reconciliation must not replay the accepted patch");
  const third = await publication.prepare([{ kind: "unregister", registrationUri, targets: [{ kind: "instance", uri: `${root}one#it` }] }, { kind: "reclassify", registrationUri, removeClassUris: ["urn:unknown-class"], addClassUris: ["urn:changed-class"] }], 3, 2);
  transport.approve(third); assert.equal(await publication.commitOrReconcile(third, 3), "confirmed");
  const observed = await runtime.typeIndexes.read(indexUri), owned = observed.registrations.find((registration) => registration.identity.value === registrationUri);
  assert.deepEqual(owned.classUris, ["urn:changed-class"]); assert.deepEqual(owned.instanceUris, [`${root}two#it`]);
  assert.deepEqual(observed.registrations.find((registration) => registration.identity.value === `${indexUri}#manual`).classUris, ["urn:manual"]);
  assert(observed.quads.some((quad) => quad.subject.termType === "BlankNode" && quad.object.value === "https://external.example/item"));
  const batches = []; for await (const batch of runtime.resources.readRdf(indexUri, { batchSize: 2 })) batches.push(batch);
  assert.equal(batches.at(-1).complete, true); assert(batches.length > 1);
  assert(batches.flatMap((batch) => batch.quads).some((quad) => quad.object.termType === "Literal" && quad.object.language === "fr" && quad.object.value === "préserver"));
  assert(!transport.requests.some((request) => request.uri === publicIndex));
  assert.equal(transport.patches, 3);
  assert.deepEqual((await runtime.things.query({})).things, [], "Protocol observations do not implicitly crawl or materialize source Things");
  console.info(JSON.stringify({ bundle: "C2", passed: true, httpRequests: transport.requests.length, patches: transport.patches, publicationIds: "consumer-owned", lostSuccess: "reconciled-by-consumer-marker", automaticPatchReplays: 0, sourceDiscoveryRequests: 0 }));
} finally { await runtime.close(); }
