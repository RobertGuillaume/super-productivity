import { SolidGraphRuntime } from "@solid-intents/runtime";

/** The caller supplies authentication, destination provisioning and durable, idempotent acceptance. */
export async function runPortableTurn({ authenticatedFetch, podUrl, identity, checkpointContainer, mode = "open", sessionId, targets, acceptBatch, runOptions = { maxJobs: 100 } }) {
  const runtime = new SolidGraphRuntime();
  try {
    await runtime.boot({ podUrl, fetch: authenticatedFetch, identity, execution: "explicit", persistence: { kind: "pod", containerUri: checkpointContainer, mode } });
    const session = await runtime.discovery.getSession(sessionId)
      ?? await runtime.discovery.createSession({ id: sessionId, targets });
    const drain = async () => {
      for (let batch = await session.readOutput(); batch; batch = await session.readOutput()) {
        // Resolve only after all IDs in this batch are durably accepted. Throwing leaves it available for redelivery.
        await acceptBatch(batch);
        await session.acknowledgeOutput(batch.receipt);
      }
    };
    await drain();
    const turn = await session.run(runOptions);
    await drain();
    const page = await runtime.things.queryPage({}, { pageSize: 100 });
    return { turn, page };
  } finally { await runtime.close(); }
}
