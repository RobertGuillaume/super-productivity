# Portable checkpoint implementation

Streaming source reads and their checkpoint writes share the maintained origin
scheduler. The checkpoint origin requires `maxConcurrent >= 2` and reserves one
slot for checkpoint requests. Queued source requests cannot obstruct that slot,
including while existing bodies drain after adaptive overload reduction. The
configured hard concurrency limit, cooldowns, cancellation and HTTP accounting
still apply. Diagnostics expose `reservedCheckpointSlots`; unrelated origins and
memory/IndexedDB persistence retain their existing scheduling policy.

The development runtime exposes explicit Pod persistence, acknowledged output,
checkpoint-aware turn budgets and resumable cleanup. The complete C3 handoff
remains unqualified until the declared archive fixture and final matrix pass.
These capabilities are unpublished. Start with the public API and failure-handling
walkthrough in [the agent integration guide](AGENT_INTEGRATION.md).

Version-one pages are UTF-8 JSON with a namespace-incarnation binding and a
SHA-256 content address. Page references pin both their hash and byte length.
Leaf pages hold at most 256 ordered entries; branches hold at most 128 children.
Both must fit the configured 64 KiB page limit. Large explicit values use ordered
blob pages. Branch summaries contain entry counts and boundaries so point reads,
range reads and partition counts do not load unrelated records.

The byte cache retains encoded immutable pages and evicts by least recent use.
Its default limit is 64 MiB, including an allowance for keys and cache bookkeeping.
Readers receive independent bytes and decoded values. The cache does not retain
parsed catalog graphs. Materializing one selected value or an unbounded result
still allocates in proportion to that result.

Catalog Things, resource observations, scope markers, discovery work, source
facts, receipts, membership, output and cleanup use versioned primary records.
Their envelope pins table and record identity. Dates and scheduling deadlines use
explicit tagged ISO timestamps; arbitrary RDF lexical forms, languages,
datatypes, source-scoped blank nodes and graph terms remain data. Checkpoints do
not contain fetch functions, credentials, executable closures, binary content or
original source response bodies. Oversized values and unsupported schemas fail
with checkpoint evidence instead of being silently truncated or migrated.

The secondary indexes reuse the catalog's existing semantic candidate tokens and
the discovery journal's existing partition definitions. Source and alias lookup,
RDF classes, inverse links, session membership, ready work, receipts, output and
cleanup therefore use the same interpretation as the memory and IndexedDB
implementations. Ready-work timestamps have a sortable numeric representation in
index keys; their stored scheduling values remain ISO timestamps.

A prepared table change returns a new pair of primary and secondary index roots.
It leaves older roots readable and unchanged. A page-write failure cannot publish
part of the proposed state. The Pod manifest adapter must conditionally publish
the resulting roots before catalog notifications or output delivery become
visible. Immutable pages staged before a failed root commit are cleanup work;
they do not establish a committed observation.

Current evidence: the initial five page/cache/RDF tests and the expanded 17-test
portable-index/catalog suite passed on Node 22.23.2. This does not establish the
100,000-resource archive guarantee or production release qualification. Retained
measurements and outstanding gates are listed in
[the capability report](HEADLESS_INTEGRATION.md).

The internal Pod adapter stores immutable pages in a pre-provisioned checkpoint
container and publishes their roots through a small conditional N3 Patch to
`manifest.ttl`. The root contains one `urn:solid-runtime:checkpoint:manifest`
literal with the canonical JSON manifest. Both create-if-absent and replacement
use N3 Patch; replacements keep the original strong ETag. The 16 KiB root limit
applies to the serialized RDF document, including literal escaping. Immutable
pages remain integrity-checked JSON.
Opening claims a new writer token; conflicts fence the displaced context.
Uncertain root outcomes retain operation evidence and stop mutations until
reconciled. A live writer also retains one bounded archive intent, its exact page
bytes and any unsettled seal when an immutable upload is interrupted. Explicit
reconciliation repeats the same conditional bytes and completes that retained
batch; it never substitutes a fresh precondition. An immediate archive failure
may report `unknown-immutable`, while later blocked mutations report
`unknown-archive`. Root publication remains the visibility boundary for the
shared prepared catalog/discovery effects.

The development boot path is explicit about identity and namespace ownership:

```ts
import { SolidGraphRuntime } from "@solid-intents/runtime";

export async function openArchive(authenticatedFetch: typeof fetch) {
  const runtime = new SolidGraphRuntime();
  await runtime.boot({
    podUrl: "https://pod.example/alice/",
    fetch: authenticatedFetch,
    identity: {
      principalWebId: "https://agents.example/worker#me",
      ownerWebId: "https://pod.example/alice/profile/card#me",
      applicationNamespace: "photo-catalog",
    },
    execution: "explicit",
    persistence: {
      kind: "pod",
      containerUri: "https://pod.example/alice/checkpoints/photos/",
      mode: "open",
    },
  });
  return runtime;
}
```

Provision the checkpoint container and its access policy in the consumer first.
Use `create` once to conditionally create the manifest; use `open` in a new
runtime instance to claim a new writer and restore its state. Neither mode falls
back to memory. Identity assertions do not authenticate the supplied fetch.

Reopening checks the manifest binding and supported versions before claiming
ownership. Catalog pages load on demand; boot does not enumerate all Thing
records. The compatibility cache of recently returned source aliases is capped
at 1,024 entries in Pod contexts, with larger identities resolved from the
persistent index. The checkpoint cache limit is available through
`runtime.diagnostics.status().checkpointLimits`.

The checkpoint container, advertised ACL resources and known type indexes are
excluded from recursive content traversal. Their intentional protocol reads
remain subject to the caller's read scope. Discovering an index pointer does not
grant access to that destination.

Boot, restart and exclusion paths passed the S21 engineering matrix; cleanup
passed the S22 matrix. The final archive and assembled S23/C3 checks remain
separate required gates.


## Explicit maintenance

Run bounded checkpoint maintenance when your application chooses:

```ts
const progress = await runtime.checkpoints.compact({ maxSteps: 16, batchSize: 128 });
// Call compact again while progress.complete is false.
```

The defaults are 16 steps and 128 entries per step. An upload intent is indivisible and contains
at most 128 page references; small intents are combined within that bound. A call
accepts at most 1,000 steps and 128 entries per step. Cancellation and deadlines apply to checkpoint
HTTP. Maintenance never discovers source resources. Its persisted phase and
cumulative deletion counters describe progress; interrupted work resumes from
the checkpoint state in a new process. Calling after a completed cycle begins a
new finite cycle.

Maintenance rebuilds the primary and secondary indexes in bounded batches,
publishes their replacement together, marks the live immutable page graph, then
collects retired pages. A concurrent data revision restarts the unfinished index
rebuild against current data. Catalog cursors are revision-bound and must be
restarted if this publication invalidates them.

Queries and prepared catalog operations pin snapshots before uncached reads.
Maintenance also protects locally admitted snapshots before fixing its mark
boundary. Read-pin releases have immutable evidence, including releases from a
displaced reader. A crashed reader's unreleased pin remains protected; there is
no implicit timeout or distributed lease expiration.

Each allocation journals page-upload intent before uploading those pages. Only
sealed retired allocations are candidates for collection. Unsealed allocations
retain unsettled upload and mutation evidence in a paged index. The
`retainedEpochs` counter reports this retained work; successful cleanup does not
assert that every historical uncertain transport has stopped.

Each deletion batch has an exact claim recorded by a conditional manifest
update. Before dispatching its deletions, the runtime rereads the authoritative
manifest to revalidate writer ownership. A new writer honors that claim. Page
hashes include the allocation identity, so a later writer cannot recreate a
retired deletion target. Repeated deletion after a lost response is safe.
Current catalog facts, incomplete source work, snapshot pins and unacknowledged
output stay reachable throughout cleanup. Cleanup never disposes session output.

An uncertain root publication or retained immutable archive batch stops mutations.
Resolve its exact conditional operation through `runtime.checkpoints.reconcile()`.
The result distinguishes an active writer from one displaced after its commit.
Open a new explicitly bound instance to claim ownership; reconciliation never
silently takes ownership back.

Keep the capability report's failed checks and remaining archive/release gates
alongside any development package. Passing the cleanup matrix does not establish
the archive's memory bound.

Bounded discovery turns count source and checkpoint HTTP, including session
startup, observation publication and progress bookkeeping. Each admitted
conditional checkpoint write reserves its PUT and one confirmation GET. Root
publication protects those requests before uploading remaining pages. A budget
that cannot admit a unit stops before that unit's HTTP dispatch; staged pages
remain unpublished. If final bookkeeping cannot fit, the runtime retains durable
continuation and returns budget evidence with the last available snapshot.
A later explicit run recovers interrupted work and reparses incomplete sources.
An unresolved remote root outcome remains blocked until checkpoint reconciliation;
exhausting a confirmation budget never turns uncertainty into a successful commit.

Portable output delivery and acknowledgement prepare under the context's writer
queue, so continuing source observations cannot indefinitely invalidate a delivery
claim. This queue is local to the bound writer; the manifest's conditional fence
still rejects a displaced writer. Explicit Pod contexts refresh session progress
within active turns and explicit API calls; they do not start checkpoint reads
from idle catalog-notification timers.

Ordered pages may use a versioned, lossless key-prefix encoding and key-suffix
references for repeated index values. Decoding restores exact ordered keys and
RDF values before semantic record validation. Hashes and page-byte limits apply
to the immutable wire representation. Earlier uncompressed version-one pages
remain readable; unknown encoding versions fail explicitly.

A live writer retires its own previously confirmed root-operation proofs during
later commits of the same kind. Data-proof retirement advances the catalog
revision; metadata-proof retirement leaves the catalog roots unchanged. Opening
a new writer does not infer that inherited operations were confirmed. Their
evidence remains available for displaced-writer reconciliation and guarded cleanup.

Output delivery pulls pending journal values only through its selected byte and
observation boundary. It may inspect one additional observation to establish a
byte boundary. Redelivery and acknowledgement stop at the outstanding batch's
last sequence. A portable iterator holds its immutable snapshot until it finishes
or its consumer stops; early return releases its read pin. The byte cache remains
bounded and no complete output backlog is hydrated.


## Root upload interruption

A conditional PUT alone does not make file-backed replacement atomic. On the
qualified CSS 8.0.0-alpha.3 configuration (`storage/backend/file.json` and
`storage/middleware/default.json`), interrupting a streaming JSON PUT can leave a
truncated live document. The root therefore uses conditional N3 Patch, whose
complete syntax is validated before the server applies its change. Interrupted
uploads retain the previous root; lost successful responses are reconciled through
the manifest's existing operation evidence. An unresolved response still stops
further mutation until explicitly reconciled. Immutable payload PUTs retain their
integrity checks. A live writer keeps the bounded byte-identical archive batch
after a lost response and failed confirmation, so caller-directed reconciliation
can confirm or complete it before root publication. They never become committed
through an unconfirmed root.

Draft artifacts through `6d7478f` used `manifest.json` with conditional PUT. That
root format is not automatically migrated. `create` and `open` detect it and fail
with `unsupported-version` and `draft-json-put-root`, preserving all files. Retain
that namespace for explicit recovery with its compatible artifact, or select a new
checkpoint container. The JSON record and observation schemas remain version one;
the mutable root representation is now RDF. A package's full commit and report
identify which root format it supports. The cached CSS storage profile and other
server configurations require their own interruption qualification.
