# Headless integration with the unpublished 2.0 contract

Use a pinned development archive and its SHA-256 report. The declared package
version remains 1.1.1; that version alone does not identify these capabilities.
The report names the exact commit, tested Node/npm versions and selected packed
contract. Repository, archive-memory and production-release qualification are
separate evidence. Production release remains blocked by the upstream dependency
audit. This work does not publish a package or introduce dependency overrides.

## Start with an explicit owner and lifetime

Supply an authenticated fetch. `identity` asserts the principal, data owner and
application namespace; it does not authenticate that fetch or grant access.
The normalized principal, owner, Pod root and application namespace partition
catalog records, work, source aliases, subscriptions and coordination. An instance
cannot change an explicit binding. Restart with a new instance and the same
binding to reopen its state.

Select `execution: "explicit"` for a consumer-owned scheduler. Queries then use
known data without starting discovery. Explicit resource reads remain permitted.
Memory persistence uses no Node storage dependency. IndexedDB is selectable where
available. Pod persistence requires a pre-provisioned checkpoint container and
explicit `create` or `open`; it never falls back to memory. Opening claims a new
writer and restores sessions without running them.

Always await `runtime.close()` in `finally`. Close rejects new work, cancels queued
requests, aborts reads by default and allows dispatched writes to settle. Its
default deadline is 30 seconds. Repeated calls share the same close operation.
A timeout reports unsettled operations and leaves late results fenced. Logout
remains a separate destructive lifecycle action.

The [executable turn example](scripts/examples/portable_agent.mjs) accepts a caller
fetch and an idempotent durable batch consumer. It opens or creates a session,
accepts retained output, executes one bounded turn, accepts newly committed output
and closes the runtime. Import it from the unpacked development archive or copy it
into your application; it imports the runtime's public package entrypoint only.

## Public API map

| Work | Public entrypoint | Network and ownership |
|---|---|---|
| Read exact bytes or RDF | `resources.read`, `resources.readRdf` | Explicit source reads; RDF uses runtime-owned batches and terms |
| Observe type-index pointers | `typeIndexes.discover` | Owner profile and allowed preferences; does not read every advertised index |
| Inspect one index | `typeIndexes.read` | Exact allowed index; unknown classes and unrelated triples remain observable |
| Conditional create or peer POST | `writes.planResourceCreate`, `writes.planResourcePost`, `writes.commit` | Exact destination and serialized payload; no automatic POST retry |
| Conditional replacement/deletion | Existing replacement/deletion planners with `validator` | The caller's original validator survives planning and commit |
| Exact N3 Patch | `writes.planRdfPatch` | Approved serialized bytes; validator or explicit unversioned consent |
| Exact registration publication | `writes.planTypeIndexPatch` | Pinned index, owner, privacy intent, registration IDs, classes and targets |
| Prepare/resume discovery | `discovery.createSession`, `getSession`, `session.run` | One maintained coordinator; explicit continuation and budgets |
| Recheck known members | `session.recheckKnown({ checkedBefore })` | Finite sweep at its preparation revision; preparation does not start execution |
| Consume observations | `session.readOutput`, `acknowledgeOutput` | One outstanding ordered delivery per session, retained until acknowledgement |
| Query known Things | `things.queryPage` | May read missing checkpoint pages; does not discover source resources |
| Maintain checkpoints | `checkpoints.compact`, `checkpoints.reconcile` | Bounded cleanup or exact uncertain-root reconciliation under writer fencing |

Discovery scopes compare container boundaries. Both `allowedOrigins` and
`readScope`, when supplied, apply before original requests and every redirect.
Explicit bindings default discovery to their Pod root and supplied owner-profile
entrypoint; additional external protocol resources require an allowance. Exact
peer writes do not enlarge discovery scope. Private publication intent requires
an appropriately protected destination supplied by the consumer; the runtime does
not create access grants.

Ordinary semantic creation retains automatic, opinionated type-index registration.
Exact publication uses the same RDF interpretation and patch compiler while
preserving the caller's selected destination and registration identities. Unknown
RDF classes need no semantic profile for inspection or exact publication. The
[packed C2 fixture](scripts/fixtures/headless_c2_consumer.mjs) demonstrates this
consumer-owned publication and reconciliation policy.

## Failures and continuation

Writes throw `RuntimeError` or `RuntimeWriteCommitError`. Inspect structured
outcomes and failure evidence instead of parsing messages. A validator conflict
remains a conflict even when proposed bytes equal the current resource. `unknown`
means the remote mutation may have succeeded: preserve its plan and evidence,
then apply your reconciliation policy. In particular, do not resend a POST merely
because its response was lost. Partial multi-operation results retain completed
effects and remaining operations.

Version-four plans pin their effective identity, source binding, payload and
preconditions. JSON round-trips preserve these fields. Explicitly bound contexts
reject unbound version-three plans before HTTP; legacy contexts retain their
existing version-three path. Versions one and two remain unsupported. Do not edit
serialized plans after approval.

`session.run` accepts job, HTTP-request and received-byte budgets. `maxRuns` remains
supported; combining it with `maxJobs` is invalid. Pod checkpoint HTTP counts
against the same turn. An admitted conditional checkpoint unit reserves its write
and first confirmation read. `insufficient-budget` can therefore return before a
unit dispatches. Budget exhaustion or abort preserves committed continuation;
uncommitted source work can require another read on the next explicit turn.
`retry-deferred` includes the next eligible time in the snapshot. `waitForRetry`
selects whether the turn waits for delayed work. Explicit transport defaults to
zero automatic retries.

On the checkpoint origin, Pod persistence reserves one HTTP slot so a streamed
source can persist observations before its body finishes. That origin requires
`requestScheduling.maxConcurrent` of at least two, considering any exact-origin
override. Other origins and memory/IndexedDB contexts retain their existing
one-slot support. Diagnostics report `reservedCheckpointSlots`. Adaptive overload
reduction preserves this dependency slot while already admitted bodies drain;
the configured hard concurrency limit still applies to all requests.

`diagnostics.status().requestScheduling` reports per-origin `dispatchedRequests`
and `retryAttempts`. Dispatch counts include automatic retry attempts; retry counts
exclude later independent requests, queued cancellations and cooldown deferrals.
Read these counters before close when producing an execution report.

`output-blocked` pauses only the affected session. Accept and acknowledge retained
output, then explicitly run it again. Repeated reads return the identical batch,
even if a later read requests a different batch size. Acknowledgements are
idempotent; invalid, wrong-session and wrong-incarnation receipts fail. If a
consumer accepts only part of a batch before failing, deduplicate by observation
ID when it is redelivered. Ordinary cancellation retains unacknowledged output;
session deletion requires explicit output disposal to discard it.

Observations distinguish source identity, attempt identity and namespace-local
sequence. Preserve RDF lexical values, languages, datatypes, blank-node identities
and graph terms. Large facts may arrive as ordered `factFragment` pieces; concatenate
their decoded UTF-8 bytes before parsing the quad. Partial observations and failed
source reads cannot prove removals. Coverage reports the selected type-index,
container or graph boundary; it does not claim a complete Pod inventory or
preservation of remote edits that were never observed.

An unknown checkpoint root or a retained immutable archive upload stops further
mutations until `runtime.checkpoints.reconcile()` resolves its exact conditional
operation. The immediate failure may report `unknown-immutable`; later attempts
report `unknown-archive`. Both retain the same byte-identical operation for an
explicit reconciliation, without an automatic HTTP retry.
Writer displacement stops admission and requires a new instance to explicitly
claim ownership. No lease timeout, automatic takeover or cross-writer merge is
implied. Read [portable checkpoint mechanics and limits](PORTABLE_CHECKPOINTS.md)
for snapshot retention, immutable allocation journals and resumable cleanup.

## Limits and compatibility

| Bound | Default |
|---|---:|
| Root manifest | 16 KiB |
| Immutable page | 64 KiB and 256 entries |
| Branch fan-out | 128 children within the page limit |
| Resident checkpoint/catalog byte cache | 64 MiB |
| Delivery batch | 100 observations or 256 KiB |
| Pending output per session | 128 MiB |
| Source body | 32 MiB |
| Expanded source observation | 64 MiB |
| Catalog query page | 100 Things; maximum 1,000 |

Limits are configurable and reported by diagnostics. Source-limit failures retain
prior authoritative knowledge and report incomplete evidence. The cache bound
covers retained checkpoint state; materializing a large value or an unbounded
query still allocates proportionally to returned data. A query cursor pins a
catalog revision and fails if that revision is invalidated.

Existing browser boot/auth flows keep their defaults and legacy databases. There
is no automatic import of unattributed browser cache records into explicit identity
partitions. Portable checkpoint and observation records use version one; unsupported
versions require an explicit migration and fail with diagnostics. Draft JSON PUT
roots (`manifest.json`, through commit `6d7478f`) are explicitly rejected and
retained. Current roots use conditional N3 Patch on `manifest.ttl`; the 16 KiB root
limit includes its RDF serialization. Checkpoints
contain parsed facts and continuation, never credentials, original source bodies,
fetch capabilities, closures or a required local database.

## Reproduce the evidence

From a pinned source checkout with the declared dependencies and supported Node 22
and npm 10 installed:

```sh
npm run test:agent:contract -- --bundle C1
npm run test:agent:contract -- --bundle C2
npm run test:agent:contract -- --bundle C3
npm run test:agent:archive
npm run verify
```

Packed consumers install only the archive and its declared dependencies into an
isolated directory. The C3 consumer tests the public persistence/output contract;
it does not replace the separate 100,000-resource archive-memory gate. The archive
harness keeps its generated source fixture and acceptance storage outside the
measured runtime processes. Reports retain failures and missing measurements.
See [the capability and qualification report](HEADLESS_INTEGRATION.md) for exact
runs, outstanding gates and the separate production release blocker.

For a local archive fixture with limited disk space, use
`npm run test:agent:archive -- --backend gzip-file`. This compresses only files
held by the fixture server outside the measured runtime. Source generation,
checkpoint HTTP payloads, validators, request accounting and runtime limits are
unchanged. Reports distinguish logical `checkpointBytes` from encoded fixture-file
`checkpointStorageBytes` and include each peak. The stored-byte counters exclude
filesystem allocation and directory overhead. The default `file` backend keeps
uncompressed fixture files; neither backend changes the runtime's Pod adapter.
