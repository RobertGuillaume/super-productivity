# Headless operations and portable discovery

Implementation baseline: `61638fb`. This work extends the unpublished 2.0 contract.
The existing upstream production audit remains a release gate. Contract tests do
not qualify a package for production or authorize publishing.

## Current qualification — 2026-09-11

The current committed implementation is `5b8ffe20bf74dfdddc1d6f38f2af6068fd369870`.
Its isolated C1–C3 consumers and shipped public example passed on Node 22.12.0
with npm 10.9.0 and Node 22.23.2 with npm 10.9.8. Both clean-source archives
contain 438,217 identical bytes, SHA-256
`aaec00c3de4815642f976701497fb989413036ead011a5fc6c9cf8ab8beb6928`.
The [artifact index](../../artifacts/README.md) identifies the packages and their
machine-readable evidence.

The checkpoint-capacity correction passed its repository qualification. A separate
2,000-member diagnostic confirmed that `maxConcurrent: 1` deadlocked a streamed
source waiting for a queued checkpoint write. The correction reserves one slot
on the checkpoint origin, requires at least two slots there, and preserves the
reservation when an adaptive reduction is below the number of retained source
bodies. Other origins and memory/IndexedDB scheduling retain one-slot support.
Build and all 43 focused transport/public-Pod checks passed. The real CSS case
passed in 52.78 seconds. Its first run only prepared the graph dependency because
the fixture admitted one job; the corrected fixture executes that dependency
and asserts exactly one source read, with the same timeout. The full regression
matrix and both pinned consumers passed. The current archives include this fix. A supplemental
20-resource archive also passed the stronger assertion that the first resumed
delivery preserves the unacknowledged receipt and batch content (42.40 seconds,
223,801,344 bytes peak RSS). The full archive remains a separate required gate.

The corrected repository matrix passed build, packed baseline, strict public
declarations, 1,008 unit tests, 81 real CSS tests, two CSS performance tests,
18 Chromium/Firefox tests and all discovery performance stages. The supported
dependency audit still blocks production release with six findings: five moderate
and one high. No dependency override, waiver or publication is introduced.

Portable roots now use conditional N3 Patch and the `rdf-manifest-v1` format.
Real CSS tests cover live upload interruption, lost successful responses and stale
validators. Earlier draft JSON roots are rejected without migration or deletion;
the retained packages through `6d7478f` predate this correction.

The clean `5b8ffe2` 100,000-resource archive ran for 17,085,954.28 ms and retained
complete measurements, but failed after 6,166 terminal sources when an immutable
archive upload response and its first confirmation could not establish the remote
outcome. Peak runtime RSS was 406,355,968 bytes, within the 512 MiB bound. The
initial listing completed in 447,199.32 ms with 293,474,304 bytes peak RSS, first
output at 959.02 ms and first publication at 1,477.10 ms. Restoration made no
source reads, 91 finite rechecks ran, an edited known resource was observed before
completion, and seven compaction cycles completed. Traffic before failure included
2,268,651 checkpoint PUTs, 2,516,354 GETs and 2,009,371 DELETEs, with zero automatic
HTTP retries. The retained result does not qualify S23 because final catalog,
health-recovery and compaction checks did not run.

The correction under qualification retains one bounded byte-identical archive
batch and exposes its replay through `runtime.checkpoints.reconcile()`. It does not
add an automatic transport retry. The build and all 52 focused persistence tests
pass. A deterministic 20-resource, two-process gzip-file diagnostic lost a page
PUT response and the first confirmation read; the consumer explicitly reconciled
it and finished with zero automatic retries, no fixture server errors and
207,970,304 bytes peak RSS. A fresh full archive remains required for S23–S24.
The dated entries below preserve earlier failures and corrections;
their historical pending statuses do not supersede this current status.

## Capability at the starting commit

| Original requirements | Existing support | Remaining work |
| --- | --- | --- |
| R01 | Packed Node CRUD, declarations, browser build and supplied-fetch fixture | C1–C3 qualification |
| R02 | Supplied fetch; stable discovery identity key | Principal/owner/application binding and complete cache isolation |
| R03 | Awaited session pause/cancel | Runtime close; queued/request/body cancellation |
| R04 | Raw reads, conditional replacement/deletion, container operations | Original validators, conditional raw create, POST, exact N3 Patch, unknown outcomes |
| R05–R06 | Preferences discovery, raw internal class facts, pinned semantic registration | Public raw RDF and exact private index operations |
| R07–R09 | Atomic IndexedDB/memory journal and cleanup | Portable records, guarded Pod manifests and compaction |
| R10 | Snapshot notifications and internal observation receipts | Lossless acknowledged output |
| R11 | Resumable sessions, fair dispatch and truthful coverage | Request/byte budgets, deferral and finite known-resource sweeps |
| R12 | Bounded expansion and origin guards | Streaming source parsing and path scopes |
| R13 | 10,000-resource and browser qualification | 100,000-resource portable archive and artifact matrix |

Run `npm run test:agent:contract -- --bundle baseline`. This builds and installs a
packed package outside the workspace, with only the runtime as a consumer
dependency. It exercises supplied-fetch native creation, custom views, raw
conditional updates/deletion and explicit discovery. At the starting commit,
plain Node lost catalog and continuation state at process exit. The implementation
now supplies optional Pod persistence and packed C1, C2 and C3 consumer contracts.
The C3 packed consumer has passed on both supported Node versions; the separate
100,000-resource archive gate is still in progress. See the slice ledger and
dated measurements below before relying on a handoff's qualification status.

## Fixed implementation contracts

- Explicit identity binds principal WebID, owner WebID, Pod root and application
  namespace; it is a host assertion, not a credential. Explicit contexts do not
  import legacy Pod-only caches or rebind identities.
- Existing browser flows stay compatible. Explicit execution disables implicit
  discovery. Close preserves durable work; logout remains separate.
- New version-four plans pin identity and exact HTTP intent. Legacy contexts
  continue to validate version-three plans; bound contexts reject unbound plans.
- One coordinator and semantic interpretation system serve all backends.
- Optional Pod persistence is authoritative, with bounded immutable JSON pages,
  guarded root commits and writer fencing. Queries may load checkpoint pages,
  never implicitly crawl sources. No required host database is introduced.
- Output is ordered, lossless and acknowledged; a full backlog pauses its session.
  Source completeness, inaccessible resources and ambiguous writes remain visible.
- Default limits: 16 KiB root; 64 KiB/256-entry pages; 128-child branches; 64 MiB
  resident cache; 100 observations/256 KiB delivery; 128 MiB backlog; 32 MiB source
  response; 64 MiB expanded observation. Oversize inputs fail without implying loss.
- Hosted identity provisioning, grants, jobs, SQLite queues and publication policy
  remain consumer responsibilities. No forks, overrides or audit waivers.

## Slice ledger

Each slice carries tests, documentation and qualification evidence. Required
verification is `npm run verify`; if an audit short-circuits it, run all unaffected
unit, CSS, browser and performance gates independently. Record failures before a
commit. Keep the pre-existing README changes out of implementation commits.

| Slice | Deliverable | Status |
| --- | --- | --- |
| S01 | Supplied-fetch packed baseline and capability mapping | Implemented; engineering baseline passed, release blocked |
| S02 | Full principal/owner/application isolation | Implemented; engineering checks passed, release blocked |
| S03 | Cancellable, deferrable transport | Implemented; engineering checks passed, release blocked |
| S04 | Path-aware discovery scope | Implemented; engineering checks passed, release blocked |
| S05 | Awaited runtime close | Implemented; engineering checks passed, release blocked |
| S06 | Original validators and version-four plans | Implemented; engineering checks passed, release blocked |
| S07 | Exact raw create and POST | Implemented; engineering checks passed, release blocked |
| S08 | Conditional N3 Patch | Implemented; engineering checks passed, release blocked |
| S09 | C1 packed artifact and qualification | Implemented; engineering checks passed, release blocked |
| S10 | Owner-bound raw RDF/type-index observations | Implemented; engineering checks passed, release blocked |
| S11 | Exact private registration batches | Implemented; engineering checks passed, release blocked |
| S12 | C2 packed artifact and qualification | Implemented; engineering checks passed, release blocked |
| S13 | Prepared catalog effects and atomic persistence seam | Implemented; engineering checks passed, release blocked |
| S14 | Pull-based RDF/body parsing and bounded staging | Implemented; engineering checks passed, release blocked |
| S15 | Atomic complete source generations and replay | Implemented; engineering checks passed, release blocked |
| S16 | Acknowledged observation output and backpressure | Implemented; engineering checks passed, release blocked |
| S17 | Bounded turns and fair finite rechecks | Implemented; Pod HTTP admission/confirmation budgets checked in S23; full C3 qualification pending |
| S18 | Portable immutable indexed pages and codec | Internal foundation checked; retained CSS rerun evidence, release blocked |
| S19 | Guarded Pod manifest commits and fencing | Internal adapter checked; retained restoration rerun evidence, release blocked |
| S20 | Paged catalog queries and bounded cache | Implemented; S20 timing failure retained, release blocked |
| S21 | Public Pod persistence create/open | Implemented; engineering matrix passed, C3 qualification pending |
| S22 | Resumable compaction and safe cleanup | Implemented; build, packed/declarations, 968 unit, CSS, browser and performance pass; upstream audit blocks release |
| S23 | Process/CSS recovery and 100,000-resource archive | Implementation and repository matrix passed; 100,000-resource qualification remains open |
| S24 | Complete C1–C3 artifacts, docs and release evidence | Public guide/example and C3 packed consumers pass on minimum/current Node; immutable final handoff pending |

## S01 qualification — 2026-09-09

Node 22.23.2, npm 10.9.8, macOS x64. Build, isolated baseline contract (13 HTTP
requests), packed Node/declaration/browser smoke checks, 756 unit tests, 73 CSS
integration tests, two CSS performance tests, 18 Chromium/Firefox tests and the
discovery performance gate (including 46 focused regression tests) passed.
`git diff --check` passed. The baseline contract is included in `verify`.

`npm run verify` stopped at the isolated consumer production audit: six upstream
vulnerabilities, five moderate and one high. The workspace production audit
reported five, four moderate and one high. The Soukai dependency chain remains
blocked; no overrides, dependency substitutions or audit waivers were added.
All stages after the smoke audit were run independently and passed.

The unchanged 10,000-resource discovery fixture completed in 59.3 seconds, with
first ten results at 503 ms, 10,001 Pod reads, at most 12 materialized jobs and
230,711,296 bytes RSS. This is the existing memory fixture, not C3 archive
qualification. An initial sandbox run failed because the default npm cache was
not writable; the isolated install passed using a writable temporary cache. An
initial overlapping unit run was stopped after timing failures; the sequential
run passed all 756 tests without changing tests or thresholds. Minimum-Node
handoff qualification remains due at S09. No package was published.

## S02 qualification — 2026-09-09

Build, focused identity/persistence tests, packed baseline and consumer smoke,
73 CSS integration tests, two CSS performance tests and all 18 browser tests
passed on Node 22.23.2/npm 10.9.8. The unit run passed 764/765 tests; the native
inspection test exceeded its 15-second timeout. The discovery benchmark passed,
but two final regression tests exceeded their 5/30-second timeouts. All three
passed on a targeted sequential rerun with unchanged thresholds. Their initial
failures are retained in the qualification record. No required test was disabled.
The 10,000-resource run used 236,748,800 bytes RSS, returned its first ten results
at 339 ms and completed in 29.6 seconds with 10,001 Pod reads. `verify` remains
blocked by the isolated consumer audit (six vulnerabilities); the workspace audit
reports five. All unaffected stages were executed independently. No production
qualification or C1 bundle is claimed. `git diff --check` passed.

## Explicit headless contexts

```ts
await runtime.boot({
  podUrl: "https://pods.example/alice/",
  fetch: authenticatedFetch,
  identity: {
    principalWebId: "https://agents.example/archiver#me",
    ownerWebId: "https://pods.example/alice/profile/card#me",
    applicationNamespace: "photo-archive",
  },
  execution: "explicit",
  persistence: { kind: "memory" },
});
const session = await runtime.discovery.createSession({
  targets: [{ kind: "type", type: "Image" }],
});
await session.run();
```

Identity is an immutable caller assertion; it does not authenticate the fetch.
The owner controls owner-based type discovery and automatic registration. Each
principal/owner/Pod/application tuple gets its own catalog, continuation, aliases,
known containers and ownership channel. IndexedDB uses a new namespace and checks
the persisted binding before loading records. Legacy browser databases remain
available to legacy callers and are never adopted by explicit contexts.

`execution: "explicit"` prevents query-triggered discovery even when a query asks
for `autoDiscover`. Explicit resource reads and session execution remain available.
`persistence: { kind: "memory" }` prevents local catalog and known-container
persistence. `indexeddb` requires IndexedDB; `auto` retains the environment's
existing selection. No Pod backend is exposed yet. Restart with a new instance
and the same binding to restore IndexedDB state. Changing a bound instance's
identity or using its interactive authentication methods fails. Hosted instances
always use their supplied fetch.

## S03 qualification — 2026-09-09

Node 22.23.2/npm 10.9.8, macOS x64. The corrected build, packed baseline and
smoke consumer checks passed up to the mandatory production audit. Independent
checks passed: 774 unit tests, 73 CSS tests, two CSS performance tests, all 18
Chromium/Firefox tests, and the discovery performance gate including 46 catalog
regression tests. The 10,000-resource run used 236,040,192 bytes RSS, returned the
first ten results at 556 ms, completed in 43.4 seconds, and made 10,001 Pod reads.
`git diff --check` passed. C1 remains unqualified until its full handoff.

The initial run found an error-cause wrapping regression and browser streams on
204/304 responses that could not be wrapped as body-bearing Responses. Both were
fixed and the complete engineering matrix rerun. The original unit run also had a
15-second native-view timeout; it passed in the corrected full run without a
threshold change. The initial browser run had six failures, and the corrected
run passed all 18. Logs retain failed runs and fixes. `verify` and the independent
production audit remain blocked by the same upstream dependency chain: six
vulnerabilities in the isolated consumer, five in the workspace. No audit waiver,
override, publishing or version change was introduced.

## Cancellation and transport

Resource reads, metadata, previews, container listings and discovery session runs
accept an `AbortSignal` and an absolute `deadline: Date`. Cancellation removes
queued work, interrupts scheduling waits and reaches response body consumption.
Dispatched requests remain counted through body consumption or cancellation. A
supplied fetch that ignores cancellation remains counted until it settles; its
late response is discarded. Aborted discovery retains work for an explicit resume.

Explicit execution defaults to zero HTTP retries. A request for an origin already
cooling down fails with `failure.reason: "deferred"`, a queued phase and `retryAt`,
without sending HTTP. The initial 429 still reports `rate-limited`. Automatic
execution keeps its adaptive scheduling defaults. POST is never retried by the
transport, even when its origin policy permits retries. Read failures include
dispatch/body phase evidence when available; deadlines report `deadline-exceeded`.

```ts
const controller = new AbortController();
const body = await runtime.resources.read(sourceUri, {
  signal: controller.signal,
  deadline: new Date(Date.now() + 10_000),
});
```

## Discovery read scopes

Bound contexts default discovery and automatic type-index protocol reads to their
Pod root and the exact owner profile document. Preferences and indexes elsewhere
require an explicit allowance. Set a default with `boot({ discovery: { readScope } })`
or select a session's complete scope when creating it:

```ts
const readScope = {
  allowedContainerRoots: ["https://pods.example/alice/"],
  allowedResources: ["https://identity.example/card", "https://identity.example/preferences"],
  excludedContainerRoots: ["https://pods.example/alice/scratch/"],
  excludedResources: ["https://pods.example/alice/ignored.ttl"],
};
const session = await runtime.discovery.createSession({
  targets: [{ kind: "type", type: "Image" }], readScope,
});
```

Explicit scope replaces the default; include all desired protocol entrypoints.
Exclusions take precedence over allowances. `allowedOrigins`, when supplied,
applies in addition to the path scope. Resource exceptions refer to HTTP documents;
fragments do not grant separate per-Thing access. The runtime checks the original
destination and every manual redirect, compares container boundaries, rejects
ambiguous encoded separators and fails explicitly on opaque redirects. The
session snapshot reports its persisted scope. Cached session queries and source
reuse respect that scope. Denied sources cannot establish complete coverage.

Legacy callers retain unrestricted cross-Pod discovery unless they select a
scope. Explicit resource/peer operations retain their own destinations; they do
not enlarge discovery scope. Raw reads, metadata and listings also accept an
optional `readScope` and `allowedOrigins` for a caller-selected boundary.

## S04 qualification — 2026-09-09

Build, diff checks, the packed baseline and Node/declaration/browser smoke checks
passed on Node 22.23.2 / npm 10.9.8, macOS x64. All unaffected gates passed:
780 unit tests, 73 CSS tests, two CSS performance tests, 18 Chromium/Firefox
browser tests and the discovery benchmark plus 46 catalog/discovery regressions.
The 10,000-resource run completed in 29.25 seconds, with first ten results at
344.58 ms, 10,001 Pod reads, at most 13 materialized jobs and 268,021,760 bytes
RSS. The performance run was isolated from this task's builds and focused tests.

`verify` remains blocked at the isolated consumer audit (six upstream findings:
five moderate, one high); the independent workspace production audit reports
five findings (four moderate, one high). No audit waiver, override or release
qualification is introduced. The earlier focused owner-profile assertion was
corrected to permit both HEAD and GET of the same allowed protocol resource;
forbidden destinations still receive no request.

## Closing a runtime context

`await runtime.close()` immediately closes admission, cancels queued requests,
aborts reads by default, and waits up to 30 seconds for admitted operations and
physical requests to settle. Pass `{ abortReads: false, timeoutMs: 5000 }` to let
already dispatched reads finish within a different deadline. Dispatched writes
are allowed to settle; post-write source refresh is deferred by marking the
catalog stale. Close unsubscribes watchers, revokes previews, releases discovery
ownership, and closes local database connections. It does not log out or delete
catalogs, continuation, or registrations.

All calls share one shutdown operation. A timeout throws `RuntimeError` with code
`runtime-close-timeout` and `details.unsettled`; dispatched mutations without a
confirmed completion carry an `unknown` outcome. This failure does not reopen the
context. A supplied fetch that ignores cancellation remains physically unsettled
until it finishes, and its late result cannot publish or persist. Create another
runtime with the same identity to reopen durable work. Session snapshots remain
readable after close; session operations and new runtime work reject as closed.

S05 focused checks cover frozen session handles, isolated shutdown, persistent
reopening, queued and noncooperative reads, dispatched writes, timeout evidence,
late catalog/journal rollback in both stores, and watcher draining. An initial
boundary fixture named a nonexistent journal store; it was corrected to the
existing observations store, and the corrected boundary tests passed. Full S05
qualification remains pending.

The semantic index fixture now supplies an explicit owner binding rather than
replacing the public auth state method. Six failures exposed that fixture's
reliance on an internal call through the public facade after lifetime admission
was separated; its seven index scenarios pass with the real identity contract.

## S05 qualification — 2026-09-09

Build, diff checks, packed baseline/smoke and the independent CSS, browser and
performance gates passed on Node 22.23.2 / npm 10.9.8, macOS x64. The full unit
run passed 789 of 790 tests; the native-view diagnostic scenario hit its existing
15-second timeout. Its unchanged, isolated rerun passed both tests in that file
(6.1 seconds of test execution). No timeout or threshold was changed. The full
CSS suite passed 73 tests, CSS performance passed two, Chromium/Firefox passed
18, and discovery performance plus 46 catalog/discovery regressions passed.

The 10,000-resource run completed in 68.35 seconds with first ten results at
715.15 ms, 10,001 Pod reads, at most 13 materialized jobs and 237,862,912 bytes
RSS. Both the failed unit log and successful rerun are retained. `verify` still
stops at the isolated consumer audit (six upstream findings, five moderate and
one high); the independent workspace audit reports five (four moderate, one
high). These are development engineering results, with production release
blocked by the supported upstream dependency gate.

## Version-four write plans and original validators

New `writes` planners return `RuntimeBoundWritePlan` (version four), including the
normalized effective identity and an ordered `http` description of each mutation:
operation index, method, destination, media type, serialized payload and headers.
Semantic operations retain their source binding and payload validation. Plans
serialize through JSON without credentials or runtime objects. Body or HTTP
intent drift, profile drift and identity drift fail before mutation. Legacy
contexts continue accepting version-three plans; explicit contexts reject them
before any HTTP. Versions one and two require replanning.

Supply `validator: { kind: "etag", etag }` or the existing `last-modified`
validator when planning replacement or deletion from an earlier read. Metadata
reads never substitute a newer validator. For semantic plans this validator pins
the main RDF source, or the sole content update when no RDF changes are planned;
other resources keep independently reviewed validators. Version-four raw writes
honor the precondition even when the current bytes equal the proposed bytes.
Version-three raw replacement retains its historical already-satisfied path.

A conflicting reviewed semantic source throws `write-plan-conflict` with evidence
from the read that detected it. Mutation errors still throw
`RuntimeWriteCommitError`, retaining completed and pending operation outcomes.
Failures expose kind, dispatch phase, HTTP status, retry deadline and Location
when available. Lost dispatched mutation responses carry `unknown`; a failed
preflight remains not-sent. Mutation redirects are returned for explicit handling.
Raw reconciliation follows the recorded HTTP outcome, so failed reconciliation
cannot erase a confirmed effect. A Location value is preserved as returned by the
server, and may be relative to the operation destination.

S06 focused evidence includes five envelope/validator/unknown-outcome scenarios,
existing raw and semantic operations, and legacy version-three reuse. The initial
101-test focused run passed; the stricter conflict diagnostic required updating
two old expectations. A later typed-update run exceeded its existing five-second
time limit while other checks were active. The complete S06 unit suite subsequently
passed, including typed updates. Bundle qualification remains separate.

## Exact creation and peer POST

`writes.planResourceCreate(uri, { body, mediaType })` pins a conditional PUT with
`If-None-Match: *`. Planning sends no HTTP, and a competing creation produces a
conflict rather than overwriting the resource. Raw creation updates the local
catalog through the existing resource reconciliation path; it does not invent a
semantic profile or automatically register the raw resource in a type index.

`writes.planResourcePost(destination, { body, mediaType, slug? })` pins one POST to
the explicit destination, including a peer outside discovery scope. The destination
may include a query string. Text and JSON are supplied as strings; binary bodies
use the existing Blob/ArrayBuffer/Uint8Array inputs. JSON round-trips retain the
approved bytes. `result.destination` identifies the requested endpoint and
`result.location` preserves the server's Location, when present. The runtime does
not follow Location or start discovery after a POST.

Mutation redirects are not followed. Redirect evidence includes its status and
Location where visible, with an unknown outcome because redirected mutation
effects have not been established. A lost POST response also remains unknown;
no automatic retry occurs, even under automatic scheduling with retries enabled.
Calling commit again is an explicit new attempt and can duplicate an accepted
POST. The consumer owns reconciliation and any application idempotency keys.

S07 focused checks passed six exact-operation scenarios and three real CSS
scenarios, including byte preservation, a create race, and a lost successful POST
response. The first unit assertion compared typed arrays from different realms;
it was corrected to compare bytes and media type separately. The first CSS server
exceeded its existing 90-second startup deadline without reporting an error; an
unchanged rerun passed all three scenarios. No timeout or required test was
removed. Full slice verification and C1 qualification remain pending.

## Exact N3 Patch and write execution (S08)

`writes.planRdfPatch(uri, { body, validator })` pins a normalized destination,
`PATCH`, `text/n3`, the exact serialized N3 body and the original validator. An
unversioned patch requires `allowUnversioned: true`. Planning and commit validate
the supported [Solid N3 Patch structure](https://solidproject.org/TR/protocol#n3-patch):
one patch resource, at most one nonnested formula per clause, no blank nodes in
insertions/deletions, and variables bound by the conditions. Unrelated source
triples are retained by the patch's specified effects. The runtime never rewrites
an approved patch body or replaces its validator with a new read.

The supported subset excludes extra statements outside the patch description,
quantifier directives, nested formulae and explicit empty formulae that the
installed parser cannot represent correctly. Omit empty clauses. This parser
limitation is reported before HTTP; it is not hidden with a dependency override.
Existing version-three semantic/SPARQL plans keep their compatibility path.

`boot({ patchLimits: { bodyBytes, expandedBytes, quads } })` configures positive
integer limits, reported by `diagnostics.status().patchLimits`. Defaults are
1 MiB of serialized UTF-8, 8 MiB of expanded term data and 50,000 quads. The parser
charges expanded terms before retaining each quad. `write-patch-limit` errors
identify the exceeded limit and maximum. These patch limits are separate from
the later discovery source and portable-state limits.

All asynchronous write planners accept cancellation/deadlines through their
planning options (or through the raw input). `planCreate(input, options)` and
`planContainerCreate(uri, options)` accept separate operation options.
`writes.commit(plan, { signal, deadline })` snapshots the reviewed plan and owns
one execution context through preflight, dispatch, response consumption and
reconciliation. Concurrent operations do not share mutable cancellation state.
A confirmed mutation remains completed if subsequent reconciliation is cancelled;
an interrupted dispatched mutation can have an unknown outcome. Shutdown and
caller cancellation retain their separate policies.

```ts
const plan = await runtime.writes.planRdfPatch(sourceUri, {
  body: approvedN3,
  validator: { kind: "etag", etag: originalEtag },
  signal: controller.signal,
});
await runtime.writes.commit(JSON.parse(JSON.stringify(plan)), {
  signal: controller.signal,
  deadline: new Date(Date.now() + 15_000),
});
```

S08 is in engineering qualification. The initial six patch tests exposed the
installed parser's empty-formula issue. A 42-test run exposed lost cached index
diagnostics after introducing scoped transports; the corrected 19-test rerun
passed. Two CSS runs accepted raw create and N3 Patch but exposed an erroneous
interruption check on ordinary 404 responses; the check was corrected and a
missing-container planning regression was added. The broader affected suite
passed 138 of 140 tests; the two legacy deletion replay fixtures were updated to
explicitly use version three, with a separate version-four conflict assertion.
All failed logs remain in the qualification record. Full verification and the
C1 packed handoff are still required before claiming the bundle complete.

The corrected affected checks pass (62 write/context/catalog tests and 79 runtime
scenarios, including the targeted correction to the new conflict assertion).
The corrected real CSS run passes all four raw-operation scenarios, including
N3 insertion, deletion and combined conditional patches. Build and diff checks
pass. The initial new conflict assertion also needed to include the still-pending
index operation; that failure is retained with the earlier test records.

## C1 packed consumers and development archives (S09)

Require C1 explicitly with `npm run test:agent:contract -- --bundle C1`. The
command builds a package, installs it outside the workspace with declared
production dependencies, and runs the baseline and C1 consumers using only
public runtime imports. C3 selections fail until that contract is implemented. The fixture checks
two principals, two owners, two path-based Pods and distinct application
namespaces; owner selection, guarded redirects, explicit reads, raw byte
preservation, create races, original validators, N3 transport, exact peer POST,
unknown outcomes, cancellation, close and version-three compatibility are
executable assertions. Real CSS separately qualifies N3 patch application.

Both consumers are included in the packed archive. After installing a pinned
archive, run `node node_modules/@solid-intents/runtime/scripts/fixtures/headless_c1_consumer.mjs`.
The fixture supplies its own in-memory transport; hosted authentication and grant
provisioning remain the consumer's responsibility. The fixture's memory mode
intentionally has no cross-process restoration promise.

To retain an immutable development archive, use a clean checkout of the desired
source commit and run:

```sh
npm run test:agent:contract -- --bundle C1 --artifact-dir /tmp/runtime-artifacts
```

The archive, SHA-256 file and JSON report use the exact source commit, package
version, requested bundle and Node version in their names. Existing files cannot
be overwritten with different contents. Artifact creation rejects a dirty
checkout. Ordinary development checks may run against uncommitted changes and
report `workingTree: true`; these are not exact-commit handoff artifacts.

Reports distinguish isolated packed-consumer results from the complete
engineering matrix and production release qualification. The package remains
`1.1.1`; its version alone does not imply published headless capabilities. No
package is published by these commands. Full qualification still requires the
supported Node matrix, all affected runtime/browser/CSS/performance checks and a
passing upstream production audit before any production release.

The Node 22.23.2 / npm 10.9.8 C1 development check passed with 25 fixture HTTP
requests and no automatic POST replay. An initial fixture assertion incorrectly
required duplicate close calls to return the identical Promise object; the
corrected check verifies the same shutdown result and unsettled evidence. The
original failing log is retained. Node 22.12.0 / npm 10.9.0 also passed the same
25-request C1 fixture. Final pinned artifacts and the full handoff matrix remain
pending.

## Raw RDF and selected type-index observations (S10)

`typeIndexes.discover(ownerWebId, options)` reads the owner's profile and linked
preferences documents, returning public/private index pointers, source validators
and the actual RDF statement establishing each pointer. It does not fetch the
advertised indexes. Protocol traversal is cycle guarded and defaults to at most
32 documents (`maxDocuments`); unavailable, malformed or limited observations
report `complete: false` with failure evidence. Cancellation and deadlines remain
operation failures. The context's path and origin guards apply throughout.

`typeIndexes.read(indexUri, options)` reads exactly the selected index, returning
all registration identities, classes, instance/container targets, source metadata
and RDF statements. Unknown classes require no semantic profile. Blank-node and
typed-only registrations, fragments, neighbouring statements and literal lexical
forms remain observable. `source.uri` is the actual response destination when the
transport supplies it; `requestedUri` retains the original request. No vocabulary
fetches or automatic public-index fallback occur.

`resources.readRdf(uri, options)` returns an asynchronous sequence of version-one
batches. Terms are runtime-owned plain data with `termType` and `value`; literals
also retain language and datatype, blank nodes carry a per-read scope, and quads
retain their graph. The terminal batch has `complete: true`; earlier batches
cannot establish removal. Breaking iteration releases its lifetime admission.
Close cancels active readers by default, including body consumption; an admitted
reader may drain when closing with `abortReads: false`.

```ts
const pointers = await runtime.typeIndexes.discover(ownerWebId);
const chosen = pointers.links.find((link) => link.privacy === "private");
if (!chosen) throw new Error("The owner has no observed private index pointer");
const index = await runtime.typeIndexes.read(chosen.uri);
for (const registration of index.registrations) {
  console.log(registration.identity, registration.classUris);
}
for await (const batch of runtime.resources.readRdf(chosen.uri)) {
  consumeRdf(batch.quads, batch.complete);
}
```

Turtle, TriG, N-Triples, N-Quads and N3 share the same source parser and type-index
fact extraction used by semantic registration, diagnostics and discovery. The
public declarations expose no N3, Soukai or Node stream types. S10 initially
materialized sources internally. S14 replaces that implementation with pull-based
parsing; archive memory bounds still require the assembled C3 qualification.

S10 focused checks passed 71 tests, including preferences-only links, independent
private-index access, unknown classes, blank nodes, source provenance, protocol
scope, cycles, literal/graph preservation and iterator shutdown. The first build
found missing RDF error declarations and a parser type mismatch; both were fixed
without changing dependencies. Full verification and C2 qualification remain
pending.

## Exact registration publication (S11)

`writes.planTypeIndexPatch(indexUri, input)` plans one conditional `text/n3` PATCH
to the selected, existing index. Input pins `ownerWebId`, `privacy`, registration
changes and optional RDF marker insertions/deletions. An explicitly bound runtime
requires its own owner. Planning reads only the selected index through the
protocol scope guards; an unavailable destination fails without selecting another
index or skipping a class. Redirected index reads report the observed destination
and require the caller to select it explicitly before planning a write.

Privacy intent specifies the caller's required destination policy. The caller
must provision suitable protection; the runtime neither verifies that protection
from an RDF privacy label nor creates grants. Registration identities and target
URIs are supplied by the caller. No semantic profiles or publication ownership
policy are inferred.

The structured operations have precise effects:

- `register` inserts `TypeRegistration`, the supplied `classUris`, and supplied
  instance/container `targets`. Existing other classes and targets are retained.
- `unregister` removes only the supplied targets, preserving other targets and
  registration metadata.
- `reclassify` removes `removeClassUris` and inserts `addClassUris` on the selected
  registration. This changes classification for all its remaining targets.
- `markers` inserts/deletes the supplied default-graph RDF triples. Literals
  preserve lexical values, language and datatype; unrelated triples survive.

Structured changes require named registration/marker subjects. Observed blank
registrations remain accessible through the RDF API and can be changed with an
exact N3 Patch using explicit `where` variables. Unsupported structured terms
fail before HTTP. This restriction never silently discards unknown RDF.

Plans retain the observed source hash, original validator, structured intent,
exact insertions/deletions and compiled body. Commit recompiles and checks both
payload and intent hashes. Changing owner, privacy, registration identity, marker
or destination requires a new plan. A supplied stale validator conflicts during
planning; commit uses that same validator and never substitutes a fresh one.
Without a supplied validator, planning selects a supported source validator;
absence requires explicit `allowUnversioned: true`.

```ts
const observed = await runtime.typeIndexes.read(privateIndexUri);
const plan = await runtime.writes.planTypeIndexPatch(privateIndexUri, {
  ownerWebId,
  privacy: "private",
  validator: { kind: "etag", etag: observed.source.metadata.etag! },
  changes: [{
    kind: "register",
    registrationUri: `${privateIndexUri}#my-publication`,
    classUris: ["https://example.org/UnfamiliarType"],
    targets: [{ kind: "instance", uri: observedThingUri }],
  }],
});
await runtime.writes.commit(JSON.parse(JSON.stringify(plan)));
```

A lost response remains `unknown`, including its dispatch evidence. The runtime
does not infer successful publication from desired bytes or select a recovery
policy. The consumer can read its index and compare its own revision-marker
triples before deciding whether to retry or prepare another plan. Successful
patches invalidate cached index diagnostics without discovering source resources.

Automatic semantic creation/reclassification retains its existing selection and
nonfatal-unavailable registration policy. It now shares registration triple
compilation with exact publication. Its existing pinned SPARQL serialization is
preserved for compatibility; explicit publication uses the N3 primitive.

S11 engineering qualification is in progress. The initial build identified an
unhandled new operation in failure-location reporting; the location mapping was
extended. Required focused, CSS, packed and full regression results remain
recorded separately from production qualification.

S11 focused publication/semantic/patch/public-API checks passed all 30 tests. The
real CSS run passed all five raw-operation scenarios, including exact selected
index registration and reclassification. A subsequent 16-test run passed both
seven-test registration suites but exceeded the existing 15-second native-view
timeout in one scenario. That unchanged scenario must be rerun in isolation; the
failed measurement is retained and no timeout was raised.

## C2 consumer-owned publication fixture (S12)

Run `npm run test:agent:contract -- --bundle C2` to require the assembled raw RDF,
selected index and exact registration APIs. This runs the baseline, C1 and C2
consumers against an isolated packed installation with declared dependencies.
The C2 fixture reads preferences-only index links, leaves an inaccessible public
index alone, incrementally publishes unknown classes in one private index, and
owns its registration IDs and revision markers. A lost accepted response is
reconciled by inspecting that consumer's marker without replaying the patch.

The fixture's supplied transport verifies exact approved N3 bodies and applies
the plan's public RDF effects. Real CSS independently qualifies actual N3 server
application; the transport fixture does not claim to implement a Solid server.
After installing a pinned archive, run
`node node_modules/@solid-intents/runtime/scripts/fixtures/headless_c2_consumer.mjs`.
Its `ConsumerPublication` example is consumer policy expressed entirely through
public imports. Host authentication, protected index provisioning and durable
publication bookkeeping remain outside the runtime.

The `--artifact-dir` option also supports C2 and retains exact commit, package,
Node/npm, archive hash and contract results. C2 reports RDF batch version one
separately from the as-yet-unqualified durable discovery observation format.
C3 streaming, acknowledged output and portable persistence remain unavailable.
Full handoff and supported Node qualification are in progress; artifacts remain
development-only while the upstream audit is blocked.

## Prepared catalog commits (S13, internal)

The catalog/discovery persistence boundary now separates asynchronous preparation
from committing already prepared effects. A prepared change captures its context,
catalog epoch and revision, source observation/ownership guards, incremental
catalog delta, and discovery bookkeeping. Source-generation pointers and output
obligations use that same bookkeeping boundary as their implementations arrive.
Preparation can read state asynchronously; final persistence receives data and
guards without a catalog callback to execute inside its transaction.

Memory and IndexedDB publish the catalog and bookkeeping together after their
guards pass. Prepared changes are isolated snapshots; another context cannot
commit them. A stale preparation fails without replaying its callback. The
existing combined mutation API retains bounded restaging for competing catalog
revisions, while observation and ownership failures remain terminal. Single-source
updates continue using incremental deltas rather than copying the full catalog.

This is an internal foundation, with no new application persistence selection.
Pod persistence remains unavailable until the complete backend is qualified.
Shared preparation/commit tests cover delayed visibility, rollback, stale guards,
source revision stamping and context binding; full slice qualification is pending.

Qualification record correction: the first S07 full run used a checkout that had
not received its saved implementation patch. It was stopped after exposing the
missing version-four behavior; its logs are retained as `invalid-snapshot` and
do not qualify S07. The saved patch was reapplied, and the resulting source diff
against S06 was checked before restarting the complete matrix.

The unchanged S11 native-view rerun passed both tests in isolation (9.13 seconds
of test execution). The earlier timeout remains in the qualification record.

C2 passed the current Node 22.23.2/npm 10.9.8 packed check: baseline and C1 also
passed; C2 made 14 HTTP requests and three patches, recovered the lost success
through its consumer marker, and made no automatic replay or source-discovery
requests. This working-tree check is not an exact-commit artifact.

## S06 qualification — 2026-09-09

Node 22.23.2/npm 10.9.8 on macOS x64. Build, packed baseline/smoke stages before
the audit, all 796 unit tests, 73 CSS tests, two CSS performance tests, 18
Chromium/Firefox tests and 46 catalog/discovery regressions passed. The existing
10,000-resource benchmark completed in 57.995 seconds, with first ten results
at 665.93 ms, 10,001 source reads, at most 13 materialized jobs and 242,343,936
bytes RSS. Diff checks passed.

`verify` stopped at the isolated production audit (six upstream findings); all
unaffected stages ran independently. The workspace production audit still reports
five findings, four moderate and one high, through Soukai/solid-utils/jsonld/undici.
No dependency substitutions, overrides or audit waivers were introduced. This
qualifies implementation progress, with production release still blocked.

C2 also passed Node 22.12.0/npm 10.9.0 with the same baseline, C1 and C2 results: 14 C2 HTTP requests, three patches, zero automatic replays and zero source-discovery requests. Both supported Node packed checks are green; exact-commit artifacts still require the clean pinned handoff checkout.

## Streaming source observations (S14)

`resources.readRdf()` consumes the authenticated response incrementally, decodes
UTF-8 in at most 8 KiB parser chunks and delivers bounded runtime-owned RDF
batches before EOF. The browser adapter supplies the installed N3 parser's three
input events without importing Node streams. Blank-node topology is stable across
chunk boundaries and scoped to the source attempt. Semantic extraction, resource
classification, type-index interpretation and raw access use the same parser.

Configure `boot({ sourceLimits: { bodyBytes, expandedBytes } })`; the defaults are
32 MiB of response bytes and 64 MiB of expanded RDF observation data. Diagnostics
report the effective values. Expanded size is charged from the serialized public
RDF quad before retaining it. Body cancellation, invalid UTF-8, malformed RDF and
limit exhaustion never produce a complete batch. A limit failure identifies the
limit, configured maximum and observed size, with `complete: false`.

Discovery commits parsed fact pages through the existing coordinator while the
source work claim remains active. A container's positive membership prefix feeds
one durable expansion cursor, allowing children to be discovered before the
listing finishes. The cursor waits for the producer when it reaches the current
prefix and resumes when another page commits. Partial observations do not advance
source-completion counters, replace authoritative membership or infer removals.
Source errors retain prior authoritative knowledge and committed parsed prefixes.

Staging uses bounded pages in the existing journal. Its current tail may change
under guards until completion; completed snapshots cannot be appended through
the staging API. The original immutable snapshot store remains immutable. Final
catalog interpretation and the existing materializing APIs still allocate in
proportion to one bounded source; portable catalog paging and the archive memory
qualification arrive in subsequent C3 slices.

The first parser/lifecycle run built successfully and passed 38 of 39 tests. Its
held-body fixture lacked the whitespace needed to disambiguate the final RDF
token and timed out before reaching cancellation. The fixture now terminates its
statement with a newline; the original failure remains recorded. The corrected build and all 68 expanded streaming, discovery, parser and semantic
regressions passed. Full slice qualification remains in progress.

Qualification queue correction: replacing an active polling-shell wrapper caused the first corrected S07 CSS performance command to exit without executing; its empty log and exit code are not qualification evidence. That stage is being rerun under a kernel-queued measurement lock. The orphan lock was recovered after confirming that no measurement owned it. No test threshold or implementation was changed for this queue repair.

## S13 qualification — 2026-09-09

Build and all engineering stages passed on Node 22.23.2/npm 10.9.8, macOS x64:
840 unit tests, 78 CSS tests, two CSS performance tests, 18 Chromium/Firefox tests,
and 46 catalog regression tests. The unchanged 10,000-resource benchmark finished
in 90.94 seconds, with first ten results at 967.82 ms, 10,001 source requests,
at most 12 materialized jobs and 252,948,480 bytes RSS. The semantic performance
gate and `git diff --check` passed. `verify` and production audit remain blocked
only by the recorded upstream dependency vulnerabilities. No dependency bypass,
threshold change, publication or production qualification was introduced.

## S07 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 802 unit tests, 76 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 18.586 seconds, with first ten results at
223.37 ms, 10,001 source reads, at most 13 materialized jobs
and 249,982,976 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

The required CSS performance rerun executed and passed both tests. The earlier
empty log from the polling-wrapper transition remains excluded from evidence.

## S08 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 816 unit tests, 77 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 20.295 seconds, with first ten results at
225.38 ms, 10,001 source reads, at most 13 materialized jobs
and 263,987,200 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

## S09 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 816 unit tests, 77 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 17.911 seconds, with first ten results at
226.89 ms, 10,001 source reads, at most 13 materialized jobs
and 254,304,256 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

## S10 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 825 unit tests, 77 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 17.074 seconds, with first ten results at
215.54 ms, 10,001 source reads, at most 13 materialized jobs
and 289,599,488 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

## S11 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 832 unit tests, 78 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 17.100 seconds, with first ten results at
224.10 ms, 10,001 source reads, at most 13 materialized jobs
and 262,868,992 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

## S12 qualification — recorded 2026-09-10

The corrected frozen slice passed build, all 832 unit tests, 78 CSS tests,
two CSS performance tests, 18 Chromium/Firefox tests, the semantic performance
gate and 46 catalog regression tests. Its unchanged 10,000-resource fixture
completed in 17.432 seconds, with first ten results at
222.64 ms, 10,001 source reads, at most 13 materialized jobs
and 250,744,832 bytes RSS. Node 22.23.2/npm 10.9.8, macOS x64.
`verify` and production audit remain blocked by the recorded upstream dependency
chain; unaffected stages passed independently. No thresholds or dependencies
were changed to bypass qualification.

## S14 qualification — recorded 2026-09-10

Build, 78 CSS tests, two CSS performance tests, all 18 browser tests and the
performance gates passed. The unchanged 10,000-resource fixture completed in
37.938 seconds, with first ten results at 1,275.07 ms, 10,001 source requests,
at most 13 materialized jobs and 333,971,456 bytes RSS. Exact dispatch and
continuation assertions remained unchanged and passed.

The initial full unit run passed 848 of 849 tests. One old assertion counted an
aborted, unconsumed response as completed. The streaming contract requires that
read to remain pending and rejects publication of its late body. The updated
test also verifies successful explicit resumption. Build and all 19 related
coordinator/streaming tests passed after that correction. The original failure
is retained. `verify` and production audit remain blocked only by the upstream
dependency findings. Source streaming is qualified; portable archive bounds and
C3 output/persistence still require the remaining slices.


## Complete source generations and recovery (S15)

Discovery now keeps an authoritative source-generation pointer separately from
incomplete staging. The pointer pins parsed RDF facts, container membership and
catalog projections. Final publication, catalog effects, source receipt and
continuation share the guarded catalog commit. A failed preparation or stale
observation leaves the previous generation authoritative. Positive prefixes stay
available without permitting inferred removal.

Catalog projections are staged in bounded record pages. Final preparation reads
those pages and the uncommitted tail through a repeatable internal reader;
source replacement visits previous identities incrementally. Container
reconciliation reads membership pages rather than reconstructing the RDF
listing. Memory and IndexedDB still retain their existing materialized identity
indexes; bounded portable indexes are qualified in S18–S23.

An interrupted source is reread and reparsed from the beginning after restoration,
using an unconditional request. A `304` cannot validate incomplete facts or
membership. The runtime does not use byte-offset resumption or reuse interrupted
blocks without proving equivalent content. Each successful replacement has a new
attempt identity; old generation references remain protected while another
attempt is incomplete. Referenced pages survive snapshot cleanup.

Asynchronous catalog preparation releases the IndexedDB operation barrier before
reading staging pages. The final mutation retains captured revision, source and
ownership guards and has no remote callbacks inside its transaction.

Initial build passed. The first 41-test run passed 39, including new atomic-page
and restart scenarios; two existing container tests exceeded their unchanged
30-second and five-second limits. Their isolated rerun also exceeded those
limits. Both failures are retained while the preparation path is corrected and
requalified; no timeout was raised.

## Pinned C1/C2 development packages — 2026-09-10

C1 source `ee938f75608ca3143498d5fc85071549eabd666b` and C2 source
`962242e630602ba61065b6175b5e5c0c02742377` passed the isolated packed consumers on
Node 22.12.0/npm 10.9.0 and Node 22.23.2/npm 10.9.8. Each clean checkout produced
an immutable archive, SHA-256 and machine-readable qualification report. Package
version remains 1.1.1; these are unpublished development artifacts identified by
source commit and bundle. Production qualification remains blocked by the
recorded upstream audit findings.

The first artifact attempts were rejected before packing because dependency
symlinks appeared as untracked files. The checkouts now use ignored dependency
directories; all four unchanged contract checks passed. The rejected attempts are
retained in the evidence record and do not qualify an artifact.

The corrected preparation path passed build and all 29 source-generation,
container, prepared-change and paged-catalog checks. This includes the two
unchanged container scenarios and an ephemeral-discovery/IndexedDB barrier
regression. Reusing already captured journal guards also removes redundant
IndexedDB reads from reference retirement. Full slice verification is pending.
A separate profiling harness failed before measurement because it selected the
wrong dependency path; it supplied no performance evidence and was not rerun
once the required unchanged scenarios passed.

The initial full S15 matrix passed 858 of 860 unit tests, 77 of 78 CSS tests,
both CSS performance tests, all 18 browser tests and the discovery performance
gate. The two container timeouts recurred under the full suite; the photo
first-result measurement was 1,616 ms against its unchanged 1,500 ms limit.
The known upstream audit also remains blocked. These failed measurements remain
recorded. Profiling the frozen code showed time in extra IndexedDB transactions
and index updates. A small source already fits one catalog delta, so dedicated
projection staging now applies only above 256 records. The isolated corrected
build and all 18 container/generation/restart tests passed (8.87 seconds of test
execution, 12.30 seconds overall). The final full matrix runs against a separate
frozen checkout to exclude in-progress output work.


## Acknowledged discovery output (S16)

Public discovery sessions retain one ordered output stream. `readOutput()`
returns the oldest delivery; repeated reads return that same delivery until
`acknowledgeOutput(receipt)` succeeds. Acknowledgements are repeatable after a
lost response. Receipt validation binds the namespace incarnation, session
incarnation and delivered sequence range. An acknowledgement watermark and
namespace-local sequence counter keep restoration independent of acknowledgement
history. Receipts contain no fetch credentials.

Cancellation retains output. Deletion refuses unacknowledged observations unless
`discovery.deleteSession(id, { disposeOutput: true })` explicitly requests their
disposal. This also protects orphaned output after a session is quarantined.
Legacy internal query-discovery intents keep their existing automatic behavior;
the public session API owns acknowledged deliveries.

Source admission reserves expanded observation capacity and terminal evidence.
A full backlog reports `output-blocked` for that session. Acknowledgement frees
capacity without resuming execution: call `session.run()` explicitly. Capacity
occupied by active reads makes further admission wait for those reads to finish.
Configure `boot({ discoveryOutputLimits: { batchObservations, batchBytes,
pendingBytes } })`; diagnostics report effective limits. Defaults are 100
observations/256 KiB per delivery and 128 MiB pending per session. The source's
expanded-data budget includes output envelopes and terminal evidence. Exceeding
it produces incomplete source-limit evidence, preserving prior authority.

Observations expose stable IDs, sequence numbers, source and attempt identities,
ISO timestamps, opaque validators, explicit RDF facts/classes, completeness and
failure evidence. Large RDF quads use ordered `factFragment` observations with
`base64-utf8-rdf-quad-json` encoding. Concatenate decoded bytes in part order and
parse the resulting JSON to recover the runtime-owned quad, including blank-node
scope, language, datatype and complete lexical value. Fragments never assert
source completeness; consumers can retain or forward fragments without
materializing an arbitrarily large literal.

```ts
const result = await session.run();
for (let batch = await session.readOutput(); batch; batch = await session.readOutput()) {
  await consumer.acceptDurably(batch.observations);
  await session.acknowledgeOutput(batch.receipt);
}
// An output-blocked session requires another explicit run after acknowledgement.
```

The initial internal output build and five memory/IndexedDB/large-literal checks
passed. Integration build attempts exposed an inferred UUID parameter type and
missing explicit API parameter annotations; these are corrected. Full public
session, browser and handoff qualification remains pending.


## S15 qualification — 2026-09-10

The final isolated slice passed build, all 860 unit tests, 78 CSS tests, both CSS
performance tests, all 18 Chromium/Firefox tests, the semantic performance gate
and 46 catalog regression tests. The unchanged 10,000-resource fixture completed
in 48.669 seconds, with first ten results at 1,250.12 ms, 10,001 source reads,
11,001 dispatched jobs, at most 13 materialized jobs and 354,369,536 bytes RSS.
Node 22.23.2/npm 10.9.8 on macOS x64. Earlier failed measurements remain above.
Verification and production qualification remain blocked by the upstream audit:
five workspace production findings (four moderate, one high), without overrides,
forks or waivers. All unaffected engineering stages passed independently.

The first public integration run passed 29 of 35 tests. Copying a prepared job to
attach its attempt identity hid continuation updates made by the existing
expansion callback, causing early false settlement. Commit now retains that
original prepared object. The corrected build and all 48 related tests passed.
Receipt deletion/replacement races then passed eight checks; interrupted-attempt
finalization and recovery passed 40 checks. The final expanded build and all 53
focused checks passed, including a child discovered before held container EOF,
stable acknowledged prefixes after interruption, separate-session progress and
whole-envelope delivery byte accounting. Earlier failures remain recorded.

Output reads and acknowledgements guard the session incarnation as well as the
queue state. Interrupted reservations retain terminal obligations; execution
finalization and restoration append incomplete attempt evidence before releasing
the reservation. An obsolete attempt cannot finalize a newer reservation.
Receipt namespace bindings use a fixed-size SHA-256 identity, and delivered byte
counts include the entire serialized batch. Metadata that exceeds the delivery
format reports a structured output-limit error while retaining existing output.
Output durability follows the selected catalog backend: memory remains ephemeral.

Each admitted source reserves its expanded-output allowance, with at least
128 KiB reserved and 64 KiB protected for terminal evidence. A pending limit too
small to admit one source reports output-blocked before source HTTP. Consumers
should configure source and backlog limits together. Full slice verification,
browser restart acknowledgement and the packed declaration checks follow in the
frozen qualification matrix.


## S17 — bounded turns and finite known-resource sweeps (in qualification)

`session.run({ maxJobs, maxRequests, maxBytes, waitForRetry })` adds explicit job,
HTTP-dispatch and consumed-response-body budgets. `maxRuns` retains its existing
100-jobs-per-run interpretation; supplying it with `maxJobs` is invalid. Omitted
request and byte budgets remain unlimited. Request counts include redirects,
conditional reads and transport retry dispatches. A request is charged before the
supplied fetch runs. Reads already admitted keep their request reservations;
unused reservations are released. Checkpoint HTTP accounting will be connected
when the Pod backend is implemented; memory and IndexedDB commits require no HTTP.

A turn that cannot admit its first unit returns `insufficient-budget` and
`insufficientBudget` with the limiting resource, required amount and remaining
amount. Later exhaustion returns `budget-exhausted` and retains continuation.
`usage.requests` and `usage.bytes` report actual transport work. A response chunk
that crosses the byte budget is counted and cancelled before its contents are
passed to RDF interpretation; the network chunk can exceed the remaining budget.
Incomplete source evidence cannot establish removal, and the next turn reparses
an interrupted source. Materializing APIs keep their separately documented limits.

Explicit execution defaults `waitForRetry` to false. With only delayed work left,
a turn returns `retry-deferred`; `snapshot.nextRetryAt` identifies its next eligible
time. Automatic execution preserves waiting by default. No recurring recheck timer
is introduced.

After pausing active discovery, call
`session.recheckKnown({ checkedBefore: new Date(cutoff) })`. Preparation records a
finite snapshot of source interests known at its committed revision, without
source HTTP and without replacing unfinished traversal. The result gives the
sweep ID, preparation revision and number of source interests. Interests for the
same source under multiple targets can reuse a matching fresh observation.
Immutable staging pages become executable together with a guarded continuation;
subsequent membership additions cannot extend that sweep. Eligible recheck work
alternates with ordinary work, retaining the existing foreground/background
session fairness. Rechecks retain original validators, so an unchanged container
can reuse its complete listing while known children receive fresh checks.


S16 initial full qualification (2026-09-10): build, 78 CSS tests, two CSS
performance tests, 18 Chromium/Firefox tests, semantic performance and 46 catalog
checks passed. Unit tests passed 867/871: three timeouts in existing IndexedDB
session/container scenarios and one cleanup test that still deleted retained
output. The unchanged 10,000-resource benchmark completed in 137.204 seconds,
first ten at 3,113.29 ms, 10,001 reads, 11,001 dispatched jobs, 10,002 completed
jobs, maximum materialized frontier 12 and RSS 396,677,120 bytes. These slower
measurements remain part of the report. The isolated direct-coordinator CPU
profile completed 257 resources in 17.09 seconds. Verification and audit remain
blocked by the same upstream findings.

The cleanup regression now acknowledges its committed output before deletion.
Output admission prepares a reservation and commits it with the source work
claim under the same guards; it no longer needs a separate reservation commit.
Independent reservation-state reads run together, and a completed source skips
redundant interrupted-reservation finalization. New memory/IndexedDB checks cover
atomic admission and rejected stale claims. An isolated corrected matrix follows.


Qualification correction (2026-09-10): inspection of retained verify logs shows
that the packed smoke consumer still asserted write-plan version three after
version-four planning was implemented. Consequently the S06–S16 verify attempts
that contain this assertion stopped in smoke:app, before reaching the audit.
Earlier descriptions of those verification failures as audit-only are incorrect.
The independently recorded unit/CSS/browser/performance results remain valid;
the separately run production audit remains blocked. The smoke fixture now
requires version four and acknowledges session output before deleting it. No
version-three compatibility path or test threshold has been removed. The pinned
C1/C2 isolated contract artifacts retain their original source and hashes; their
successful consumer checks do not establish a successful full verify command.


S17 checks (2026-09-10): the first corrected build and 24 focused budget,
transport, work and fairness checks passed. The expanded restart/recheck run
passed 43/44 tests; the existing 150-resource IndexedDB restoration scenario
exceeded its unchanged 30-second limit. Its uncapped path now avoids the extra
receipt lookup needed only for request/byte admission limits. The new prepared
sweep restart and persisted 1:1 fairness checks passed in both storage modes.
Earlier build failures and the timeout remain in the qualification record.

The corrected packed runtime consumer passed after the version assertion and
acknowledgement fixes. Strict declaration checking then exposed N3 types reachable
through the diagnostic inspection module's private implementation imports. Public
inspection types now live in a dedicated contract module. No consumer dependency
on @types/n3 or reduced declaration checking is introduced. The prior declaration
failure remains recorded; a new full verify run checks the corrected boundary.


S16 final qualification (2026-09-10): the admission correction passed build and
all 873 unit tests, 78 CSS tests, two CSS performance tests, 18 Chromium/Firefox
tests, the semantic performance gate and 46 catalog/discovery regression tests.
The final 10,000-resource run completed in 231.990 seconds, first ten results at
5,711.34 ms, 10,001 source reads, 11,001 dispatched jobs, 10,002 completed jobs,
maximum frontier 12 and RSS 405,630,976 bytes. The earlier measurements and
failures remain above; no thresholds were changed. Node 22.23.2/npm 10.9.8 on
macOS x64.

The corrected full verify attempt passed its packed baseline, isolated Node smoke
consumer and strict public declaration check, then stopped at the isolated
production dependency audit (six findings: five moderate, one high). The runtime
behavior gates listed above ran independently on the same admission implementation;
the subsequent correction changes the smoke fixture and public type-module
boundary. The separate workspace audit reports five production findings. S16 is
implemented with these engineering results, while production release qualification
remains blocked. C3 and portable persistence are not yet qualified.


S17 initial full matrix (2026-09-10): the corrected packed Node consumer and
strict declarations passed; verify then stopped at the isolated upstream audit.
The independent unit run passed 874 of 883 tests in 1,068.52 seconds. All nine
failures were time limits: paused IndexedDB restoration, large container
continuation, rollback, native views, prepared-sweep restoration, the bounded
catalog-mutation fixture, two public runtime restoration scenarios and the local
10,000-record semantic query fixture. These failures remain recorded.

An initial profiled Node restoration run stalled and was stopped. Subsequent
capped, unprofiled traces made steady progress without claim conflicts and
drained cleanly on cancellation. The queued trace reached 134 of 150 source
resources at its 30-second cancellation boundary, including a successful pause
and local restoration at 18.07 seconds. This is diagnostic evidence, not a passed
restoration time gate. A correction batches the six work-state counters used by
a progress snapshot into one IndexedDB transaction, and also batches session
orphan checks. Counts remain indexed and preserve one coherent storage snapshot.
The corrected build and focused restoration matrix are pending.

S18 internal foundation (2026-09-10): the first build and five page-tree, large
RDF, integrity and cache tests passed. The expanded build and all 17 portable
index and related catalog query tests passed. Primary records and secondary
indexes share immutable prepared roots. The implementation reuses catalog token
and discovery-index definitions; narrow reads and indexed counts load bounded
paths. No public Pod persistence backend is enabled by this foundation. See
[portable checkpoint internals](PORTABLE_CHECKPOINTS.md) for the record boundary.
Full S18 verification and C3 qualification remain pending.


The counter correction builds. Its focused run passed 34 of 39 tests: all new
counter, finite-sweep and public-runtime tests passed, while five existing
container, restoration and cross-context stop tests timed out. The host reported
load averages above 40 and substantial compressed memory. A one-worker diagnostic
keeps the same time limits and is pending; the existing failures remain recorded.


S17 corrected counter matrix (2026-09-10): the focused one-worker run passed
38 of 39 tests, with the existing 150-resource restoration time limit still
failing. The subsequent isolated full unit run passed all 887 tests in 688.14
seconds using one worker and unchanged test thresholds. Build, packed Node and
strict declaration checks passed; verify stopped at the isolated six-finding
production audit. The remaining CSS, browser and performance stages are pending.
The earlier nine failed timing checks remain above.


S18 retained CSS performance failure: both assertions returned empty catalog
results (0 of 40 indexed records, and 0 of 5 search results), completing in
10.94 seconds. Its full 78-test CSS suite passed beforehand; the corresponding
S17 performance gate passed. The only active source-code difference between those
frozen slices is the exported name of the shared catalog-token helper; the
portable foundation is not wired into browser or legacy execution. No cause has
yet been established. The unchanged rerun passed both tests in 29.09 seconds.


S18 follow-up evidence (2026-09-10): the unchanged CSS performance rerun passed
both tests in 29.09 seconds. The original empty-result failure remains recorded;
its cause is not established. All 18 Chromium/Firefox tests passed in 4.8 minutes.
The full performance stage remains in progress.


S17 final corrected qualification (2026-09-10): build, packed public consumer and
strict declaration checks passed. Verification then stopped at the isolated
upstream audit (six findings). The independently executed stages passed: all 887
unit tests with one worker and unchanged thresholds, 78 CSS tests, two CSS
performance tests, 18 Chromium/Firefox tests, semantic performance and all 46
catalog/discovery performance tests. The 10,000-resource discovery fixture took
149.764 seconds, returned the first ten in 2,082.33 ms, made 10,001 source reads,
dispatched 11,001 jobs and completed 10,002, with at most 12 materialized jobs.
Reported end-of-run RSS was 397,848,576 bytes. This fixture is the existing
memory/IndexedDB benchmark, not the portable archive qualification. Earlier
failed timing runs remain retained above. Production release remains blocked by
the dependency audit; Pod checkpoint HTTP accounting is qualified only when the
portable backend integration supplies its execution scopes and reservations.


S18 final qualification (2026-09-10): build, packed consumer and strict
declarations passed; verify stopped at the isolated six-finding upstream audit.
All 895 unit tests, 78 CSS tests, 18 browser tests, semantic performance and 46
catalog/discovery performance tests passed. Both CSS performance tests passed
on the unchanged rerun; their earlier empty-result failure is retained above.
The existing 10,000-resource benchmark took 201.351 seconds, returned the first
ten in 2,426.29 ms, made 10,001 source reads, dispatched 11,001 jobs and completed
10,002, with at most 12 materialized jobs and reported end-of-run RSS of
390,340,608 bytes. The new backend remains internal in this slice. These results
do not qualify the portable 100,000-resource archive or production release.

S19 internal guarded-manifest adapter (2026-09-10): build and all 13 focused
root, catalog-commit and operation-scope tests passed on Node 22.23.2. These
checks cover conditional create/open, displaced writers, failed staging, lost
successful responses, 503 after a committed root, reconciliation after another
writer advances state, ignored cancellation, wrong identity and unsupported
versions. Catalog, continuation and output remain hidden until one guarded root
publication is confirmed. An uncertain root blocks further mutations.

Operation-specific page readers and writers inherit cancellation and HTTP/byte
accounting from the supplied scheduled transport, sharing one bounded cache.
This verifies the internal transport seam; full discovery-turn checkpoint
attribution and finalization reservations remain integration work. The Pod
backend is not publicly selectable yet. Full S19 verification and the C3 archive
and restart qualification remain pending.

S19 full qualification (2026-09-10): build, packed public consumer and strict
declaration checks passed; verification stopped at the isolated upstream audit
(six findings). The full unit run passed 906 of 908 tests; the existing
150-resource IndexedDB restoration and 257-child container restoration exceeded
their unchanged 30-second deadlines. An unchanged one-worker rerun of both
affected files passed all 25 tests in 46.85 seconds. The initial failures remain
recorded and their cause has not been established. All 78 CSS tests, two CSS
performance tests, 18 browser tests, semantic performance and 46 catalog/discovery
performance tests passed. The existing 10,000-resource fixture took 228.491
seconds, returned the first ten in 6,480.66 ms, made 10,001 source reads, dispatched
11,001 jobs and completed 10,002, with at most 12 materialized jobs and end-of-run
RSS of 403,423,232 bytes. This qualifies the internal implementation checks with
retained rerun evidence, not C3 or production release.

S20 bounded portable catalog and public query pages (2026-09-10): initial
read/index checks passed all 21 tests, followed by 26 mutation checks. The first
public page build failed on two nonexistent namespace-property references; the
corrected build and all 51 public query/session tests passed. The first assembled
run passed 34 of 36 checks and rejected two canonically serialized session
definitions. Value comparison now preserves normalization while ignoring JSON
object property order. The later combined S20/S21 run passed 66 of 69 checks;
two five-second assembled scenarios and one existing 30-second IndexedDB
restoration timed out. An unchanged rerun passed 15 of 17 checks, still timing
out on session membership/clear and the existing IndexedDB restoration.
These failed measurements remain recorded. Verified private cache hits now
avoid repeated hashing and validation, with fresh parsed return values and
full integrity checks after eviction. Corrected qualification is pending.

`things.queryPage(query, { pageSize, cursor, scope, signal, deadline })` returns
`{ things, revision, nextCursor?, discovery? }` in Thing URI order, with default
page size 100 and maximum 1,000. Opaque authenticated cursors bind context,
revision, query, scope and semantic-profile revision; restart pagination on
`invalid-query-cursor`. Checkpoint page reads never start source discovery.
Materializing queries retain their existing semantics. Internal Pod catalog
reads use paged source, identity, type, inverse-link, membership and work indexes,
while memory/IndexedDB continue using the same semantic query interpretation.
This slice does not yet expose Pod boot or qualify the 100,000-resource archive.

S20 preparation correction: a bounded private page buffer uploads final
reachable paths and spills within its reserved share of the configured cache.
Membership references in large records remain explicit physical dependencies.
The first staging run passed 14 of 17 checks, with two five-second timeouts and
a fault fixture that rejected checkpoint reads before reaching the intended
root failure. The corrected fault fixture fails reads only after losing the
root response. Its rerun passed 16 of 17 checks; the combined membership/clear
scenario still exceeded five seconds with a 64 KiB cache. Assembled timing checks
now use the declared default cache; separate page, catalog and public boot tests
retain their small-cache configurations. No test deadline has changed.
The earlier cache-only run passed 40 of 42 checks, with this same assembled
timeout and a new 1,000-record bootstrap scenario exceeding 30 seconds during
its combined fixture preparation and boot. That public S21 scenario is still
unqualified. The smaller, previously passed boot cases remain separate evidence.

S20 final focused check: the isolated build first failed because nested
workspace development-tool links were missing from the checkout. After restoring
those links, build passed and 38 of 39 checks passed, including both assembled
five-second scenarios with the default cache. The remaining assertion required
more than three checkpoint requests even though buffering correctly reduced
the commit to three. It now checks that page and manifest requests are present
and that every actual request is charged; it no longer requires redundant HTTP.
The original failure is retained. Full verification is pending.

S20 full unit matrix: 925 of 926 checks passed across 124 files in 999.73
seconds with one worker and unchanged limits. The existing 150-resource
IndexedDB restoration alone exceeded its 30-second deadline. Packed consumer
and strict declarations passed; verify then stopped at six upstream audit
findings. CSS, browser and performance stages continue independently.

S20 final qualification (2026-09-10): the corrected operation-accounting file
passed all four tests. Build, packed public consumer and strict declarations
passed; verify stopped at the isolated six-finding upstream audit. All 78 CSS
tests, two CSS performance tests, 18 Chromium/Firefox tests, semantic performance
and 46 catalog/discovery performance checks passed. The full unit matrix passed
925 of 926 tests; an unchanged rerun of the affected restoration file passed
14 of 15, again exceeding the existing 30-second limit for 150-resource IndexedDB
restoration. This timing gate remains unresolved, without a proven cause or
relaxed threshold. The 10,000-resource benchmark took 145.652 seconds, returned
the first ten in 3,585.44 ms, made 10,001 source reads, dispatched 11,001 jobs
and completed 10,002, with at most 12 materialized jobs and end-of-run RSS of
398,905,344 bytes. These internal checks do not qualify C3 or production release.

S21 corrected bootstrap evidence: build and all 20 public Pod/output/transport/
HTTP-link tests passed in 27.47 seconds. The 1,000-record boot case now uses the
bounded bulk page builder for fixture generation before boot and keeps its
original 30-second limit. It confirms restoration does not hydrate the Thing
catalog or read source resources. The earlier slow incremental fixture and
failed combined timing measurement remain recorded. Read-output cancellation
rejects before checkpoint dispatch; acknowledgements also accept operation
options. Full execution budgets and C3 remain unqualified.

S21 admission checks: build and all 28 selected public Pod, manifest, close,
operation-lifetime and exact-write tests passed in 37.22 seconds. A known displaced
writer stops new context admission and dispatches no peer mutation. An uncertain
root blocks peer mutations until its outcome can be established. The separate
operation-scope matrix passed all 48 selected discovery and public Pod tests.
Finalization budget reservations, cleanup and full S21 qualification remain open.

S21 related-read preparation: build passed; the first 35-test run passed 29.
Four new test assertions omitted the existing committed revision and epoch stamps;
they now compare the requested values and separately assert coherent stamps.
The existing 150-resource IndexedDB restoration and 1,000-record portable
bootstrap also exceeded their unchanged deadlines. The latter took 809.519
seconds including fixture preparation in this run, compared with its earlier
passing measurement. The cause is not established; these failures remain retained.

S21 output snapshot correction: all 15 entry-read and output tests passed in
12.70 seconds. Full verification of the frozen public Pod backend is pending.
Checkpoint turn accounting and finalization reservations remain incomplete;
compaction, recovery cleanup and archive qualification belong to subsequent work.
C3 remains unqualified.

S21 full unit qualification passed all 939 tests across 128 files in 368.96
seconds using one worker and unchanged deadlines. CSS and CSS performance also
passed; browser and performance stages continue. Earlier timing failures remain
recorded. The upstream isolated audit remains the production release blocker.

S21 final qualification (2026-09-10): build, isolated packed consumer and strict
declaration checks passed. Verification stopped at the isolated six-finding
upstream audit. Independent stages passed all 939 unit tests, 78 CSS tests, two
CSS performance tests, 18 Chromium/Firefox tests, semantic performance and 46
catalog/discovery performance tests. The 10,000-resource benchmark took 73.829
seconds, returned the first ten in 1,549.02 ms, made 10,001 source reads, dispatched
11,001 jobs and completed 10,002, with at most 12 materialized jobs and end-of-run
RSS of 393,805,824 bytes. Earlier failed timing and fixture measurements remain
recorded. Public Pod boot, restoration, output retention and identity fencing
are implemented; complete checkpoint turn accounting, finalization reservations,
compaction, cleanup and the 100,000-resource archive qualification remain open.
C3 and production release remain unqualified.


S21 retained initial integration run: 38 of 42 checks passed; four rejected
canonically serialized session definitions. The correction preserves normalized
intent while allowing JSON object-key order to change. Later corrected and full
results above supersede that failure without removing its record.

S21 output snapshot correction: all 15 entry-read and output tests passed in
12.70 seconds. S22 internal archive groundwork builds; its first focused run
passed 13 of 15 checks. Two new journal cases exposed invalid JSON from an
optional predecessor hash serialized as undefined. The codec now omits absent
optional fields. Archive anchoring, compaction, persistent read pins and GC
are not yet integrated or qualified.

S22 allocation/journal integration: bounded batch upload checks passed all 13
tests in 13.16 seconds. Root anchoring builds and its first run passed 21 of 23
checks. The two failures expected three opening requests; opening now also
materializes the previous writer's immutable archive descriptor before the
conditional claim. Both expectations now include that bounded metadata write.
The archive chain remains internal; sealing on close, persistent read pins,
compaction and reclamation are still unfinished.

S22 guarded archive checks passed all 24 tests in 20.66 seconds. The first
shutdown-sealing build failed on a nullable catalog-store check; the close path
now checks that a store exists before invoking its backend barrier. Corrected
shutdown tests are pending. No cleanup or archive capacity qualification is
implied by these internal results.

S22 shutdown sealing: the corrected build and all 46 selected public Pod, close,
operation-lifetime, checkpoint-accounting and scheduler tests passed in 32.16
seconds. Duplicate close writes one archive seal after admitted work drains.
Interrupted or displaced epochs remain unsealed. Full S21 verification now runs
in an isolated checkout that excludes this later archive implementation.

S21 full unit qualification passed all 939 tests across 128 files in 368.96
seconds using one worker and unchanged deadlines. CSS and CSS performance also
passed; browser and performance stages continue. Earlier timing failures remain
recorded. S22 small-journal checks passed all nine tests in 5.10 seconds; guarded
control-root checks passed all 19 tests in 8.47 seconds. Their catalog revision
stays unchanged while checkpoint metadata commits advance the manifest revision.

S22 read-pin and metadata evidence checks: build and all 20 selected pin,
manifest, catalog-commit and store tests passed in 14.41 seconds. Metadata
publication retains its own indexed evidence and preserves catalog data roots.
An uncertain metadata write can be established after another writer advances
the catalog. The subsequent snapshot lifetime build passed all 28 tests in
30.33 seconds. A local edit script stopped before wiring catalog query methods;
that wiring is now under a separate test run. Actual GC and compaction remain
unimplemented, so these checks do not qualify reclamation.

S22 query-pin integration initially passed 27 of 29 checks. Two public
discovery scenarios became blocked because pin metadata advanced the manifest
while a catalog commit was being prepared. Diagnostics confirmed the revision
conflict. Data publication now tolerates intervening metadata only when its
catalog revision, epoch and allocation still match, preserving the latest pin
and control-evidence roots. The corrected build and all 29 checks passed in
30.74 seconds, including the public restart and exclusion scenarios. The earlier
failures remain recorded. Cleanup and archive qualification remain outstanding.

S22 cleanup development: bounded page marking passed eight focused tests across three files, including serialized continuation, orphan exclusion and integrity failures. Ordered archive rotation then passed the build and 22 tests across three files (6.35 seconds). Rotation uploads its proof before sealing the retired allocation; proof attribution uses the target allocation so uncertain rotation remains protected. Lost-response reconciliation rebinds page uploads only after root publication is confirmed. These are internal checks; complete cleanup and C3 qualification remain outstanding.

S22 assembled cleanup development initially failed its build on two missing TypeScript narrowings; both were corrected. The corrected build passed; 19 existing focused tests passed while four new cleanup tests rejected their invalid empty-leaf fixture before cleanup ran. After replacing that fixture with valid unpublished pages, all four cleanup scenarios passed (18.07 seconds): bounded continuation across restart, pinned snapshots and unsealed epochs, lost DELETE responses, and writer takeover during a dispatched deletion. The failed measurements remain in the development logs. Prepared-catalog snapshot retention and the public maintenance interface are still being integrated.

S22 maintenance integration: an initial build rejected a stale TypeScript narrowing across reconciliation; the corrected build passed. The integrated matrix passed 23 of 25 tests across six files (141.27 seconds). Both failures were existing 30-second limits in the public recursive-exclusion scenario and the new public maintenance scenario. The successful checks include pinned preparations, reclamation after snapshot release, resumable index rebuilding, and takeover/lost-delete recovery. No thresholds were changed. The two timing failures remain unresolved while request-count diagnostics run; this is not full S22 or C3 qualification.

S22 pin-lock correction: the first compiled Node diagnostic ended with an unsettled await during session execution. It exposed lazy pin registration trying to acquire the manifest lock held by its own catalog commit. Pin protection now precedes that lock. The corrected build and 23 of 25 integration tests passed (118.16 seconds); recursive exclusion passed, while public maintenance hit 30 seconds and one internal restart/cleanup test hit 5 seconds. A subsequent Node trace completed with identical output redelivery in 54.57 seconds: two source requests, 17,013 checkpoint requests including close, and 1,222 remaining control proofs. This measurement exposed excessive metadata work from processing each small intent separately. Bounded intent batching and read-only revalidation of already persisted deletion claims are now under test; the previous measurements remain retained.

S22 bounded-intent correction passed the build and 24 of 25 selected tests
(53.85 seconds). All maintenance scenarios passed, but concurrent pin registration
caused one public discovery run to report a metadata preparation conflict. The
compiled Node diagnostic completed with identical redelivery in 5.88 seconds,
two source requests, 4,212 checkpoint requests including close, and 41 remaining
control proofs. This replaces the earlier per-intent metadata amplification;
both traces are retained. Pin registration is now serialized locally, and the
mark boundary also protects readers admitted during index rebuilding. These
concurrency corrections and additional corruption/rebuild-restart scenarios are
under test.

S22 final focused checks passed the build and all 28 tests across six files
(46.56 seconds), including the previously blocked public restoration case,
corrupted sealed intents, restart during rebuilding with intervening edits,
and snapshots admitted after compaction starts. The final compiled diagnostic
completed in 5.46 seconds with two source requests, 3,752 checkpoint requests
including close, and identical output redelivery. The complete repository matrix
is now running in an isolated S22 checkout. C3 remains unqualified until the
remaining checkpoint-budget and archive handoffs pass.

S22 complete repository qualification (Node 22.23.2, npm 10.9.8, macOS x64):
build, the packed baseline consumer and strict public declarations passed.
Verification then stopped at the known isolated production dependency audit:
six findings, five moderate and one high. Independent stages passed all 968
unit tests across 132 files (601.59 seconds, one worker, unchanged deadlines),
78 CSS tests (188.10 seconds), two CSS performance tests (38.63 seconds),
and 18 Chromium/Firefox tests (4.9 minutes). The semantic performance comparison
and all 46 discovery performance checks passed. The existing 10,000-resource
measurement completed in 141.218 seconds: first ten results in 2,616.670 ms,
10,001 source reads, 11,001 dispatched jobs, 10,002 completed jobs, at most 12
materialized frontier jobs, and ending RSS 402,341,888 bytes. This fixture is
not the separate 100,000-resource archive qualification. S22 cleanup and
compaction are implemented and checked; C3 remains unqualified pending complete
checkpoint turn budgeting and the archive/packed-consumer handoffs. Production
release remains blocked by the upstream audit; no thresholds or dependency
overrides were changed.

S23 checkpoint-budget groundwork passed its build and all 30 selected transport,
reservation, manifest and journal checks (14.25 seconds). The first full-scope
build rejected the catalog status interface's old zero-argument declaration;
the implementation and interface now both accept the operation scope. The
corrected build and all 78 focused checks across 11 files passed (74.73 seconds),
including public Pod turn accounting, insufficient commit admission, restart,
retained output, and unchanged memory bounded-turn behavior. Conditional page
and root writes protect their PUT and first confirmation request; source request
credits remain separate. Session startup, selection, progress and finalization
share the turn budget. Uncertain checkpoint writes remain blocked, independently
of any budget error encountered while confirming them.

S23 archive harness development retains two failed 20-resource measurements:
the first used the unsupported publication target spelling `instanceContainer`
instead of the public `container` target; the corrected fixture then exposed
output delivery repeatedly conflicting with live source commits. Pod output
reads and acknowledgements now prepare within the existing context writer queue,
before the guarded commit, without remote callbacks inside a storage transaction.
The correction passed the build and all 18 selected output, store and portable
budget tests (20.79 seconds). The process-restart HTTP fixture then passed all
20 resources, exact redelivery, partial consumer acceptance, publication and
compaction in 55.136 seconds. Peak measured runtime RSS was 215,822,336 bytes;
fixture storage and consumer acceptance lived in the parent. It recorded 4,958
checkpoint PUTs, 1,749 GETs, 4,019 DELETEs, 98,180,610 checkpoint request bytes,
and peak stored checkpoint size 94,979,893 bytes. This is diagnostic evidence,
not archive qualification. The larger bounded consumer now drains full available
batches between turns while the initial streaming observation is still consumed
before the listing finishes; the concurrent-consumption result remains retained.

S23 real CSS qualification passed the new portable agent scenario (75.91 seconds,
including 71.81 seconds of test execution within the unchanged 120-second limit).
It covers exact root confirmation after a lost response, restored output without
source reads, explicit capacity backpressure, repeated acknowledgement, unknown
RDF publication with a caller-owned revision marker, an unknown patch outcome
reconciled by the consumer without replay, and compaction retaining outstanding
output. The CSS fixture deliberately uses its existing allow-all configuration;
private publication intent selects the destination and does not establish grants.

S23 retained 200-resource file-backed diagnostic: discovery and its finite recheck
sweep settled in 700.382 seconds, with 201 catalog Things and 292 source requests
(91 intentional conditional rechecks). Compaction was still executing when this
diagnostic was deliberately interrupted at 1,474.572 seconds to test the exposed
write-amplification corrections. The parent retained its failed report and cleaned
only its own fixture storage. Recorded checkpoint traffic reached 111,935 PUTs,
88,587 GETs and 77,483 DELETEs; peak stored checkpoint size was 1,930,746,057
bytes. The interrupted worker did not return its final peak-memory measurement.
The original console's 133,046,272-byte value covers only the initial process and
must not be treated as the whole diagnostic's peak. The harness now marks missing
process measurements explicitly and emits no aggregate peak for incomplete runs.
Neither this interrupted diagnostic nor the smaller passing fixture establishes
archive qualification. The report's older `retriedSources` counter included the
91 planned rechecks; subsequent reports call that counter `repeatedSourceRequests`
and report automatic HTTP retries separately.

S23 warm-preparation checks passed the build and all 28 selected tests across
six files (32.51 seconds), covering snapshot protection, prepared guards, all
cleanup faults, and public Pod restoration/budgeting. Catalog reads still pin
before an uncached read. Once catalog preparation and guards have completed,
root publication reads its own checkpoint metadata under the conditional writer
boundary without acquiring a redundant read pin. Existing pins remain held until
commit completion. The 20-resource diagnostic with batched consumption passed
in 32.577 seconds, with peak runtime RSS 204,488,704 bytes. It recorded 3,015
checkpoint PUTs, 288 GETs, 2,508 DELETEs and 68,726,475 request bytes. This run
also changes consumer batching, so its timing is not a controlled comparison
with the earlier concurrent-consumption run. Archive qualification remains open.

S23 lossless page-key encoding passed its build and all 45 selected tests across
10 files (50.33 seconds). The corrected cold-restoration assertion, which decodes
the physical key prefix before counting loaded Things, passed all seven bootstrap
checks (18.08 seconds). The 20-resource diagnostic passed in 33.176 seconds with
peak runtime RSS 203,100,160 bytes, 2,838 checkpoint PUTs, 225 GETs and 2,348
DELETEs. The new C3 fixture passed directly through public imports with three
source reads and 635 checkpoint requests; it has not yet passed the packed
supported-version handoff. A separate CPU-profile diagnostic retained its higher
profiling overhead and is not a memory qualification measurement.

S23 bounded immutable uploads first passed 37 of 38 selected checks. The new
fault fixture incorrectly represented a dispatched unknown write as an ordinary
unstructured Error, whose transport evidence defaults to queued. After replacing
it with the actual structured dispatched-mutation failure, the build and all 38
checks across six files passed (26.60 seconds). Upload intents still precede all
payloads; at most eight immutable pages upload concurrently. All admitted siblings
settle before a failed batch returns, and any unknown sibling keeps its allocation
unsealed. Finite HTTP-request budgets retain sequential reservation admission.

The following 200-resource diagnostic completed discovery and its known-resource
sweep in 299.215 seconds, retaining 201 catalog Things and 292 source requests
including 91 intentional rechecks. The edited Thing appeared before completion.
Compaction was deliberately interrupted at 551.103 seconds so the identified
preparation-buffer and confirmed-evidence corrections could be measured next.
Its retained failed report records 96,872 checkpoint PUTs, 35,869 GETs, 29,784
DELETEs, peak stored checkpoint size 1,528,730,781 bytes and no aggregate runtime
peak because the interrupted worker's final sample is unavailable. Automatic
HTTP retries remained zero. These timings use a memory-backed parent fixture,
whereas the earlier interrupted 200-resource run used files; they are not a
controlled performance comparison or the required archive qualification.

S23 confirmed-proof retention passed the build and all 41 selected checks across
six files (67.63 seconds), including repeated data/metadata commits and uncertain
displaced-writer reconciliation. The larger bounded preparation allowance first
passed 36 of 38 tests: one new record fixture used unsupported fields, and one
older assertion assumed an order between independent uploads. The corrected
fixtures retain the intent-before-payload requirement and all 38 checks passed
(34.37 seconds). Preparation now uses one quarter of the configured cache budget,
leaving three quarters for confirmed page bytes; the total configured default
remains 64 MiB.

The corrected 200-resource file-backed diagnostic passed discovery, finite
rechecks, process restart, output acceptance and final compaction in 1,165.535
seconds. Peak runtime RSS was 278,646,784 bytes and peak sampled heap was
149,263,168 bytes. Discovery settled in 479.738 seconds; the edit was visible
before completion. The consumer accepted 497 distinct observations, including
292 complete observations for 201 sources. Traffic included 70,701 checkpoint
PUTs, 66,223 GETs and 62,384 DELETEs; peak checkpoint storage was 1,278,626,998
bytes, ending at 35,668,737 bytes. Source reads totaled 292, including 91
intentional conditional rechecks and zero automatic HTTP retries. This is a
passing diagnostic with material write amplification, not the 100,000-resource
archive qualification.

S23 immutable-write confirmation passed the build and all 38 selected checks
across five files (23.85 seconds). A queued confirmation failure now retains the
original dispatched mutation's unknown evidence for both page and archive-intent
writes. The affected allocation stays unsealed. Source-summary index reduction
passed all 31 selected checks across seven files (71.64 seconds): exact summaries
use primary resource records, while aggregate scope indexes retain their existing
semantics. Its 20-resource file-backed diagnostic passed in 31.422 seconds with
peak RSS 238,661,632 bytes, 1,862 checkpoint PUTs, 141 GETs, 1,456 DELETEs and
34,458,978 checkpoint request bytes. Independent implementation and fixture
changes mean these timings are not controlled comparisons.

S23's 8 KiB target for ordered leaf pages passed the build and all 53 selected
tree, catalog, manifest, restoration and cleanup checks across nine files
(74.56 seconds). The configured maximum stays 64 KiB; an individual larger entry
can use that allowance. Old immutable snapshots and cold reads remain valid.
The 200-resource measurement and complete repository matrix remain in progress.
Future large-fixture runs record periodic memory/HTTP telemetry, distinguish
initial fixture sizes from transferred source bytes, and perform explicit
maintenance every ten bounded discovery turns. The consumer now publishes the
listing's BasicContainer class as an exact instance; content classes retain their
container registrations. Earlier measurements used a container registration for
that listing class and remain retained with that fixture limitation.


S23 completed the 200-resource, 8 KiB leaf-target diagnostic with both runtime
processes reporting final measurements. Total elapsed time was 1,059,993.913 ms;
peak runtime RSS was 299,835,392 bytes and heap 143,832,096 bytes. It accepted 497
observations, including 292 complete source observations and terminal evidence
for all 201 sources. The finite sweep made 91 conditional rechecks and found the
edit before traversal completed. Checkpoints used 73,346 PUTs, 68,426 GETs and
64,011 DELETEs; request/response bytes were 769,284,532/715,853,422. Peak checkpoint
storage was 743,743,335 bytes across 65,326 objects, ending at 35,229,120 bytes
and 6,480 objects after compaction. This is diagnostic evidence for 200 resources,
not the required 100,000-resource qualification. Its source includes uncommitted
changes over `454a829`; it is not an immutable development artifact.

S24's isolated packed C3 consumer passed on Node 22.23.2/npm 10.9.8 and
Node 22.12.0/npm 10.9.0. Both installed the same 425,131-byte archive with SHA-256
`40d01514624b9b01736bc048e6def5378dae6f1f106e9db7ed3d61606dacd90f` using declared
dependencies only. Baseline, C1, C2 and C3 fixtures all passed, including three
source reads, retained output on process replacement and explicit compaction.
The package was built from the working tree over `454a829`; final immutable
artifacts still require a clean pinned checkout. Packed consumer success does
not replace the archive, repository or production-release gates.

The updated 20-resource archive fixture also passed (39,685.130 ms, peak RSS
252,153,856 bytes, heap 108,713,536 bytes). Source-alias, repeated source-alias,
typed-page and inverse-page queries each made zero source requests and zero
checkpoint requests with warm data. Checkpoint traffic was 3,579 PUTs, 267 GETs
and 2,927 DELETEs; peak storage was 24,689,078 bytes. This run adds query evidence
and reports fixture sizes independently of transferred bytes. Larger runs
explicitly compact after every ten 100-job turns; the report declares that
consumer policy. No recurring runtime maintenance timer is introduced.


S23's first complete unit stage passed all 990 tests across 138 files in
749.77 seconds. The packed baseline and declaration smoke passed; verification
stopped at the isolated production audit (five moderate and one high finding),
so CSS, browser and performance gates continue independently.

The first 100,000-resource archive attempt was stopped after a separate
deterministic test exposed degenerate ordered-tree splits: 200 descending
insertions with eight-entry leaves/eight-child branches produced height 28 and
5,659 writes. Mutation splits filled the first page and left the next page almost
empty, so repeatedly inserting into the full path could deepen the tree instead
of preserving bounded lookups. Balanced mutation splits and a descending-order
regression are now in qualification; the ordered bulk builder retains its packing
policy. Existing immutable pages remain readable.

The interrupted large attempt retained early-output and early-publication evidence,
both before listing completion, but no final runtime peak measurement. At
511,704.828 ms it had made one source request, 54,692 checkpoint PUTs and 118
checkpoint GETs. Checkpoint request/response bytes were 791,473,002/210,072; peak
stored state was 787,096,499 bytes across 53,244 objects. It had received
11,364,581 of the listing fixture's 11,900,081 bytes. The generated source fixture
is 37,824,816 bytes. This failed attempt does not qualify the 512 MiB bound. Its
original report, frozen build/source fingerprints and the split-defect diagnostic
are retained under `artifacts/qualification/`.

S23’s first full real-CSS stage passed all 79 tests across 17 files in 402.39 seconds, including the portable-agent recovery/publication scenario. This run predates the balanced-split correction; its remaining browser and performance stages continue independently.

Bounded parallel cleanup passed the build and all 36 selected tests across five
files (63.95 seconds), including lost-response sibling draining, finite-budget
serialization, ownership displacement and pinned snapshots. The 20-resource
process diagnostic passed in 38,129.661 ms with peak RSS 230,252,544 bytes and
heap 80,166,432 bytes. It made 3,364 checkpoint PUTs, 255 GETs and 2,722 DELETEs;
peak checkpoint storage was 24,011,786 bytes. Cleanup still verifies candidate
page allocation before deletion and retains the entire durable claim after any
failure. Presence-only cache checks now avoid copying page bytes just to test
existence. These changes retain the configured cache and request limits.

Balanced mutation splits passed the build and all 55 selected tests across nine
files (78.45 seconds). The packed C3 consumer also executed the shipped public
turn example successfully on Node 22.23.2/npm 10.9.8. Its working-tree archive was
426,372 bytes, SHA-256
`36d04f074cdba19bcbcd3939fbb395d48cda2d2a209471764ba32b8921859671`.
The 200-resource restart diagnostic passed in 805,762.011 ms with peak runtime
RSS 300,556,288 bytes and heap 154,787,216 bytes. All 201 sources retained terminal
evidence; 497 observations were accepted, including 292 complete observations
and 91 conditional rechecks. Checkpoint traffic was 57,175 PUTs, 50,825 GETs and
48,504 DELETEs. Peak stored checkpoint state was 704,666,635 bytes, ending at
34,163,510 bytes. Cold alias, typed and inverse queries fetched checkpoint pages
without source reads; the repeated alias query used no HTTP. This candidate
predates parallel cleanup and does not qualify the 100,000-resource bound.

The first full CSS performance stage passed both scenarios in 46.60 seconds.
Combined tests now include measured transport dispatch/retry counters and a
smaller inaccessible-source recovery diagnostic; those results remain pending.
Earlier archive reports labelled automatic retries from the explicit execution
configuration. New reports obtain actual per-origin dispatch and retry counters
before close, and report missing counters as unavailable rather than zero.

The assembled candidate passed the build and all 50 selected transport, budget,
cleanup, ordered-tree and restoration tests across six files (65.94 seconds).
Its packed C3 consumer, including the shipped public example, passed on Node
22.23.2/npm 10.9.8 (427,485 bytes; SHA-256
`d1b5c52ce439f2904d08badcfb5d0a82ab20c47cc266b523e8aad2251f595f98`).
The 20-resource file fixture with `--unavailable-every 17` passed in 21,619.806 ms,
peaking at RSS 227,688,448 bytes and heap 92,713,904 bytes. It retained the
inaccessible observation and a later complete recovery under distinct attempt
IDs. Actual per-origin counters reported zero automatic retries. It accepted 44
observations, including 21 complete observations, and all four bounded query
checks made zero source requests. Checkpoints used 3,319 PUTs, 278 GETs and 2,609
DELETEs, peaking at 25,227,913 stored bytes. The configurable failure interval is
for small diagnostics; the required 100,000-resource fixture retains interval 997.

The earlier full browser stage passed all 18 Chromium/Firefox scenarios in
5.1 minutes. The final assembled matrix additionally covers explicitly stale
resource enumeration through the maintained summary index. Removing redundant
indexes had left that one caller selecting the removed status partition; a
colocated regression covers explicit staleness, startup staleness and fresh reads.

The final assembled unit stage passed all 996 tests across 139 files in
571.08 seconds with one worker. It includes the stale-source summary regression.
Verification again passed the packed baseline and strict declarations/browser
build before the unchanged isolated audit failure (five moderate, one high).
The required CSS, browser and performance stages continue independently.

The final archive reporting check passed its build and 20-resource recovery
fixture in 21,019.675 ms (peak RSS 224,665,600 bytes). Reports now include host
OS/CPU/memory details, per-phase restoration HTTP deltas, publication timing and
completed compaction work. The resumed process restored with seven checkpoint
GETs and zero source reads. Cleanup completed 80 steps over two calls, deleting
2,502 pages and 126 metadata objects while retaining its live references. This
run follows formatting/documentation-only TypeScript changes and reporting-only
harness changes after the assembled matrix was frozen; those differences do not
change the runtime's execution behaviour. The 100,000-resource gate remains open.

The final assembled real-CSS stage passed all 79 tests across 17 files in
236.64 seconds. Both CSS performance scenarios passed in 35.75 seconds. Browser
and discovery-performance stages remain in progress; the 100,000-resource gate
is still unqualified.

The final assembled browser matrix passed all 18 Chromium/Firefox scenarios in
4.3 minutes. The maintained discovery-performance stage is the remaining repository
gate before pinning the source for the complete archive measurement.

The final assembled repository matrix is complete: the semantic benchmark and
all 46 discovery-performance regression tests passed (36.71 seconds). The existing
10,000-resource memory benchmark finished in 110,465.060 ms, with first-ten results
at 2,262.272 ms, 10,001 source reads, 11,001 dispatched jobs and 10,002 completed
jobs. The materialized frontier stayed at 12 jobs; end RSS was 393,674,752 bytes.
This end measurement is not the portable archive peak-RSS qualification.

S23 is committed as implementation progress with its 100,000-resource gate still
open. Build, packed baseline, strict declarations, unit, CSS, browser and maintained
performance checks passed; the unchanged upstream audit blocks production release.
The committed runtime JavaScript matches the frozen matrix build byte for byte.
The next archive run uses a clean pinned source checkout. The first failed large
attempt and every smaller diagnostic remain retained; C3 and the final S24 handoff
must not be labelled fully qualified until the large run succeeds.

### S23 archive correction: pull output through the delivery boundary

The clean `ed679fadb01d86c7b2f920b8be6c827f11b4a0b3` 100,000-resource run was
stopped after 1,375.09 seconds to correct demonstrated output over-reading. Its
first process retained a partial listing after a network failure during HTTP 200
body consumption; the restarted process reread and completed that source. The
original failure remained separate from the completed observation. The underlying
transport cause was not established. The retained report is incomplete and does
not establish the archive RSS bound.

A deterministic diagnostic queued 100 observations, requested a 30,000-byte
batch, delivered one 20,770-byte observation, and recorded 100 pending values
loaded for delivery and another 100 for acknowledgement. A read-only worker
sample also showed repeated typed-array construction from string iterators while
decoding blob pages. The correction pulls portable journal values from a pinned
snapshot until the batch boundary, stops redelivery and acknowledgement at the
retained last sequence, and fills decoded byte arrays without allocating a
character array. Receipt contents, ordering, validators and checkpoint schemas
are unchanged.

The initial focused run passed 41 tests across five files in 31.98 seconds. The
new output regression reads two records to determine a one-observation byte
boundary, then one record each for redelivery and acknowledgement. The separate
20-resource diagnostic with one inaccessible-then-recovered source passed in
34,492.11 ms with peak runtime RSS 230,244,352 bytes. Its source HTTP count was
22 and measured automatic retry count was zero. This smaller run does not qualify
the 100,000-resource gate. The snapshot-lifetime regression and full repository
matrix are still required before committing this correction.

The frozen output correction passed all 999 unit tests across 139 files in
516.31 seconds, including stable journal iteration across a concurrent commit
and pin release on early return. Build, packed baseline, strict public declarations
and packed browser build passed. Verification stopped only at the isolated audit
with six upstream findings (five moderate, one high). The independent CSS,
browser and performance stages and the 200-resource diagnostic remain in progress.

The 200-resource output-correction diagnostic passed in 433,053.84 ms with peak
runtime RSS 290,840,576 bytes. It accepted 497 observations, including terminal
evidence for all 201 sources, and performed 91 finite known-resource rechecks.
The edited Thing appeared before discovery settled. Queries made no source HTTP;
the warm source-alias query made no checkpoint HTTP either. The run made 56,700
checkpoint PUTs, 50,375 checkpoint GETs and 48,060 checkpoint DELETEs. Logical
checkpoint storage peaked at 697,125,419 bytes and ended at 34,104,908 bytes.
Cleanup completed 1,156 steps over 19 calls and retained no unresolved epochs.
These request and storage costs are retained alongside the successful checks.

The independent CSS matrix passed all 79 tests in 17 files (279.39 seconds);
its two performance checks also passed (32.11 seconds). The fixture's new
optional `gzip-file` backend passed three HTTP-equivalence/storage-accounting
checks across memory, file and compressed-file storage. A separate compressed
20-resource recovery run passed with the same runtime JavaScript as the frozen
matrix; compression is confined to the parent fixture's files and does not
change HTTP representation bytes or runtime limits. Stored-file byte counters
exclude filesystem allocation and directory overhead. Browser and discovery
performance results remain pending.

All 18 Chromium and Firefox browser tests passed (5.7 minutes). The compressed
20-resource diagnostic completed in 26,058.24 ms with peak runtime RSS
231,821,312 bytes. Logical checkpoint bytes peaked at 25,276,857; encoded fixture
files peaked at 2,762,920 bytes, excluding filesystem allocation overhead. Source
HTTP remained 22, automatic retries remained zero, and restoration made no source
requests. The final discovery performance gate is still running.

The output correction's full repository matrix is complete: all required
engineering stages passed, with the upstream production audit remaining the
only verification blocker. The semantic-profile benchmark passed; the final
46 regression tests passed across six files in 44.19 seconds. The existing
10,000-resource memory fixture completed in 131,458.22 ms, returned its first
ten results at 3,015.96 ms, made 10,001 source reads, dispatched 11,001 jobs and
completed 10,002, with at most 12 materialized jobs. End-of-run RSS was
402,513,920 bytes; this is not a peak measurement or the portable archive gate.
The main and frozen builds contain 217 byte-identical runtime JavaScript files.
Fixture compression and its three HTTP checks were added after the full freeze
and qualified separately by the compressed 20-resource recovery run. The next
100,000-resource run and final immutable C3 handoff remain required. No package
was published and no dependency override or audit waiver was introduced.


S24 retained root-upload gap (2026-09-11): reviewing the updated agent integration
handoff identified an untested interruption boundary. Existing CSS tests lost a
response only after a complete manifest PUT. A real CSS diagnostic using file
storage and standard uncached middleware interrupted the live conditional JSON
PUT after its prefix reached the backing file. The remaining root was invalid
JSON with a changed ETag. The same interrupted N3 Patch preserved the previous
RDF bytes and ETag; create-if-absent N3 Patch also succeeded with HTTP 201.
The pinned `6d7478f` packages predate this correction and do not qualify root
atomicity, despite their passing packed consumers.

The 100,000-resource run was stopped for this correction. It retained a completed
initial listing (443.452 seconds, peak RSS 292,024,320 bytes), first output at
659.903 ms, first publication at 1,055.623 ms and restoration without source HTTP.
The interrupted complete run lasted 1,065.941 seconds, observed 432 source requests
including 91 rechecks and accepted 2,401 observations. It issued 142,737 checkpoint
PUTs and 7,021 checkpoint GETs; peak logical checkpoint size was 2,144,889,207 bytes
and encoded fixture storage 192,097,337 bytes. Missing final worker measurements
mean it does not establish the archive RSS bound or complete qualification.

The correction changes root publication to conditional N3 Patch on `manifest.ttl`,
with canonical JSON state in a bounded RDF literal and the shared RDF parser.
Immutable pages, original validators, writer fencing and operation reconciliation
remain part of the same commit boundary. Draft JSON roots fail explicitly without
migration or deletion. The first focused unit run passed 39 of 40 tests; its sole
failure was the restoration measurement trying to parse the new RDF root as a JSON
page. That measurement now excludes the root when counting hydrated Thing pages.
Real CSS interruption and the full corrected qualification gates remain pending.


The corrected root passed all 51 focused persistence/budget/cleanup tests across
seven files (66.41 seconds) and all three fixture HTTP checks (693.84 ms). Both
real CSS scenarios passed in 169.29 seconds: live root-upload interruption and
portable discovery/output/publication/cleanup. The C3 packed consumer and shipped
public example passed from the working-tree candidate on Node 22.23.2/npm 10.9.8.
An initial artifact-output invocation was rejected before consumer execution
because immutable archives require a clean checkout; the corrected working-tree
qualification requested no immutable artifact.

The corrected 20-resource gzip-file diagnostic passed in 35,706.73 ms with peak
runtime RSS 209,866,752 bytes. It made 22 source requests, zero automatic HTTP
retries, 3,132 checkpoint PUTs, 191 root PATCHes, 281 checkpoint GETs and 2,613
checkpoint DELETEs. Logical checkpoint storage peaked at 25,244,144 bytes and
encoded fixture files at 2,763,949 bytes. Restoration made zero source reads.
These measurements do not qualify the 100,000-resource archive. The frozen
full matrix has passed build, packed baseline and strict declarations/browser
build; verify stopped at the same six upstream audit findings. Its remaining
unit, CSS, browser and performance stages continue independently.


The corrected frozen unit matrix passed all 1,003 tests across 140 files in
583.65 seconds with one worker and unchanged thresholds. The full CSS, browser
and performance gates remain in progress; no 100,000-resource result or corrected
immutable package is claimed at this point.


The full corrected CSS suite passed all 80 tests in 18 files (318.49 seconds),
and both CSS performance tests passed (32.29 seconds). The main and frozen
working-tree builds contain 218 byte-identical JavaScript files, including the
new root document codec. Browser and discovery performance qualification continue.


All 18 corrected Chromium and Firefox browser scenarios passed (4.4 minutes).
The discovery performance gate remains in progress.


The corrected root's repository matrix is complete. The semantic-profile gate
passed, the 10,000-resource memory fixture completed in 117,667.35 ms with first
ten results at 2,403.22 ms, and all 46 final performance regression tests passed
across six files (43.19 seconds). The fixture made 10,001 source reads, dispatched
11,001 jobs, completed 10,002 and held at most 12 materialized jobs. End-of-run
RSS was 413,638,656 bytes; this is not a peak measurement or portable archive
qualification. All unaffected engineering stages passed. `npm run verify` still
fails at the six-finding supported upstream dependency audit. No dependency
substitution, audit waiver, version change or publication was introduced.

The correction is ready for a new source-pinned artifact. Minimum/current packed
consumers and the full 100,000-resource archive remain separate handoff gates.
Draft artifacts through `6d7478f` retain their narrower original test evidence and
the documented root-upload limitation. No complete C3 archive qualification is
claimed from this correction's smaller diagnostic.
