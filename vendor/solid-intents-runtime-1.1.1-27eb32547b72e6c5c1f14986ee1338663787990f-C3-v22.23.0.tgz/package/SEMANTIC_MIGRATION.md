# Soukai semantic-profile migration

Target: runtime 2.0.0, write-plan version 3. No intermediate release.

Status: **migration complete, release blocked**. Slices 1–14 are implemented and
committed; slice 15 remains open for upstream dependency qualification. The package
version deliberately remains 1.1.1 on this unpublished migration branch until that
gate passes. See [the consumer migration guide](MIGRATION_2.md).

The runtime owns source reads, catalog projections, explicit conditional writes,
and operation outcomes. Soukai owns internal profile models and serialization of
supported fields. Existing RDF is never replaced with a model serialization.
Custom profiles remain declarative; no public Soukai objects or I/O-capable models.

## Commit checklist

- [x] 1. Legacy/native compatibility fixtures and baseline (53 tests; build passed)
- [x] 2. Isolated packed-consumer checks and pinned Soukai pair
- [x] 3. Central semantic profile registry (build and all 581 unit tests pass)
- [x] 4. Isolated Soukai codecs (build and 20 codec/validation tests pass)
- [x] 5. Shared catalog/view projections and diagnostics (606 unit tests, including
  the corrected consistent-type fixture; 10,000-record cold/warm local queries)
- [x] 6. Source-based uncataloged Thing resolution (build and 106 targeted tests pass)
- [x] 7. Profile-derived validation (build, 90 runtime/validation tests and 16
  targeted shape tests pass; incomplete foreign edits validate changed fields)
- [x] 8. Version-three persisted plans: asynchronous API, v1/v2 rejection, stable
  fingerprints, exact identities, serialized payloads and frozen metadata;
  source-bound payloads completed with slices 9–11 below.
- [x] 9. Source-bound conditional field updates (build and 631 unit tests pass;
  reviewed JSON round-trips, ambiguous aliases, validator drift and partial failures)
- [x] 10. Pinned type-index registration and reclassification (build, 86 existing
  runtime/reader/update tests and 9 focused index tests pass; same-source effects
  coalesce, mixed-class registrations reject, unavailable registration skips)
- [x] 11. Native resource creation and safe content ownership (all 26 built-ins,
  custom fields, binary content, races and partial failures; full 669-test run
  exposed two legacy-contract assertions, corrected and all 121 affected tests pass)
- [x] 12. Remove superseded models and mapping paths (build, all 658 unit tests,
  and 12 live Pod/type-index contract tests pass; architectural isolation gates)
- [x] 13. Integration, fault, and 10,000-record acceptance coverage (build,
  all 661 unit tests, 73 local Pod/CSS tests and both live performance gates pass;
  every declared field of all 26 built-ins round-trips; packed Node/TypeScript/
  browser checks pass on Node 22.12.0 and 22.23.2, production audit remains blocked)
- [x] 14. Consumer migration documentation (native defaults, custom fields/views,
  source-bound edits, v3 replanning, timestamps, ownership, performance tradeoffs
  and the upstream-only release gate; guides included in the packed file list)
- [ ] 15. Upstream dependency qualification and release artifact

## Release constraint

Upstream releases only: no fork, vendor build, consumer override, postinstall
patch, or audit waiver. The current Soukai Solid 0.7.1 / solid-utils 0.6.1 chain
uses JSON-LD 8 and has a known production-audit blocker. Implementation may finish
while release remains blocked. Publishing requires separate authorization.

The isolated Node 22.23.2 CRUD consumer, strict TypeScript declarations, browser
build, and single-Soukai-instance check pass with the pinned 0.7.1 pair. The
unmodified packed consumer audit fails with six reported vulnerabilities through
`soukai-solid → solid-utils → jsonld@8 → http-client@3 → undici@5`.
This is a failing release gate, not a waived check.

The final packed consumer also passes CRUD with custom typed profiles, strict
declarations and a browser build on the declared minimum Node 22.12.0. Both Node
lines report six vulnerable packages (five moderate, one high) in the isolated
consumer. The workspace production audit reports five (four moderate, one high),
the same dependency path without the consuming runtime package counted as an
additional dependent. Its suggested downgrade to Soukai Solid 0.5.2 was not
applied; it is not a qualifying release of the pinned 0.7 semantic integration.

The full local Pod/CSS matrix passes 73 tests across 15 suites; the separate live
CSS performance gate passes both request-budget tests. `npm run verify` still
exits unsuccessfully at the packed consumer production audit, so unit/integration
and performance gates are also run independently. Early concurrent verification
runs encountered fixture timeouts; the final integration/performance runs are
sequential, with bounded CSS startup error output and an outer hook deadline that
allows that error to be reported. The release gate itself has not been relaxed.
The final isolated unit run passes all 661 tests across 75 suites, including
all-field native creation and the 10,000-record persistence/projection checks.

Slice 15 must remain open: wait for a supported upstream dependency chain, pin
qualifying versions, repeat the complete matrix, then bump to 2.0.0 and qualify a
release artifact. No release version bump, audit waiver or publishing has occurred.

## Baseline

Before migration, 40 targeted vocabulary, snapshot, view, RDF patch, and public API
tests passed. Existing catalog delta and live CSS request-budget/performance tests
are the acceptance baseline; they must remain passing.

## Read benchmark against slice 1

Run `node packages/runtime/scripts/benchmark_semantic_profiles.mjs` from the
workspace. The script compiles the actual read modules at slice-1 commit
`bfca2d75c4c9e9932cf594449ca7c3c93f4461c4` and the working tree into temporary
directories, without dependency changes or Pod access. Both process the same
10,000 legacy RDF-backed Note records, returning 20 synchronous Note views. Results
below are medians of three fresh Node 22.23.2 processes; each warm sample is the
median of 20 queries. Retained heap is measured after forced GC, not peak memory.

| Measurement | Slice 1 | Semantic profiles |
| --- | ---: | ---: |
| First query + result views | 21.2 ms | 211.8 ms |
| Warm query + result views | 8.2 ms | 15.7 ms |
| Retained heap above input dataset | 84,056 bytes | 2,441,888 bytes |
| Pod requests | 0 | 0 |

This is an explicit performance tradeoff: the first query now interprets raw
facts through profiles and retains revision-aware projections. Warm queries remain
local and bounded by existing gates, but this measurement is not a speedup claim.
It is a local Node microbenchmark, not a browser latency or peak-memory guarantee.
The separate fake-IndexedDB acceptance test covers 10,000 custom native records,
schema-1 migration, profile registration, restart, membership, missing/degraded
visibility, zero model hydration, zero network and zero startup record rewrites.
A one-resource refresh still performs exactly three puts (Thing, resource,
metadata) and no store clear; transaction rollback coverage remains in place.

Creation mutation counts for deterministic exact resource names, excluding the
same optional type-index PATCH in either implementation:

| Creation | Slice-1 effects | Semantic-profile effects |
| --- | --- | --- |
| Managed fields only | RDF PUT | RDF PUT |
| Explicit RDF extensions | RDF PUT + RDF PATCH | One complete RDF PUT |
| Content-backed Thing | RDF PUT + content PUT + RDF PATCH | Content PUT + complete RDF PUT |

Slice-1 counts follow its operation-aware creation executor and explicit extension
patch (`solid_graph_runtime.ts` at the baseline commit). Current native creation
tests count actual requests. New RDF/content PUTs are conditional; content ownership
is not asserted until this operation has successfully created that content.
Planning and reviewed commit can require additional source/index **reads** to pin
and validate approvals; the table describes mutations, not total HTTP traffic.
