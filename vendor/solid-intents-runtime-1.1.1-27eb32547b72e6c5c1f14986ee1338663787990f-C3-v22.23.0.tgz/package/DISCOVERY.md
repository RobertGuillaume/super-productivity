# Durable, progressive discovery

Discovery builds local knowledge progressively. It supports broad type discovery
(“find my photos”) and bounded exploration (“what is this linked to?”) through
one coordinator. Soukai still handles semantic profiles and values; it never
fetches resources or hydrates models during query filtering. Discovery performs
Pod reads, not Pod mutations.

## Render first, execute explicitly

```ts
await runtime.boot({
  podUrl,
  fetch: authenticatedFetch,
  discoveryIdentityKey: accountId,
});

const photos = await runtime.discovery.createSession({
  id: "photo-library",
  priority: "foreground",
  targets: [{ kind: "type", type: "Photo", webId }],
});
const stopRendering = runtime.things.subscribe(
  { type: "Photo" },
  (result) => renderPhotos(result.things, result.metadata.discovery),
  { scope: { kind: "discovery-session", id: photos.id } },
);
const stopProgress = photos.subscribe((snapshot) => renderProgress(snapshot));

// Cached query results do not wait for this call or implicitly cause it.
const result = await photos.run({ maxRuns: 10 });
if (result.reason === "budget-exhausted") showContinueAction();

// When leaving this screen, choose whether background work should continue.
await photos.pause();
stopRendering();
stopProgress();
```

Built-in authentication supplies the execution identity; no application identity
key is needed for it. For a supplied authenticated fetch, the key must be stable
for the account and must change when the account changes. It is a host assertion
for local partitioning, **not a credential, WebID, or proof of authorization**.
Without a key, supplied-fetch discovery is memory-only even if the catalog uses
IndexedDB. Do not share a key between different accounts.

The identity key partitions discovery continuation, not the entire Pod-scoped
catalog. When switching accounts must also discard cached knowledge, await
`runtime.auth.logout()` before booting the next account. Changing only a supplied
fetch/key selects another discovery partition while retaining the Pod's catalog;
it is not a local data-isolation/security boundary.

Creation, retrieval, listing, refresh preparation, and snapshot subscription do
local work only. An identical normalized definition and ID returns the existing
session; a conflicting definition throws `DiscoverySessionError` with code
`definition-conflict`. Omit the ID to generate one. Register custom semantic
profiles before creating type targets.

## Targets and boundaries

Targets are an ordered union. Their order expresses application priority, not a
requirement to finish one target before starting another. Sessions default to
background priority. Eligible foreground/background work is selected 3:1, with
round-robin selection between sessions in each band.

```ts
const exploration = await runtime.discovery.createSession({
  id: "selected-project",
  targets: [
    { kind: "graph", uri: selectedThingUri, maxDepth: 2 },
    { kind: "container", uri: selectedContainerUri, recursive: true },
  ],
  allowedOrigins: [new URL(podUrl).origin, "https://collaborator.example"],
});
```

| Target | Default and coverage boundary |
| --- | --- |
| `type` | Uses profile class mappings and WebID public/private type indexes; optional `webId` overrides the authenticated identity. |
| `container` | Recursive by default; `recursive: false` covers direct members only. URIs must end with `/`, without query or fragment. |
| `graph` | Depth two by default; depth zero reads only the root, depth N includes at most N edges. Optional `predicates` restricts traversed facts. |

Omitting `allowedOrigins` permits cross-origin HTTP(S) traversal. Supplying it
restricts reads to those exact origins. This is a traversal boundary, not an
authentication grant; browser CORS and resource permissions still apply. Unknown
useful URI predicates can be traversed; structural predicates such as RDF class
assertions do not trigger vocabulary crawling. Cycles terminate, shorter paths
can allow further expansion, and known content aliases/external subjects use
their actual source documents. Multiple Things in one source remain distinct.

Type discovery automatically falls back to the current Pod root when registrations
cannot provide usable coverage. Set `fallbackStorageRoots` to selected container
URIs to narrow that scan, or `[]` to disable fallback. Pending registered work with
temporarily empty results does not itself trigger fallback. A removed registration
removes membership in that discovery scope; it does not mean the resource is gone.

Discovery obtains RDF descriptions and file metadata, not photo/video/binary
bodies. Request content explicitly with `things.content()` or preview APIs.
Existing graph inverse-writing and semantic write-plan version 3 are unchanged.

## Execution and lifecycle

`run()` resumes the current pass with defaults of 100 scheduler runs, each bounded
to 100 job dispatches. `maxRuns` changes that budget. `maxDurationMs` is a soft
deadline and `signal` stops further dispatch; neither promises to interrupt an
already active HTTP request. Delayed retry work is awaited until ready within the
budget. HTTP pacing, concurrency, rate-limit retries and origin cooldowns remain
at the networking boundary.

| Run reason | Meaning / next action |
| --- | --- |
| `settled` | No unfinished or delayed work remains. Check coverage: failures can still make it partial. |
| `budget-exhausted` | Continuation remains. Call `run()` again when appropriate. |
| `paused` | Unfinished obligations retained. Resume with `run()`. |
| `aborted` | Dispatch stopped by the signal. A later `run()` can continue. |
| `cancelled` | Terminal session; unfinished work discarded after active reads finish. Create a new session to restart. |
| `owned-elsewhere` | Another context owns execution. Retain cached results and try explicitly later. |
| `blocked` | Inspect diagnostics: persistence, profile drift, or unresolved dependencies prevented continuation. |

Concurrent `run()` calls on one session throw `already-running`. `pause()` and
`cancel()` wait for active reads and persistence. Neither deletes cataloged Things.
`refresh()` requires the previous run to have stopped and prepares a new generation
without HTTP. Cached scoped results remain available while new coverage is partial.
Even a 304 container listing causes present children to be checked during a new
pass: unchanged membership does not imply unchanged child contents.

```ts
const restored = await runtime.discovery.getSession("photo-library");
if (restored) {
  renderProgress(restored.snapshot()); // Restoration never starts Pod requests.
  await restored.run();               // Explicit resume, not a new pass.
  await restored.refresh();           // Local preparation only.
  await restored.run();               // Explicit fresh observation pass.
}

const summaries = await runtime.discovery.listSessions();
// To remove an active session, first await its cancellation.
await restored?.cancel();
await runtime.discovery.deleteSession("photo-library");
```

Deletion removes session bookkeeping and unreferenced discovery snapshots, not
cataloged Things. A cancelled session is terminal until deleted; delete/recreate
produces a new incarnation and old handles remain invalid. Reboot, logout, and
identity changes retire old runtime services. Late responses cannot repopulate
cleared state. Logout finishes durable cleanup before handing control to an auth
client that may navigate away.

Changes to relevant profile class mappings block a pass with `profile-changed`
until explicit `refresh()`. Field-only profile changes update local projections
without restarting traversal or migrating Pod data.

## Coverage is not a result count or a freshness guarantee

Snapshots separately report resources observed, available, missing, unavailable,
invalid, and failed; job counts; pending expansion entries; delayed retries;
`nextRetryAt`; timestamps; and diagnostics. These are not a known total number of
matching Things. One RDF source can contain multiple Things or no matching Thing.

Coverage reports `unknown`, `partial`, or `complete`, plus its basis:
`registered-locations`, `container-tree`, `bounded-graph`, or a mixture. A listing,
processing all listed members, and exhausting a traversal boundary are distinct
facts. Unresolved failures keep coverage partial even when execution is settled.
Authoritative absence resolves an observation; inaccessible or invalid sources do
not prove absence. A complete pass describes observations over an interval, not
an atomic snapshot of an entire Pod.

Completing type-index registrations proves coverage of **registered locations**,
not exhaustive Pod-wide inventory. A completed graph is complete only within its
depth/predicate/origin boundary. A completed container tree covers the selected
roots, not unlinked storage elsewhere. Prior successful observations may be stale.

Session-scoped queries/subscriptions remain entirely catalog-only. Type targets
select matching types, while container and graph targets retain generic Things
and unexpected connections. Scope and missing-record visibility apply before
deduplication, ordering, and limits. Only records confirmed missing are hidden;
stale, refreshing, inaccessible, and invalid cached knowledge stays readable with
aggregate degradation diagnostics. `Thing` never exposes catalog `recordStatus`.

```ts
const page = await runtime.diagnostics.inspectDiscoverySession(photos.id, {
  limit: 25, // 1–100, default 50
});
renderFailures(page.work.entries);
renderCoverageExplanation(page.coverage.entries);
if (page.work.nextCursor) {
  const next = await runtime.diagnostics.inspectDiscoverySession(photos.id, {
    limit: 25,
    workCursor: page.work.nextCursor,
  });
  renderFailures(next.work.entries);
}
```

Cursors independently paginate work and coverage. They are opaque and
generation-bound; restart pagination after refresh. Use
`diagnostics.inspectThing()` for per-record investigation. Query subscribers can
receive meaningful coverage changes even when the result count is unchanged.
The first fresh result is published after commit; subsequent updates coalesce
after ten completed resources or 50 ms, with terminal changes always flushed.

## Durability and browser ownership

IndexedDB schema 3 stores catalog knowledge, session work, immutable listing pages,
cursors, membership, receipts, leases, and change tracking in one database.
Schema-1/schema-2 upgrades preserve cached Things without startup store rewrites.
An observation commits catalog effects, its receipt, and new obligations together.
Parsing happens outside the transaction; mirrors and notifications update only
after commit. A crash may repeat a GET, but must not lose committed obligations
or double-count completed work. This is not exactly-once networking. Keeping the
bookkeeping in the catalog database permits the shared atomic boundary defined
by [IndexedDB transactions](https://www.w3.org/TR/IndexedDB-3/#transaction-concept).

Complete listings use pages of 256 entries, with children materialized ten at a
time. Advancing a cursor and recording child work are atomic. A 304 preserves
prior authoritative membership and unfinished expansion; missing usable snapshot
data triggers one unconditional recovery read. Failed listings preserve cached
members and never imply deletion. `storage.listContainer()` remains read-only.

Ownership is database-scoped. [Web Locks](https://www.w3.org/TR/web-locks/)
coordinate live tabs; the runtime's 30-second IndexedDB
lease, renewed every five seconds, supplies durable fencing. A crashed tab may
require lease expiry before handoff. Expired owners and obsolete generations
cannot commit late observations. Revision checks and a bounded 1,024-revision
change log synchronize mirrors even when broadcast hints are missed; lagging
mirrors reload read-only. Old generations and unreferenced pages are cleaned in
bounded batches, not retained as a discovery-history archive.

Durability depends on browser storage availability and retention. Storage can be
evicted or cleared, private browsing may limit retention, and quota/upgrade errors
are classified rather than disguised as successful persistence. Plain Node is
explicitly memory-only; process exit loses discovery continuation. There is no
new Node persistence backend or offline edit queue.

## Migrating application coordinators

Replace application-owned listing queues, pagination checkpoints, and graph
visited sets with sessions. Keep application policy: selected targets and roots,
target ordering, foreground/background priority, origin restrictions, rendering,
and when to resume or refresh. Do not create an inferred workspace layout.

Legacy `start()`, `refresh()`, `discoverType()`, `settle()`, and
`reconcileContainer()` use the same coordinator and retain bounded behavior.
Global `pause()`, `resume()`, and `cancel()` keep their synchronous signatures;
session methods add awaitable barriers. Legacy calls do not implicitly resume
unrelated restored sessions. Legacy cancellation allows a later explicit start
to create fresh intent; that does not make a cancelled named session resumable.

`start()` returning does not mean a whole collection is finished. Expansion and
graph-processing jobs count toward its bounded turn, not only HTTP reads. Use
`settle()` for explicit continuation, and inspect coverage separately:

```ts
await runtime.discovery.start({ storageRoots: [selectedContainerUri] });
render(await runtime.things.query({}, { autoDiscover: false }));
const continuation = await runtime.discovery.settle({ maxRuns: 100 });
if (continuation.reason === "budget-exhausted") showContinueAction();
```

There is no alternative discovery backend or feature flag. Browser and performance
qualification, along with the independent upstream dependency release gate, are
recorded in [DISCOVERY_MIGRATION.md](./DISCOVERY_MIGRATION.md).
