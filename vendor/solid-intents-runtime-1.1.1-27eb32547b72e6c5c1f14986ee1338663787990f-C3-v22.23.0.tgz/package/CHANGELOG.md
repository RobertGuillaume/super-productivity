# Changelog

## Unreleased

The semantic-profile migration targets **2.0.0**, but is not a released or
release-qualified version. The upstream-only production audit remains a hard gate;
see [qualification status](SEMANTIC_MIGRATION.md) and the
[consumer migration guide](MIGRATION_2.md).

One runtime-local profile registry now drives Soukai field serialization, native
RDF creation, source-preserving updates, typed views, catalog projections,
validation and pinned type-index classes. All built-in views retain their shapes;
custom profiles need no Soukai imports. Unknown RDF remains available without a
model round-trip, including external subjects and multi-Thing sources.

Breaking changes: `planCreate()` and both `planUpdate()` forms are asynchronous;
all plans use version 3 and reject older approvals before network access. Semantic
creation uses exact conditional `rdf.create` effects and native primary classes.
Task, Note and Concept default bindings change while legacy read/update bindings
remain supported. Typed edits require source validators unless explicitly opted
out, reject ambiguous encodings and duplicate assignments, and never coerce invalid
managed values. See the migration guide for field, timestamp and content semantics.

Added declarative `fields`, `types.view()`, strict managed-profile validation,
projection diagnostics, explicit reclassification and exact planned index changes.
Content is created before its owned RDF reference, and completed network effects
are recorded before reconciliation. Superseded generic models, global Soukai
engines, duplicated mappings and handwritten shape artifacts are removed.
IndexedDB remains schema 2 with no startup data rewrite or Pod-wide migration.

Catalog mutations now stage indexed, copy-on-write deltas without cloning or comparing the whole catalog. IndexedDB persists each prepared delta atomically, then updates the in-memory mirror. Startup hydrates persisted records directly, and maintenance operations share the mutation queue. Source/content indexes keep refresh, promotion, and status changes proportional to the affected records. Catalog schema v2 and existing cached data remain compatible.

Resource reads preserve HTTP status and response metadata when reading a body fails. `resources.read()` and `things.content()` throw `RuntimeError` with code `resource-read-failed` and a structured `details.failure`, distinguishing HTTP failures, transport errors, aborts, invalid JSON, and unavailable bodies. `ResourceReadOptions.accept` allows explicit content negotiation without changing raw-read defaults. Rate-limited reads include the origin's retry deadline when known.

Discovery persists the latest source-read observation for `diagnostics.inspectThing()`. Diagnostic summaries omit credentials, query strings, response bodies, and transport-error text; thrown errors retain their original cause. Uncataloged resources are not assumed missing, and temporary read failures continue to preserve cached semantic knowledge. Raw reads remain read-only with respect to the catalog; no persistence status is added to Things.

## 1.1.1

HTTP scheduling now adapts automatically to Pod overload. Each exact origin starts at its configured interval and concurrency. A 429 episode doubles the effective interval to between 1 and 30 seconds, halves concurrency to at least one, and pauses queued dispatch. An explicitly slower baseline remains respected. Concurrent 429s extend cooldown without applying repeated reductions. After cooldown, each 20 non-429 responses recover one concurrency slot and reduce the interval to 75%, without exceeding configured capacity. Requests already in flight finish normally; queued requests remain spaced as dispatch resumes.

Valid delta-seconds and HTTP-date `Retry-After` instructions are honored without the former 60-second cap. Exponential fallback delays add 0–25% positive jitter and remain capped at 60 seconds. Retry limits and the existing 429-only retry policy are unchanged. A final 429 still protects later requests through the origin cooldown. Adaptive state is transient.

`diagnostics.status().requestScheduling` exposes origin-only scheduling snapshots. `diagnostics.subscribeRateLimits()` emits one structured event per overload episode. Built-in OIDC transport, supplied authenticated fetches, discovery, storage, sharing, and writes use the runtime scheduler.

`share.resolvePermissions()` reports final rate limiting as `unknown` with reason `rate-limited` and an optional `retryAt`. It does not infer denied access or accept a fallback grant after a rate-limited ACL read. The compatibility `share.permissions()` wrapper still returns an empty array for unknown access.

No adaptive scheduling configuration or persisted-data migration is required. Catalog schema v2 and v1 migration, transactional catalog deltas, discovery reconciliation/settling/cancellation, native Vtodo-to-Task mapping, fallback ACL provenance, and write-plan version 2 remain in place.

Historical packaging limitation: 1.1.1 used a consumer HTTP-client override for
standalone Node 22 installs. The 2.0 migration supersedes that workaround with
unmodified upstream dependencies and a mandatory production-audit gate. The
overload policy itself requires no configuration.
