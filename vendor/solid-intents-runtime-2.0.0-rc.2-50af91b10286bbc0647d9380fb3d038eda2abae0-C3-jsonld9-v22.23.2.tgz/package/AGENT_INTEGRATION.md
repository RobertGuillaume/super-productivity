# Headless integration with the private 2.0 prerelease

Use a pinned `2.0.0-rc.2` archive and its SHA-256 report. The package version alone
does not identify the qualified bytes; retain the exact commit and digest.
The report names the exact commit, tested Node/npm versions and selected packed
contract. Repository, archive-memory and production-release qualification are
separate evidence. Production release remains blocked by the upstream dependency
audit. Private applications own the documented JSON-LD 9 override; the runtime
package contains none. This work does not publish a package.

## Start with an explicit owner and lifetime

Supply an authenticated fetch. `identity` asserts the principal, data owner and
application namespace; it does not authenticate that fetch or grant access.
The normalized principal, owner, Pod root and application namespace partition
catalog records, work, source aliases, subscriptions and coordination. An instance
cannot change an explicit binding. Restart with a new instance and the same
binding to reopen its state.

Select `execution: "explicit"` for a consumer-owned scheduler. Queries then use
known data without starting discovery. Explicit resource reads remain permitted.
Memory persistence uses no Node storage dependency. IndexedDB is selectable where
available. Pod persistence requires a pre-provisioned checkpoint container and
explicit `create` or `open`; it never falls back to memory. Opening claims a new
writer and restores sessions without running them.

Always await `runtime.close()` in `finally`. Close rejects new work, cancels queued
requests, aborts reads by default and allows dispatched writes to settle. Its
default deadline is 30 seconds. Repeated calls share the same close operation.
A timeout reports unsettled operations and leaves late results fenced. Logout
remains a separate destructive lifecycle action.

The [executable turn example](scripts/examples/portable_agent.mjs) accepts a caller
fetch and an idempotent durable batch consumer. It opens or creates a session,
accepts retained output, executes one bounded turn, accepts newly committed output
and closes the runtime. Import it from the unpacked development archive or copy it
into your application; it imports the runtime's public package entrypoint only.

## Public API map

| Work | Public entrypoint | Network and ownership |
|---|---|---|
| Read exact bytes or RDF | `resources.read`, `resources.readRdf` | Explicit source reads; RDF uses runtime-owned batches and terms |
| Observe type-index pointers | `typeIndexes.discover` | Owner profile and allowed preferences; does not read every advertised index |
| Inspect one index | `typeIndexes.read` | Exact allowed index; unknown classes and unrelated triples remain observable |
| Conditional create or peer POST | `writes.planResourceCreate`, `writes.planResourcePost`, `writes.commit` | Exact destination and serialized payload; no automatic POST retry |
| Conditional replacement/deletion | Existing replacement/deletion planners with `validator` | The caller's original validator survives planning and commit |
| Exact N3 Patch | `writes.planRdfPatch` | Approved serialized bytes; validator or explicit unversioned consent |
| Exact registration publication | `writes.planTypeIndexPatch` | Pinned index, owner, privacy intent, registration IDs, classes and targets |
| Prepare/resume discovery | `discovery.createSession`, `getSession`, `session.run` | One maintained coordinator; explicit continuation and budgets |
| Recheck known members | `session.recheckKnown({ checkedBefore })` | Finite sweep at its preparation revision; preparation does not start execution |
| Consume observations | `session.readOutput`, `acknowledgeOutput` | One outstanding ordered delivery per session, retained until acknowledgement |
| Query known Things | `things.queryPage` | May read missing checkpoint pages; does not discover source resources |
| Inspect/collect checkpoint debt | `checkpoints.maintenanceStatus`, `checkpoints.maintain` | Cached status and bounded reclamation; never discovers source resources |
| Repack/reconcile checkpoints | `checkpoints.compact`, `checkpoints.reconcile` | Explicit full index repack or exact uncertain-operation reconciliation under writer fencing |

Discovery scopes compare container boundaries. Both `allowedOrigins` and
`readScope`, when supplied, apply before original requests and every redirect.
Explicit bindings default discovery to their Pod root and supplied owner-profile
entrypoint; additional external protocol resources require an allowance. Exact
peer writes do not enlarge discovery scope. Private publication intent requires
an appropriately protected destination supplied by the consumer; the runtime does
not create access grants.

Ordinary semantic creation retains automatic, opinionated type-index registration.
Exact publication uses the same RDF interpretation and patch compiler while
preserving the caller's selected destination and registration identities. Unknown
RDF classes need no semantic profile for inspection or exact publication. The
[packed C2 fixture](scripts/fixtures/headless_c2_consumer.mjs) demonstrates this
consumer-owned publication and reconciliation policy.

## Failures and continuation

Writes throw `RuntimeError` or `RuntimeWriteCommitError`. Inspect structured
outcomes and failure evidence instead of parsing messages. A validator conflict
remains a conflict even when proposed bytes equal the current resource. `unknown`
means the remote mutation may have succeeded: preserve its plan and evidence,
then apply your reconciliation policy. In particular, do not resend a POST merely
because its response was lost. Partial multi-operation results retain completed
effects and remaining operations.

Version-four plans pin their effective identity, source binding, payload and
preconditions. JSON round-trips preserve these fields. Explicitly bound contexts
reject unbound version-three plans before HTTP; legacy contexts retain their
existing version-three path. Versions one and two remain unsupported. Do not edit
serialized plans after approval.

`session.run` accepts job, HTTP-request and received-byte budgets. `maxRuns` remains
supported; combining it with `maxJobs` is invalid. Pod checkpoint HTTP counts
against the same turn. An admitted conditional checkpoint unit reserves its write
and first confirmation read. `insufficient-budget` can therefore return before a
unit dispatches. Budget exhaustion or abort preserves committed continuation;
uncommitted source work can require another read on the next explicit turn.
`retry-deferred` includes the next eligible time in the snapshot. `waitForRetry`
selects whether the turn waits for delayed work. Explicit transport defaults to
zero automatic retries.

On the checkpoint origin, Pod persistence reserves one HTTP slot so a streamed
source can persist observations before its body finishes. That origin requires
`requestScheduling.maxConcurrent` of at least two, considering any exact-origin
override. Other origins and memory/IndexedDB contexts retain their existing
one-slot support. Diagnostics report `reservedCheckpointSlots`. Adaptive overload
reduction preserves this dependency slot while already admitted bodies drain;
the configured hard concurrency limit still applies to all requests.

Discovery reads are parallel within bounded capacity; the ETag-guarded manifest
publication remains serial. The coordinator claims and commits up to eight source
units together. When four or more source slots are available, refill admission
uses a cohort so one unusually quick response does not permanently stagger later
reads into single-result roots. Each cohort prepares its receipts, authoritative
source state and observation guards from one protected snapshot. Results that
become ready while a compatible root is still being assembled may join that root
within the same eight-unit and 4 MiB bounds. Ready results otherwise flush when
the batch reaches either bound or 25 ms after its first unit. A streamed RDF source publishes its first nonempty
batch promptly, then coalesces up to 1,024 quads, 1 MiB or 100 ms. Immutable page
uploads and cleanup deletions use up to eight concurrent requests, while each
root becomes visible through one conditional manifest mutation.

Refill does not wait for a complete cohort when a partially consumed streaming
source has published children that must run before the producer can finish. It
also refills immediately when total transport capacity is below four. These cases
preserve forward progress for interactive and low-capacity callers without
changing the manifest boundary.

Effective source concurrency is capped at eight and also by transport capacity,
reserved output and the 4 MiB prepared-result queue. Diagnostics expose
`checkpointActivity.effectiveDiscoveryConcurrency` and `concurrencyLimitedBy`.
The default 128 MiB pending-output limit combined with the 64 MiB maximum expanded
source reservation can limit one session to two worst-case reads. Raising output
capacity or lowering the source limit can admit more reads without changing the
durability boundary. These are existing capacity controls; commit batching has no
public tuning option.

For Pod persistence, a finite request budget must have at least 17 requests
available before the runtime dispatches a source read: one source request plus a
conservative ordinary checkpoint-publication allowance. Smaller turns return
`insufficient-budget` without sending the source request. Durable expansion jobs
perform no source HTTP and keep their exact budget behavior.

`diagnostics.status().requestScheduling` reports per-origin `dispatchedRequests`
and `retryAttempts`. Dispatch counts include automatic retry attempts; retry counts
exclude later independent requests, queued cancellations and cooldown deferrals.
Read these counters before close when producing an execution report.

`output-blocked` pauses only the affected session. Accept and acknowledge retained
output, then explicitly run it again. Repeated reads return the identical batch,
even if a later read requests a different batch size. Acknowledgements are
idempotent; invalid, wrong-session and wrong-incarnation receipts fail. If a
consumer accepts only part of a batch before failing, deduplicate by observation
ID when it is redelivered. Ordinary cancellation retains unacknowledged output;
session deletion requires explicit output disposal to discard it.

Observations distinguish source identity, attempt identity and namespace-local
sequence. Preserve RDF lexical values, languages, datatypes, blank-node identities
and graph terms. Large facts may arrive as ordered `factFragment` pieces; concatenate
their decoded UTF-8 bytes before parsing the quad. Partial observations and failed
source reads cannot prove removals. Coverage reports the selected type-index,
container or graph boundary; it does not claim a complete Pod inventory or
preservation of remote edits that were never observed.

An unknown checkpoint root or a retained immutable archive upload stops further
mutations until `runtime.checkpoints.reconcile()` resolves its exact conditional
operation. The immediate failure may report `unknown-immutable`; later attempts
report `unknown-archive`. Both retain the same byte-identical operation for an
explicit reconciliation, without an automatic HTTP retry.
If immutable metadata at the same archive epoch and sequence contains different
bytes, the runtime reports checkpoint reason `integrity` and permanently fences
that instance. The last confirmed manifest remains authoritative and no output or
catalog state from the conflicting intent becomes visible. Reconciliation may
confirm identical bytes; it never chooses between branches. Continue by opening a
new instance with the same binding, which claims the confirmed root in a new
archive epoch. Retain the ambiguous old epoch for investigation.
Writer displacement stops admission and requires a new instance to explicitly
claim ownership. No lease timeout, automatic takeover or cross-writer merge is
implied. Read [portable checkpoint mechanics and limits](PORTABLE_CHECKPOINTS.md)
for snapshot retention, immutable allocation journals and resumable cleanup.

Internal claim, commit and acknowledgement preparations use the shared writer
boundary and do not publish remote read-pin roots. Public paged queries and
output reads can outlive a mutation, so they remain remotely pinned. Retained
output is ordered directly by its version-one primary keys; mixed older
namespaces with secondary output indexes remain compatible and require no
migration.
Local source and container-scope catalog candidates likewise use their ordered
Thing primary ranges. External RDF subjects and older version-one records retain
their secondary-index path, which the runtime merges without duplicates. This is
an internal storage optimization; query ordering, scope boundaries and cursors do
not change.

Use `maintenanceStatus()` to inspect cached reclamation debt and `maintain()` to
perform bounded collection without rebuilding live catalog indexes:

```ts
const status = await runtime.checkpoints.maintenanceStatus();
if (status.due) {
  const progress = await runtime.checkpoints.maintain({ maxSteps: 16, batchSize: 128 });
  // Call maintain again during a later explicit operation while !progress.complete.
}
```

Collection becomes due after 4,096 uploaded pages, 64 MiB of uploaded page data,
or when opening finds an unswept epoch. `force: true` starts it below those debt
thresholds. One bounded collection step may run after an explicit discovery turn
when the turn has capacity; no timer starts work while the runtime is idle.
`compact()` remains the explicit, more expensive operation that rebuilds primary
and secondary indexes before reclaiming the retired archive. Both operations are
resumable and fenced. Neither reads source resources.

## Limits and compatibility

| Bound | Default |
|---|---:|
| Root manifest | 16 KiB |
| Immutable page | 64 KiB and 256 entries |
| Branch fan-out | 128 children within the page limit |
| Resident checkpoint/catalog byte cache | 64 MiB |
| Delivery batch | 100 observations or 256 KiB |
| Pending output per session | 128 MiB |
| Source body | 32 MiB |
| Expanded source observation | 64 MiB |
| Catalog query page | 100 Things; maximum 1,000 |

Limits are configurable and reported by diagnostics. Source-limit failures retain
prior authoritative knowledge and report incomplete evidence. The cache bound
covers retained checkpoint state; materializing a large value or an unbounded
query still allocates proportionally to returned data. A query cursor pins a
catalog revision and fails if that revision is invalidated.

Existing browser boot/auth flows keep their defaults and legacy databases. There
is no automatic import of unattributed browser cache records into explicit identity
partitions. Portable checkpoint and observation records use version one; unsupported
versions require an explicit migration and fail with diagnostics. Draft JSON PUT
roots (`manifest.json`, through commit `6d7478f`) are explicitly rejected and
retained. Current roots use conditional N3 Patch on `manifest.ttl`; the 16 KiB root
limit includes its RDF serialization. Checkpoints
contain parsed facts and continuation, never credentials, original source bodies,
fetch capabilities, closures or a required local database.

## Reproduce the evidence

From a pinned source checkout with the declared dependencies and supported Node 22
and npm 10 installed:

```sh
npm run test:agent:contract -- --bundle C1 --dependency-profile jsonld9
npm run test:agent:contract -- --bundle C2 --dependency-profile jsonld9
npm run test:agent:contract -- --bundle C3 --dependency-profile jsonld9
npm run test:agent:archive:baseline
npm run test:agent:archive:prefix
npm run test:agent:archive
npm run verify
npm run verify:release
```

Packed consumers install only the archive and its declared dependencies into an
isolated directory. The C1-C3 commands above select the private application
override. `verify` is the passing engineering gate; `verify:release` additionally
exercises the ordinary dependency tree and remains the publication fence. The C3
consumer tests the public persistence/output contract;
it does not replace the separate 100,000-resource archive-memory gate. The archive
harness keeps its generated source fixture and acceptance storage outside the
measured runtime processes. Reports retain failures and missing measurements.
The baseline uses 200 resources. The prefix command uses the complete 100,000-
resource listing and intentionally stops after a bounded number of terminal
sources; pass `--stop-after-terminal-sources N` to the underlying archive command
for a different diagnostic boundary. An interrupted prefix never establishes the
full elapsed-time or final-RSS qualification.
See [the capability and qualification report](HEADLESS_INTEGRATION.md) for exact
runs, outstanding gates and the separate production release blocker.

The official 100,000-resource archive run passed its formal engineering gates on
the declared four-logical-CPU Intel Mac with Node 22.22.0 and npm 10.9.4. It
completed in 7 h 59 min 53.749 s, peaked at 526,991,360 bytes RSS and used
15.6169 operational checkpoint requests per terminal source. Explicit full
compaction accounted for 2 h 26 min 23 s and 2,348,005 additional checkpoint
requests. The run restored and served warm checkpoint-backed queries with zero
source HTTP. Its elapsed and RSS margins were narrow, and the stronger 6.5-hour
target did not pass; use these figures when planning checkpoint-container
capacity and maintenance windows.

For a local archive fixture with limited disk space, use
`npm run test:agent:archive -- --backend gzip-file`. This compresses only files
held by the fixture server outside the measured runtime. Source generation,
checkpoint HTTP payloads, validators, request accounting and runtime limits are
unchanged. Reports distinguish logical `checkpointBytes` from encoded fixture-file
`checkpointStorageBytes` and include each peak. The stored-byte counters exclude
filesystem allocation and directory overhead. The default `file` backend keeps
uncompressed fixture files; neither backend changes the runtime's Pod adapter.
Reports also separate operational checkpoint traffic from the final explicit
compaction and record source/index/checkpoint requests and bytes, publication
kinds, page reuse and retirement, commit-batch activity, source-progress pauses,
restoration reads and maintenance work.
