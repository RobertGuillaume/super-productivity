# Portable checkpoint implementation

Streaming source reads and their checkpoint writes share the maintained origin
scheduler. The checkpoint origin requires `maxConcurrent >= 2` and reserves one
slot for checkpoint requests. Queued source requests cannot obstruct that slot,
including while existing bodies drain after adaptive overload reduction. The
configured hard concurrency limit, cooldowns, cancellation and HTTP accounting
still apply. Diagnostics expose `reservedCheckpointSlots`; unrelated origins and
memory/IndexedDB persistence retain their existing scheduling policy.

Source HTTP and immutable checkpoint uploads run concurrently; conditional
manifest publication is deliberately serialized. The coordinator can claim and
commit eight source units per guarded root. Refills wait for a cohort of four
available source slots when capacity and the remaining finite job budget permit;
this keeps small-source completions batchable without delaying already prepared
output. A cohort prepares source receipts, authoritative snapshots and observation
guards against one protected revision. Results that arrive during compatible root
assembly can join that root within its existing bounds. The runtime flushes a
ready commit batch at eight units, 4 MiB of prepared data, or 25 ms from the first ready unit. The first
nonempty RDF batch from a source is published promptly. Later streaming batches
coalesce at 1,024 quads, 1 MiB or 100 ms. Completion, failure, cancellation,
capacity pressure and close flush immediately. Up to eight immutable pages upload
in parallel before one root publication makes their references visible; cleanup
likewise deletes up to eight pages concurrently.

Version-one ordered pages front-code adjacent keys and branch ranges on the wire.
New temporary discovery snapshots use padded, range-addressable page identities,
so streaming appends and cleanup do not maintain a duplicate `byGroup` tree for
those pages. Existing version-one snapshots retain their original identities and
index path; an interrupted legacy snapshot resumes with the same layout. These
are internal encoding choices and do not change checkpoint, page, portable-record
or observation versions.

Cohort waiting is bypassed when committed children of an active partial stream
need dispatch so the producer can continue, and when total transport capacity is
below four. This prevents a streaming producer or a small transport from waiting
on slots that cannot become free.

The effective source-read limit is the minimum of eight, transport capacity after
the checkpoint reservation, output-reservation capacity and prepared-result byte
capacity. The 4 MiB prepared queue pauses body pulling instead of buffering past
its bound. The default 128 MiB output backlog and 64 MiB maximum expanded source
reservation can therefore limit a session to two worst-case reads. Runtime
diagnostics report the effective limit and whether transport, output capacity or
prepared bytes currently constrain it. Root publication remains single-writer at
every concurrency level.

Finite request budgets on Pod-backed discovery reserve a conservative ordinary
publication allowance before reading a source. A turn with fewer than 17
available requests reports `insufficient-budget` without dispatching that source.
Pure expansion work performs no source HTTP and retains its existing exact budget
behavior. Automatic collection does not run after an insufficient-budget result.

The development runtime exposes explicit Pod persistence, acknowledged output,
checkpoint-aware turn budgets and resumable cleanup. Its 100,000-resource archive
fixture passed the declared correctness, elapsed-time, request and memory gates;
the final artifact matrix remains separate evidence. These capabilities are
unpublished. Start with the public API and failure-handling
walkthrough in [the agent integration guide](AGENT_INTEGRATION.md).

Version-one pages are UTF-8 JSON with a namespace-incarnation binding and a
SHA-256 content address. Page references pin both their hash and byte length.
Leaf pages hold at most 256 ordered entries; branches hold at most 128 children.
Both must fit the configured 64 KiB page limit. Large explicit values use ordered
blob pages. Branch summaries contain entry counts and boundaries so point reads,
range reads and partition counts do not load unrelated records.

The byte cache retains encoded immutable pages and evicts by least recent use.
Its default limit is 64 MiB, including an allowance for keys and cache bookkeeping.
Readers receive independent bytes and decoded values. The cache does not retain
parsed catalog graphs. Materializing one selected value or an unbounded result
still allocates in proportion to that result.

Catalog Things, resource observations, scope markers, discovery work, source
facts, receipts, membership, output and cleanup use versioned primary records.
Their envelope pins table and record identity. Dates and scheduling deadlines use
explicit tagged ISO timestamps; arbitrary RDF lexical forms, languages,
datatypes, source-scoped blank nodes and graph terms remain data. Checkpoints do
not contain fetch functions, credentials, executable closures, binary content or
original source response bodies. Oversized values and unsupported schemas fail
with checkpoint evidence instead of being silently truncated or migrated.

The secondary indexes reuse the catalog's existing semantic candidate tokens and
the discovery journal's existing partition definitions. Source and alias lookup,
RDF classes, inverse links, session membership, ready work, receipts, output and
cleanup therefore use the same interpretation as the memory and IndexedDB
implementations. Ready-work timestamps have a sortable numeric representation in
index keys; their stored scheduling values remain ISO timestamps.

A prepared table change returns a new pair of primary and secondary index roots.
It leaves older roots readable and unchanged. A page-write failure cannot publish
part of the proposed state. The Pod manifest adapter must conditionally publish
the resulting roots before catalog notifications or output delivery become
visible. Immutable pages staged before a failed root commit are cleanup work;
they do not establish a committed observation.

The official 100,000-resource archive qualification passed on the declared Intel
Mac with Node 22.22.0. It completed in 28,793,749 ms and peaked at 526,991,360
bytes RSS. Operational discovery used 15.6169 checkpoint requests per terminal
source; explicit full compaction added 2,348,005 checkpoint requests and
8,782,877 ms. The elapsed-time and memory margins were only 6.251 seconds and
9,879,552 bytes, and the stronger 6.5-hour target did not pass. Retained
measurements and the separate production release gate are listed in
[the capability report](HEADLESS_INTEGRATION.md).

The internal Pod adapter stores immutable pages in a pre-provisioned checkpoint
container and publishes their roots through a small conditional N3 Patch to
`manifest.ttl`. The root contains one `urn:solid-runtime:checkpoint:manifest`
literal with the canonical JSON manifest. Both create-if-absent and replacement
use N3 Patch; replacements keep the original strong ETag. The 16 KiB root limit
applies to the serialized RDF document, including literal escaping. Immutable
pages remain integrity-checked JSON.
Opening claims a new writer token; conflicts fence the displaced context.
Uncertain root outcomes retain operation evidence and stop mutations until
reconciled. A live writer also retains one bounded archive intent, its exact page
bytes and any unsettled seal when an immutable upload is interrupted. Explicit
reconciliation repeats the same conditional bytes and completes that retained
batch; it never substitutes a fresh precondition. An immediate archive failure
may report `unknown-immutable`, while later blocked mutations report
`unknown-archive`. Root publication remains the visibility boundary for the
shared prepared catalog/discovery effects.

Each archive epoch has one runtime-local sequence controller shared by every
operation view. The controller owns the next sequence, predecessor hash, pending
intent, serialization tail, seal state and fatal state for the lifetime of that
epoch. Reopening transport options or reconciling a missing response ETag cannot
replace or reset it. A pre-existing byte-identical intent confirms the retained
operation. Different bytes at the same epoch and sequence are an archive fork:
the runtime reports checkpoint reason `integrity`, permanently fences that
instance and never publishes the associated root. `reconcile()` cannot select a
branch. Open a new explicitly bound instance to claim the last confirmed
manifest and continue in a new epoch; the ambiguous old epoch remains retained.

The development boot path is explicit about identity and namespace ownership:

```ts
import { SolidGraphRuntime } from "@solid-intents/runtime";

export async function openArchive(authenticatedFetch: typeof fetch) {
  const runtime = new SolidGraphRuntime();
  await runtime.boot({
    podUrl: "https://pod.example/alice/",
    fetch: authenticatedFetch,
    identity: {
      principalWebId: "https://agents.example/worker#me",
      ownerWebId: "https://pod.example/alice/profile/card#me",
      applicationNamespace: "photo-catalog",
    },
    execution: "explicit",
    persistence: {
      kind: "pod",
      containerUri: "https://pod.example/alice/checkpoints/photos/",
      mode: "open",
    },
  });
  return runtime;
}
```

Provision the checkpoint container and its access policy in the consumer first.
Use `create` once to conditionally create the manifest; use `open` in a new
runtime instance to claim a new writer and restore its state. Neither mode falls
back to memory. Identity assertions do not authenticate the supplied fetch.

Reopening checks the manifest binding and supported versions before claiming
ownership. Catalog pages load on demand; boot does not enumerate all Thing
records. The compatibility cache of recently returned source aliases is capped
at 1,024 entries in Pod contexts, with larger identities resolved from the
persistent index. The checkpoint cache limit is available through
`runtime.diagnostics.status().checkpointLimits`.

The checkpoint container, advertised ACL resources and known type indexes are
excluded from recursive content traversal. Their intentional protocol reads
remain subject to the caller's read scope. Discovering an index pointer does not
grant access to that destination.

Boot, restart and exclusion paths passed the S21 engineering matrix; cleanup
passed the S22 matrix. The assembled C3 checks and official 100,000-resource
archive now pass their engineering gates. Production release remains separate.


## Routine collection and explicit compaction

Inspect cached maintenance debt without fetching source resources:

```ts
const status = await runtime.checkpoints.maintenanceStatus();
```

Routine collection becomes due after 4,096 uploaded pages, 64 MiB of uploaded
page payloads, or when an opened namespace has an unswept prior epoch. Perform a
bounded portion during an explicit application operation:

```ts
const progress = await runtime.checkpoints.maintain({
  maxSteps: 16,
  batchSize: 128,
});
// Call maintain again later while progress.complete is false.
```

`maintain()` rotates and seals the active archive, marks reachable pages and
collects unreachable pages and retired metadata. It does not rebuild the live
primary or secondary indexes. Passing `force: true` starts collection below the
normal debt threshold. Repeated calls below the threshold are cheap no-ops. The
runtime may perform at most one maintenance step after an explicit discovery turn
when maintenance is due and the turn is neither budget-starved, output-blocked nor
closing. It never starts a background timer.

Use explicit full compaction when repacking indexes is worth the extra work:

```ts
const progress = await runtime.checkpoints.compact({ maxSteps: 16, batchSize: 128 });
// Call compact again while progress.complete is false.
```

The defaults are 16 steps and 128 entries per step. An upload intent is indivisible and contains
at most 128 page references; small intents are combined within that bound. A call
accepts at most 1,000 steps and 128 entries per step. Cancellation and deadlines apply to checkpoint
HTTP. Maintenance never discovers source resources. Its persisted phase and
cumulative deletion counters describe progress; interrupted work resumes from
the checkpoint state in a new process. Calling after a completed cycle begins a
new finite cycle.

Full compaction rebuilds the primary and secondary indexes from validated stored
values in steps of at most 1,024 entries and 4 MiB, reusing blob pages by reference.
It publishes durable continuation for each step, then performs one guarded switch
after both trees are complete and collects the retired archive. Catalog mutation
remains serialized behind the context writer boundary during this explicit repack.
Catalog cursors are revision-bound and must be restarted if the final publication
invalidates them.

Repack input scans reuse validated encoded values without decoding application
records or referenced blobs. Input tree pages are decoded transiently, while
ordinary queries continue sharing frozen decoded pages in the bounded cache. The
rebuild staging allowance is capped independently so old and rebuilt page
generations do not accumulate in memory. These choices affect compaction latency
and residency only; hashes, stored bytes and version-one records are unchanged.

Public paged queries, output delivery reads and other snapshots that may outlive a
mutation remain remotely pinned before uncached reads. Discovery assembly,
claims, acknowledgements and maintenance preparations already run under the
shared context writer boundary; they use writer-fenced snapshots instead of
publishing read-pin roots. Those preparations capture the manifest/catalog
revision, archive allocation and writer token and must finish with a guarded root.
An external takeover turns a missing page into `ownership-lost`; unchanged
ownership preserves `missing-page` or `integrity`. Read-pin releases have
immutable evidence, including releases from a displaced reader. A crashed public
reader's unreleased pin remains protected; there is no implicit timeout or
distributed lease expiration.

Each allocation journals page-upload intent before uploading those pages. Only
sealed retired allocations are candidates for collection. Unsealed allocations
retain unsettled upload and mutation evidence in a paged index. The
`retainedEpochs` counter reports this retained work; successful cleanup does not
assert that every historical uncertain transport has stopped.

Each deletion batch has an exact claim recorded by a conditional manifest
update. Before dispatching its deletions, the runtime rereads the authoritative
manifest to revalidate writer ownership. A new writer honors that claim. Page
hashes include the allocation identity, so a later writer cannot recreate a
retired deletion target. Repeated deletion after a lost response is safe.
Current catalog facts, incomplete source work, snapshot pins and unacknowledged
output stay reachable throughout cleanup. Cleanup never disposes session output.
After one deletion claim settles, cleanup derives the next bounded claim from the
persisted cursor and publishes one root that clears the completed claim and
records the next. The initial claim and final clearing root remain explicit. A
restart replays the preceding claim idempotently before advancing, so no deletion
can outrun durable ownership while long cleanups avoid two roots per batch.

An uncertain root publication or retained immutable archive batch stops mutations.
Resolve its exact conditional operation through `runtime.checkpoints.reconcile()`.
The result distinguishes an active writer from one displaced after its commit.
Open a new explicitly bound instance to claim ownership; reconciliation never
silently takes ownership back.

Keep the capability report's failed checks and release gate alongside any
development package. The official archive run establishes the declared fixture's
memory bound, not a general upper bound for larger results or other Pod layouts.

Bounded discovery turns count source and checkpoint HTTP, including session
startup, observation publication and progress bookkeeping. Each admitted
conditional checkpoint write reserves its PUT and one confirmation GET. Root
publication protects those requests before uploading remaining pages. A budget
that cannot admit a unit stops before that unit's HTTP dispatch; staged pages
remain unpublished. If final bookkeeping cannot fit, the runtime retains durable
continuation and returns budget evidence with the last available snapshot.
A later explicit run recovers interrupted work and reparses incomplete sources.
An unresolved remote root outcome remains blocked until checkpoint reconciliation;
exhausting a confirmation budget never turns uncertainty into a successful commit.

Portable output delivery and acknowledgement prepare under the context's writer
queue, so continuing source observations cannot indefinitely invalidate a delivery
claim. This queue is local to the bound writer; the manifest's conditional fence
still rejects a displaced writer. Explicit Pod contexts refresh session progress
within active turns and explicit API calls; they do not start checkpoint reads
from idle catalog-notification timers.

Ordered pages may use a versioned, lossless key-prefix encoding and key-suffix
references for repeated index values. Decoding restores exact ordered keys and
RDF values before semantic record validation. Hashes and page-byte limits apply
to the immutable wire representation. Earlier uncompressed version-one pages
remain readable; unknown encoding versions fail explicitly.

The live writer's current `manifest.commit` is its lost-response proof; ordinary
same-writer publications do not copy every commit into a proof tree. On takeover,
the next writer carries the displaced commit unchanged until its first mutation.
That guarded mutation persists one proof keyed by the displaced operation ID and
state hash before overwriting `manifest.commit`. Several claim-and-exit cycles
therefore still create at most one displaced proof. Older version-one per-root
proofs remain readable and are collected only after their archive allocation is
sealed and outside protected history.

Output delivery pulls pending journal values only through its selected byte and
observation boundary. It may inspect one additional observation to establish a
byte boundary. Redelivery and acknowledgement stop at the outstanding batch's
last sequence. A portable iterator holds its immutable snapshot until it finishes
or its consumer stops; early return releases its read pin. The byte cache remains
bounded and no complete output backlog is hydrated.

Pending output and reservations are addressed through their ordered primary
ranges, keyed by namespace, session and padded sequence or work identity. New
records do not maintain the redundant `bySession`, `byState` and
`bySessionState` entries. When an older version-one record changes, its legacy
secondary-index superset is removed. Mixed namespaces remain readable without a
migration, and explicit output disposal scans both primary ranges before generic
session cleanup.

Local source and container-scope candidate lookups use the ordered Thing primary
range as well. New local Things therefore omit redundant source and ancestor-scope
candidate entries. External RDF subjects still receive those secondary entries,
and readers merge both paths with stable deduplication so older version-one pages,
external subjects and newly written local Things produce the same query results.
Container comparisons remain boundary-aware; `/alice/` cannot admit
`/alice-other/`.


## Root upload interruption

A conditional PUT alone does not make file-backed replacement atomic. On the
qualified CSS 8.0.0-alpha.3 configuration (`storage/backend/file.json` and
`storage/middleware/default.json`), interrupting a streaming JSON PUT can leave a
truncated live document. The root therefore uses conditional N3 Patch, whose
complete syntax is validated before the server applies its change. Interrupted
uploads retain the previous root; lost successful responses are reconciled through
the manifest's existing operation evidence. An unresolved response still stops
further mutation until explicitly reconciled. Immutable payload PUTs retain their
integrity checks. A live writer keeps the bounded byte-identical archive batch
after a lost response and failed confirmation, so caller-directed reconciliation
can confirm or complete it before root publication. They never become committed
through an unconfirmed root.

Draft artifacts through `6d7478f` used `manifest.json` with conditional PUT. That
root format is not automatically migrated. `create` and `open` detect it and fail
with `unsupported-version` and `draft-json-put-root`, preserving all files. Retain
that namespace for explicit recovery with its compatible artifact, or select a new
checkpoint container. The JSON record and observation schemas remain version one;
the mutable root representation is now RDF. A package's full commit and report
identify which root format it supports. The cached CSS storage profile and other
server configurations require their own interruption qualification.
