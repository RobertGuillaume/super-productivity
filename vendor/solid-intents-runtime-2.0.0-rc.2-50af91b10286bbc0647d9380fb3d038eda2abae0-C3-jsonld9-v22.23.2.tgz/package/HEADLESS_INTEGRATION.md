# Headless and portable runtime integration

This is the current integration and qualification guide for runtime 2.0. The
runtime provides the same semantic profiles, exact writes, discovery coordinator,
coverage model and cache behavior to browser applications and hosted agents.
Headless callers add an explicit identity, caller-supplied authenticated fetch,
explicit execution and, when portability is required, Pod-backed persistence.

## Release status

The C1, C2 and C3 capability bundles are implemented and engineering-qualified.
The private `2.0.0-rc.2` package is for applications that apply the exact JSON-LD
9 override in [the private adoption guide](PRIVATE_2_PRERELEASE.md). The package
itself contains no override and has not been published.

`npm run verify` is the passing engineering gate. `npm run verify:release` first
runs that complete gate, then tests the ordinary dependency tree. Public 2.0
release remains blocked by the supported upstream `solid-utils` dependency path.
The publish lifecycle invokes the release gate through `prepublishOnly`.

The [artifact index](../../artifacts/README.md) identifies the current package,
checksums and machine-readable qualification evidence.

## Responsibility boundary

The runtime owns authenticated transport, resource parsing, semantic projection,
type-index mechanics, conditional writes, discovery, reverse relationships,
coverage, caching and portable checkpoints. It accepts arbitrary RDF and unknown
types without requiring a registered semantic profile.

The consuming platform owns credential acquisition, identity provisioning,
authorization grants, business handlers, handler queues and retries, publication
policy, and the application experience. An identity passed at boot attributes and
isolates work; it does not authenticate the supplied fetch or create access grants.

## Boot an isolated context

```ts
import { runtime } from "@solid-intents/runtime";

await runtime.boot({
  podUrl: "https://pod.example/alice/",
  fetch: authenticatedFetch,
  identity: {
    principalWebId: "https://agents.example/id/researcher",
    ownerWebId: "https://pod.example/alice/profile/card#me",
    applicationNamespace: "com.example.research",
  },
  execution: "explicit",
  persistence: {
    kind: "pod",
    containerUri: "https://pod.example/alice/.runtime/research/",
    mode: "open",
  },
});
```

An explicitly bound context requires an authenticated fetch. Its normalized
principal, owner, Pod root and application namespace form the isolation key for
catalog data, discovery work, source aliases, subscriptions and ownership state.
Create a new runtime instance to use another identity. Reopening with the same
binding restores only that binding's state.

`persistence` accepts `auto`, `memory`, `indexeddb`, or an explicit Pod container.
Pod `create` conditionally creates a new namespace; `open` requires an existing
one. Neither silently falls back to memory. Existing browser contexts and legacy
browser databases keep their established behavior and are not imported into an
explicit identity partition.

Explicit execution disables query-triggered discovery and automatic HTTP retries.
The application advances discovery with bounded `session.run()` calls. Direct
resource reads requested through public APIs remain available.

## Operations and shutdown

Networked operations accept an `AbortSignal` and deadline where their public
options use `RuntimeOperationOptions`. Cancellation is enforced during scheduler
admission, origin cooldown, fetch dispatch and response-body consumption. A
rate-limited explicit operation can return a retry deadline instead of sleeping.

Close admission and settle the context before replacing a worker or ending a
process:

```ts
await runtime.close({ abortReads: true, timeoutMs: 30_000 });
```

Close rejects new work immediately, cancels queued requests, aborts reads when
requested, and lets admitted mutations settle within the deadline. Duplicate
calls share one close operation. A timeout leaves the context closed and reports
unsettled operations; late transport results are fenced from persistence and
publication. Logout remains a separate authentication and data-lifecycle action.

## Read scopes and redirects

Discovery can be restricted with `RuntimeReadScope`: allowed container roots,
exact resource exceptions and exclusions. `allowedOrigins` and path scope both
apply when both are supplied. Checks occur before the first authenticated request
and before every redirect. Container boundaries are path-aware, so `/alice/`
does not admit `/alice-other/`; ambiguous encoded separators and opaque redirects
fail explicitly.

Explicit contexts default discovery to their Pod root and admit the selected
owner profile as a protocol entrypoint. Additional external profile, preferences
or index resources require explicit scope permission. Exact peer POST and other
caller-addressed operations do not expand discovery scope.

## Exact writes and reviewed plans

New plans use write-plan version 4. They contain the effective identity binding,
exact method and destination, media type, serialized payload, payload hashes and
preconditions. JSON round-trips preserve binary and textual bytes. Version 1 and
2 plans are unsupported. Unbound legacy contexts retain the version-3 validation
path; explicitly bound contexts reject unbound version-3 plans before network I/O.

Available primitives include:

- `planResourceCreate()` for conditional `PUT` with `If-None-Match: *`.
- `planResourcePost()` for one exact POST with an optional `Slug`; POST is never
  replayed automatically.
- `planResourceReplace()` and `planResourceDelete()` with caller validators.
- `planRdfPatch()` for a bounded, exact N3 Patch with a validator or explicit
  unversioned consent.
- `planTypeIndexPatch()` for structured changes compiled to one pinned N3 Patch.

A caller-supplied validator remains the approved precondition through planning and
commit. A fresh read never substitutes it. Conflicts, rejections, requests that
were not sent and unknown remote outcomes remain distinct in structured outcome
evidence. Mutation redirects are not followed automatically.

## RDF and type indexes

`resources.readRdf()` returns an asynchronous sequence of runtime-owned RDF
batches. Public terms preserve named nodes, blank nodes, literal lexical forms,
languages, datatypes and graph terms without exposing N3, Soukai or Node streams.
Body and expanded-observation limits apply while parsing incrementally.

`typeIndexes.discover(ownerWebId, options)` observes public and private index links
from profile and preferences resources with provenance and validators.
`typeIndexes.read(indexUri, options)` reads raw registrations, including unknown
classes and blank-node registrations, without requiring semantic profiles.

Structured type-index plans pin the owner, selected destination, privacy intent,
registration identities, classes, targets, insertions and deletions. They preserve
unrelated triples and caller-owned marker triples. Privacy intent describes the
required destination policy; the runtime does not provision that policy or choose
a fallback index for an exact operation. Ordinary semantic creation continues to
use the runtime's automatic registration policy through the same lower-level
reader and compiler.

## Bounded discovery turns

Create a session for the application-selected boundary, then advance it explicitly:

```ts
const session = await runtime.discovery.createSession({
  targets: [{ kind: "container", uri: "https://pod.example/alice/photos/" }],
});

const turn = await session.run({
  maxJobs: 100,
  maxRequests: 250,
  maxBytes: 16 * 1024 * 1024,
  waitForRetry: false,
});
```

Turns preserve durable continuation on abort or budget exhaustion. Request budgets
include checkpoint traffic for Pod persistence and reserve enough capacity to
finish an admitted commit unit. Delayed work reports its next eligible time.
Known-resource checks are explicit finite sweeps:

```ts
await session.recheckKnown({ checkedBefore: new Date() });
```

The sweep covers membership at its preparation revision, so continuous additions
cannot extend it indefinitely. Rechecks and new discovery are interleaved while
existing foreground/background fairness remains in effect.

Streaming source reads publish an early nonempty RDF batch, then coalesce bounded
updates. Partial observations can add positive knowledge but cannot establish
removal. Only a successfully completed source generation permits inferred
removals. Malformed, interrupted or oversized sources preserve prior authoritative
knowledge and record incomplete evidence.

## Acknowledged output

Every committed discovery observation is retained until the consumer acknowledges
it. Each session has one ordered stream and at most one outstanding batch:

```ts
for (let batch = await session.readOutput(); batch; batch = await session.readOutput()) {
  await deliverToApplication(batch.observations);
  await session.acknowledgeOutput(batch.receipt);
}
```

Repeated reads return the same batch until acknowledgement. Acknowledgement is
idempotent; receipts from another session or namespace incarnation fail. Ordinary
cancellation retains output. Session deletion refuses to discard it unless the
caller explicitly requests output disposal.

Output records contain stable observation, source and attempt identities; a
namespace-local sequence; opaque validators; RDF facts and types; completeness;
and structured failure evidence. A full backlog pauses only its session. Capacity
is reserved before source admission, including terminal evidence, so an observed
result is never dropped because its queue filled.

Default delivery limits are 100 observations or 256 KiB per batch and 128 MiB of
pending output per session. Source limits are 32 MiB of response data and 64 MiB
of expanded observations. Configure source and output limits together because the
worst-case reservation affects effective read concurrency.

## Portable checkpoint storage

The Pod backend keeps the Pod authoritative. It uses a small conditional root
manifest and immutable integrity-checked JSON pages for catalog records, source
facts, memberships, ready work, receipts, output and cleanup state. It loads pages
on demand into a bounded cache; opening a namespace does not hydrate its complete
catalog or journal.

Catalog effects, discovery continuation and output obligations become visible
together after one ETag-guarded root update. Immutable pages may upload in
parallel, while manifest publication remains serialized. A new process claims a
writer fencing token. Once displaced, a writer stops admission and cannot commit
or automatically reclaim ownership.

Internal mutation preparation uses writer-fenced snapshots. Public paged queries
and output reads that may outlive a mutation retain remote read pins. Queries may
fetch missing checkpoint pages but never turn those reads into source discovery.
`things.queryPage()` uses a revision-bound opaque cursor, defaults to 100 results
and accepts at most 1,000; an invalidated cursor fails explicitly.

The version-1 portable format stores no credentials, fetch objects, closures,
source bodies or binary content. RDF facts needed for incomplete-source recovery
remain data. Existing version-1 namespaces require no migration.

### Default checkpoint limits

| Limit | Default |
| --- | ---: |
| Root manifest | 16 KiB |
| Immutable page | 64 KiB and 256 entries |
| Internal branch | 128 children within the page limit |
| Resident checkpoint/catalog cache | 64 MiB |
| Delivered output batch | 100 observations or 256 KiB |
| Pending output per session | 128 MiB |
| Source response body | 32 MiB |
| Expanded observations from one source read | 64 MiB |

## Maintenance and recovery

`checkpoints.maintenanceStatus()` reports cached maintenance debt without source
discovery. `checkpoints.maintain()` performs bounded archive reclamation without
repacking live catalog indexes. Routine collection can run for one bounded step at
the end of an explicit turn when due and when request budget, output and shutdown
state permit it. It has no recurring timer.

`checkpoints.compact()` explicitly rebuilds live indexes and then reclaims retired
state. It preserves active snapshots, incomplete sources, unacknowledged output
and unresolved operation evidence. `checkpoints.reconcile()` resolves retained
uncertain root operations from their exact recorded evidence.

A conflicting immutable archive intent is an integrity failure and permanently
fences that runtime instance. Reconciliation may confirm an identical write; it
cannot choose between different immutable bodies. Start a new instance to claim
the last confirmed manifest and continue in a new archive epoch. The ambiguous
epoch remains retained rather than being cleaned speculatively.

Unknown root outcomes stop further mutations until reconciliation. A failed root
publishes no catalog or output state. Lost successful responses are confirmed from
the recorded operation identity and state hash before local publication proceeds.

## Concurrency and diagnostics

The coordinator can use up to eight source reads when transport slots, output
reservations and prepared-result capacity permit. One active read is allowed per
source identity. The prepared-result queue is bounded, and body pulling pauses at
capacity. Up to eight immutable pages or cleanup deletions can run concurrently;
conditional manifest updates remain single-writer operations.

`diagnostics.status().checkpointActivity` reports pending commit units, the last
committed batch size, effective discovery concurrency, its limiting factor and
maintenance state. Request diagnostics distinguish source, index and checkpoint
traffic and retain origin-level dispatch, retry and cooldown information without
exposing credentials, headers, bodies or RDF content.

## Qualification evidence

The authoritative 100,000-resource result is
[`f09-archive-100000-da9aee9.json`](../../artifacts/qualification/archive-diagnostics/f09-archive-100000-da9aee9.json).
It completed with:

- 100,001 terminal sources and catalog Things.
- 101,370 accepted observations.
- Early output and type publication before the large listing completed.
- Zero source requests during restoration and warm checkpoint-backed queries.
- Zero automatic HTTP retries in explicit execution.
- 15.62 operational checkpoint requests per terminal source.
- 526,991,360 bytes peak runtime RSS, below the 512 MiB gate.
- 28,793,748.8 ms total elapsed time including final compaction, 6.25 seconds
  inside the eight-hour gate.

The stronger target of at most 20 operational checkpoint requests per source
passed. The stronger 6.5-hour margin did not pass; explicit compaction remains the
largest measured cost. These margins are operational evidence rather than changes
to the public contract.

The full browser matrix covers Chromium and Firefox with real IndexedDB and Web
Locks. Packed C1–C3 consumers cover the public Node contract on the minimum and
current supported Node 22 releases. The archive result establishes the selected
discovery boundary; it does not claim complete Pod inventory outside that boundary
or preservation of remote edits that were never observed.

## Consumer handoff checklist

1. Pin the exact RC tarball and verify its SHA-256.
2. Apply the root-owned JSON-LD 9 override from the private adoption guide.
3. Commit the application's lockfile and verify the resolved dependency chain.
4. Use an explicit identity and authenticated fetch for each hosted agent context.
5. Pre-provision the checkpoint container and its access controls before Pod
   persistence `create` or `open`.
6. Bound discovery with scopes, turn budgets, source limits and output limits.
7. Deliver and acknowledge output before deleting sessions.
8. Close each runtime and reconcile uncertain checkpoint operations before process
   replacement.
9. Run the application's build, tests and production audit.

See [the agent integration guide](AGENT_INTEGRATION.md) for a complete example and
[portable checkpoint mechanics](PORTABLE_CHECKPOINTS.md) for storage details.

## Repository verification

```sh
npm run verify
npm run verify:release
```

The first command is the private engineering gate under the tested consumer
override. The second is the publication fence and is expected to fail only on the
documented ordinary upstream dependency audit until a qualifying upstream release
is adopted. No package publication is part of either command.
