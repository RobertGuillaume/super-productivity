# Runtime 2.0 semantic qualification

Runtime 2.0 has completed its semantic, headless and portable-discovery
engineering gates. The current unpublished private prerelease is `2.0.0-rc.2`.
Applications using it must apply the exact root-owned JSON-LD 9 override described
in [the adoption guide](PRIVATE_2_PRERELEASE.md). Public release remains blocked
until the ordinary supported dependency tree passes its production audit without
a consumer override.

## Semantic contract

The runtime owns source reads, catalog projections, conditional writes, operation
outcomes and preservation of arbitrary RDF. Soukai is an internal implementation
tool for registered profile fields and supported serialization. Public APIs expose
runtime Things, views, RDF terms and plans; they do not expose I/O-capable Soukai
models or require applications to understand Soukai.

Built-in and application-defined profiles share one registry. Unknown RDF classes,
predicates, subjects and connections remain readable. Existing RDF documents are
patched at their actual source; they are never replaced with a model serialization.
Language tags, datatypes, blank-node structures, unrelated subjects and unsupported
facts survive unless an exact reviewed operation changes them.

The detailed application migration is in [MIGRATION_2.md](MIGRATION_2.md). The
headless, discovery and portable persistence contract is in
[HEADLESS_INTEGRATION.md](HEADLESS_INTEGRATION.md).

## Write-plan compatibility

`planCreate()` and both `planUpdate()` forms are asynchronous. New semantic and raw
plans use version 4 and include their effective runtime identity, exact serialized
effects, payload hashes and preconditions. Versions 1 and 2 are rejected before
network access. Unbound legacy contexts retain their version-3 validation path;
explicitly bound contexts reject unbound version-3 plans. Replan stored approvals
to gain the current identity binding.

Typed edits require a strong ETag or supported Last-Modified validator unless the
caller explicitly accepts an unversioned write. The approved validator remains the
precondition throughout planning and commit. Partial results and unknown remote
outcomes remain explicit; the runtime does not roll back a mutation that may have
succeeded.

## Compatibility and persistence

- Existing browser behavior and catalog databases remain available to legacy
  callers. They are not imported into explicitly bound identity partitions.
- IndexedDB remains on schema 2 and retains its established schema-1 migration.
- Portable checkpoint, portable record, RDF batch and observation formats remain
  at version 1.
- Native profile defaults use their semantic classes while legacy read aliases
  and existing writable bindings remain supported.
- Registering or revising a profile reinterprets cached RDF without rewriting Pod
  data or hydrating Soukai models.

## Qualified evidence

Engineering verification covers:

- Public Node consumers for baseline and C1-C3 behavior.
- JSON-LD to RDF, RDF to JSON-LD, compaction, languages and datatypes.
- Strict TypeScript declarations, browser bundling and one Soukai instance.
- Runtime unit, real Community Solid Server and CSS performance suites.
- Chromium and Firefox with real IndexedDB and Web Locks.
- Semantic and discovery performance fixtures.
- The qualified 100,000-resource portable archive with restart, acknowledged
  output, warm queries, edits, inaccessible resources and final compaction.

`npm run verify` runs the engineering gate under the tested application-owned
override. `npm run verify:release` runs the same behavioral gate first, then the
ordinary packed-consumer and workspace production audits. The latter command is
expected to fail only on the documented upstream dependency chain until a
qualifying release is adopted.

The machine-readable archive evidence and current private package reports are
indexed in [`artifacts/README.md`](../../artifacts/README.md). The 100,000-resource
result passed the formal eight-hour and 512 MiB gates and the stronger target of
at most 20 operational checkpoint requests per terminal source. Its stronger
6.5-hour target did not pass; explicit compaction remains the dominant measured
cost.

## Release boundary

The private dependency profile introduces no fork, vendored library, postinstall
patch, audit waiver or override inside the runtime package. Applications own the
temporary override because npm does not propagate library overrides.

Final public 2.0 requires a supported ordinary dependency tree with a passing
production audit, the complete verification matrix, a newly qualified immutable
artifact and an explicit publication action. No current package is published or
claimed as final public production qualification.
