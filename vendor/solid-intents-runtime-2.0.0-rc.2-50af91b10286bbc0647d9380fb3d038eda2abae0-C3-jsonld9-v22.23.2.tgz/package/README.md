# Solid Intents Runtime

Semantic runtime API for building Solid applications over RDF data, ordinary files, and Solid type indexes.

This package is the unpublished `2.0.0-rc.2` private prerelease of the 2.0
semantic-profile contract. See [the migration guide](MIGRATION_2.md),
[qualification status](SEMANTIC_MIGRATION.md), and the
[private application adoption guide](PRIVATE_2_PRERELEASE.md). Engineering use is
qualified with the documented application-owned JSON-LD 9 override. Public release
remains blocked until the ordinary upstream dependency tree passes its production
audit without a consumer override.

## Philosophy

Solid-runtime is an opinionated foundation for building premium, fast, reliable
applications on Solid: applications work with meaningful Things, types, and
relationships while the runtime handles authentication, storage, semantic mapping,
safe writes, discovery, and local caching. Its core is making data discoverable by
type and navigable by relationship: opinionated type-index registration supports
“give me all my photos” without requiring a blind Pod crawl, while maintained
reverse relationships support “what connects to this Thing?” and progressive graph
exploration across Pods. Cached knowledge is useful immediately, discovery
continues durably within explicit budgets, and coverage reporting distinguishes
what has been found from what is genuinely complete. The runtime is opinionated
about data shape and shared conventions without becoming a closed schema:
unfamiliar types, arbitrary RDF, and unexpected valuable connections remain
accessible and preserved. Applications own their experience, layout, and
priorities; the runtime owns dependable Solid mechanics, with Soukai serving as an
internal semantic tool rather than something applications need to understand.

## Import

```ts
import {
  SolidGraphRuntime,
  hasLink,
  hasProperty,
  profiles,
  queries,
  runtime,
  vocab,
  views,
} from "@solid-intents/runtime";
import type { SolidRuntime, Thing } from "@solid-intents/runtime";
```

The package export map exposes one public entrypoint. Applications should not import runtime internals directly.

### Supported Node and dependencies

The supported runtime is Node `>=22.12.0 <23` with npm 10. Soukai and Soukai Solid
are pinned to 0.7.1 and resolve to one Soukai instance. Private applications using
`2.0.0-rc.2` must own the exact JSON-LD 9 override documented in the adoption guide;
the resulting isolated production tree has a zero-finding audit. The runtime package
contains no override because npm applies overrides only from the root consumer.
The ordinary upstream dependency tree still fails its production audit and remains
the public-release blocker.

## Public Entry Point

The package value exports are:

- `SolidGraphRuntime`
- `runtime`
- `queries`
- `profiles`
- `views`
- `vocab`
- `findVocabularyTerm`
- `listVocabularyTerms`
- `hasProperty`
- `hasLink`
- `RuntimeError`
- `RuntimeWriteCommitError`
- `ThingNotFoundError`
- `GraphLinkWriteError`
- `DiscoverySessionError`

## Runtime Areas

- `runtime.boot(options)` composes runtime services for one pod/session.
- `runtime.auth` handles login, redirect completion, logout, session state, and authenticated fetch.
- `runtime.types` registers app-owned semantic profiles, RDF classes, field bindings and typed views.
- `runtime.layouts` defines app-owned containers and type profiles.
- `runtime.writes` plans reviewable writes and commits approved plans.
- `runtime.things` creates, reads, queries, updates, deletes, subscribes to, and reads content for meaningful Things.
- `runtime.resources` reads raw pod resource metadata and bodies when an app intentionally wants storage-level access.
- `runtime.graph` writes RDF predicate links and reads directly related Things.
- `runtime.context` returns bounded context around one Thing, grouped by RDF predicate.
- `runtime.discovery` indexes configured containers, graph entrypoints, storage roots, and type-index registrations.
- `runtime.storage` lists pod roots and containers.
- `runtime.share` applies read/write access intent.
- `runtime.validation` validates readable resources or runtime-managed Thing RDF.
- `runtime.diagnostics` explains runtime health, indexed knowledge, type-index state, Thing/content/source identity, and query decisions.

Most applications should start with `things`, `context`, and `discovery`. Use `resources` only when you deliberately want raw Solid storage access outside the Thing model.

## Boot And Auth

Browser applications can use `runtime.auth.login()`, `runtime.auth.handleRedirect()`, and `runtime.auth.restoreSession()` to manage a Solid OIDC session backed by browser storage.

Native and command-line applications can use the same auth core without browser storage. They supply an exact loopback redirect URI, open the returned authorization URL in the system browser, and pass the callback URL back to the same long-lived runtime instance:

```ts
const authorization = await runtime.auth.beginLogin({
  issuer: "https://solidcommunity.net/",
  redirectUrl: "http://127.0.0.1:48317/auth/callback",
  clientName: "My CLI",
});

openSystemBrowser(authorization.authorizationUrl);

// In the loopback callback handler:
const state = await runtime.auth.completeLogin(callbackUrl);
```

Native login uses Authorization Code with PKCE and a memory-only session. The runtime owns discovery, dynamic client registration, callback validation, token exchange, DPoP, refresh, logout, and authenticated fetch. The host application must keep the runtime instance alive and must not persist or serialize its session. Process termination requires login again.

Providers used for native login must advertise discovery and dynamic registration. The runtime registers a native public client with the exact loopback redirect and does not guess client identifiers or silently choose another auth architecture.

Headless Node applications that already have an authenticated fetch can instead boot the runtime with the resolved pod URL:

```ts
await runtime.boot({
  podUrl,
  fetch: authenticatedFetch,
  requestScheduling: {
    minIntervalMs: 300,
    maxConcurrent: 4,
    maxRetries: 3,
    initialRetryDelayMs: 2000,
    origins: {
      "https://high-throughput.example": { maxConcurrent: 8 },
    },
  },
});
```

Request scheduling is enforced at the runtime networking boundary for supplied and built-in authenticated fetches alike. Exact origins have independent start intervals, concurrency limits, retries, and `Retry-After` cooldowns.

Since 1.1.1, these settings are baselines for automatic overload recovery. The first 429 in an episode doubles the start interval (at least 1 second, at most 30 seconds) and halves concurrency, rounding down to a minimum of one. Other in-flight 429s can extend that episode's cooldown without reducing capacity again. Queued starts remain spaced after the cooldown. Every 20 non-429 responses after cooldown increase concurrency by one and reduce the interval to 75%, bounded by the configured baselines. An explicitly configured interval above 30 seconds is preserved. Adaptive state resets when the scheduler is recreated.

Both HTTP-date and delta-seconds `Retry-After` values are honored in full. Missing, negative, or malformed values use exponential fallback with 0–25% positive jitter, capped at 60 seconds including jitter. The default retry limit remains three retries per request, and even a final 429 establishes an origin cooldown. Network exceptions and other HTTP failures do not gain automatic retries.

Hosts can use content-safe scheduling diagnostics to show a quiet retry state:

```ts
const origins = runtime.diagnostics.status().requestScheduling;
const waiting = origins.some((origin) => origin.cooldownUntil !== null);
const unsubscribe = runtime.diagnostics.subscribeRateLimits(({ status }) => {
  showPodRetryState(status.origin, status.cooldownUntil);
});
```

The event fires once per origin overload episode; read `diagnostics.status().requestScheduling` for current cooldown extensions and recovery state. Scheduling snapshots contain only exact origins, counts, timing values, and effective/baseline policy values. They contain no request paths, credentials, headers, or bodies.

`runtime.boot({ restoreSession: true })` restores a browser session when one is available. It is not a server-side credential store. Native sessions are deliberately not restorable.

Use `runtime.auth.capabilities()` or `runtime.diagnostics.status().authCapabilities` to report the active auth environment:

```ts
const capabilities = runtime.auth.capabilities();

if (!capabilities.headlessInteractiveLogin && !capabilities.suppliedFetch) {
  showSetupHint(capabilities.message);
}
```

## Things, Content, Source, Facts, And Facets

A `Thing` is the runtime snapshot for one meaningful item. That item can be an RDF subject, an image, a markdown file, a PDF, a text file, or another file-backed resource.

The runtime separates three ideas:

- `thing.uri` is the stable Thing identity.
- `thing.content` is the readable body when the Thing has bytes: image, markdown, HTML, JSON, PDF, audio, video, and so on.
- `thing.source` is the resource that described or discovered the Thing: an RDF document, a file resource, inferred storage metadata, or runtime-managed RDF.

```ts
const thing = await runtime.things.get(uri);

if (thing) {
  renderTitle(thing.facets.title);

  const body = await runtime.things.content(thing, { as: "blob" });
  renderBody(body);

  renderNames(thing.property(vocab.schema.name.uri));
  renderLinks(thing.objects(vocab.schema.about.uri));
}
```

Snapshots expose:

- `uri` for the Thing URI.
- `content` for the body resource, content kind, media type, filename, and whether it was file-backed or RDF-described.
- `source` for the description/discovery resource and metadata quality.
- `types` for normalized runtime types; original RDF classes remain URI facts under `rdf:type`.
- `facets` for ergonomic fields such as `title`, `description`, `kind`, `status`, image, and record timestamps. Additional typed fields are available through `types.view(type)`.
- `properties` for literal and structured RDF values keyed by predicate URI.
- `links` for URI-valued RDF facts keyed by predicate URI.
- `known` for vocabulary-grouped fact buckets.
- `freshness.source`, currently `"catalog"` or `"pod"`, showing where the snapshot came from.

`things.get(uri)` is catalog-first. It accepts a Thing URI or a known content/file URI and returns the same Thing snapshot. When an identity is neither cataloged nor known missing, it falls back to a direct runtime-managed model lookup. A null result does not establish a remote HTTP 404; use resource-read diagnostics for that distinction.

## Content

Use `things.content()` to read the body for any Thing or known Thing/content URI.

```ts
const markdown = await runtime.things.content(readmeThing, { as: "text" });
const image = await runtime.things.content(photo, { as: "blob" });
const pdf = await runtime.things.content(documentThing, { as: "arrayBuffer" });
const preview = await runtime.things.previewContentUrl(photo);
```

Use `thing.content.kind` and `thing.content.mediaType` to choose presentation. The lookup stays the same for RDF subjects, RDF-described files, and ordinary file-backed Things: pass the Thing to `things.content()`.

Do not use `runtime.resources` to render a Thing. `resources` is the low-level escape hatch for raw pod URIs, HTTP metadata, storage diagnostics, or tools that intentionally operate below the semantic Thing model.

`things.content()` returns one of four body shapes:

- `{ as: "text", text, metadata }`
- `{ as: "blob", blob, metadata }`
- `{ as: "arrayBuffer", arrayBuffer, metadata }`
- `{ as: "json", json, metadata }`

Creating a content-backed Thing writes the bytes and an RDF description that points to them with ordinary RDF facts.

```ts
const readme = await runtime.things.create({
  title: "Project Readme",
  type: "MarkdownDocument",
  content: {
    filename: "README.md",
    mediaType: "text/markdown",
    body: "# Project\n\nEverything is a Thing.",
  },
});
```

Use `target.containerUri` when an app owns a deterministic container layout:

```ts
const readme = await runtime.things.create({
  title: "Project Readme",
  type: "MarkdownDocument",
  target: {
    containerUri: `${podUrl}workspace/docs/`,
  },
  content: {
    filename: "README.md",
    mediaType: "text/markdown",
    body: "# Project\n\nEverything is a Thing.",
  },
});
```

Relative target containers resolve from the runtime pod URL, and missing trailing slashes are normalized.

Updating content writes the content resource, not the RDF metadata resource.

```ts
await runtime.things.update(readme.uri, {
  content: {
    body: "# Project\n\nUpdated notes.",
  },
});
```

Deleting a file-backed Thing deletes that file because the resource is the Thing. For RDF-described content, deletion removes only the canonical Thing subject from its RDF source. A distinct content resource is deleted only when durable `runtime:ownsContent` metadata proves that the runtime created and owns it; legacy or shared content is retained and reported in the write-plan diagnostics.

## Discovery And Queries

Discovery indexes externally created RDF subjects, file resources, and runtime-managed Things into the catalog. RDF subjects do not need `rdf:type` to be meaningful: labels, titles, descriptions, links, dates, and other non-structural facts are enough evidence for indexing.

```ts
await runtime.boot({ podUrl });

await runtime.discovery.start({
  entrypoints: [`${podUrl}workspace/things/`],
  mode: "balanced",
});

const photos = await runtime.things.query(
  queries.photos(),
  { scope: { kind: "container", uri: `${podUrl}workspace/photos/` } },
);

for (const photo of photos.things) {
  const preview = await runtime.things.previewContentUrl(photo);
  renderImage(preview.url);
}

for (const diagnostic of photos.metadata.diagnostics) {
  console.info(diagnostic.code, diagnostic.message);
}
```

Queries are catalog-first. Records confirmed `missing` are hidden from `things.get()`, queries, subscriptions, and context, while stale, refreshing, inaccessible, and invalid cached knowledge remains available for offline use. Metadata reports completeness, freshness, stale counts, refresh state, and diagnostics such as `scope-unscanned`, `degraded-resources`, `type-index-results`, and `fallback-discovery-results`. Per-record catalog status stays under `diagnostics.inspectThing()` rather than leaking into `Thing`.

Use explicit container reconciliation when a complete listing should authoritatively update direct membership:

```ts
const reconciliation = await runtime.discovery.reconcileContainer(`${podUrl}workspace/things/`);
const settled = await runtime.discovery.settle({ maxRuns: 100 });

if (settled.reason === "budget-exhausted") {
  showContinueDiscoveryAction();
}
```

Successful changed listings replace direct membership, tombstone absent children, and enqueue every present child. Unchanged, inaccessible, and failed listings preserve the cached membership snapshot. `storage.listContainer()` remains a read-only inspection API. `discovery.cancel()` stops new dispatch and discards queued work after active requests finish; an explicit later start or refresh begins cleanly.

Use query presets for common content categories:

```ts
await runtime.things.query(queries.images());
await runtime.things.query(queries.documents());
await runtime.things.query(queries.markdown());
```

Use `hasProperty` and `hasLink` when a query needs explicit RDF predicates:

```ts
const result = await runtime.things.query({
  where: [
    hasProperty(vocab.schema.name.uri, "Project Apollo"),
    hasLink(vocab.schema.about.uri, topicUri),
  ],
});
```

`relatedTo` is the predicate-agnostic shortcut for "anything linked to this target URI." Use `hasLink(predicateUri, targetUri)` when the predicate matters:

```ts
const broad = await runtime.things.query({
  relatedTo: topicUri,
});

const aboutTopic = await runtime.things.query({
  where: [
    hasLink(vocab.schema.about.uri, topicUri),
  ],
});
```

## Type Indexes

Runtime-managed writes try to register created and updated Things in the user's private Solid type index. Type-index write failures are observable and non-fatal by default.

```ts
const photo = await runtime.things.create({
  title: "Beach Sunset",
  type: "Photo",
  status: "active",
});

const write = runtime.diagnostics.status().typeIndexWrites.latest;
console.info(write?.status, write?.message);
```

`discoverType(runtimeType)` uses type-index registrations first. If the type index has no matching instance or container registrations, discovery performs bounded fallback traversal/storage discovery. Query diagnostics report which path produced results.

```ts
await runtime.discovery.discoverType("Photo");

const result = await runtime.things.query({ type: "Photo" }, { autoDiscover: false });
const codes = result.metadata.diagnostics.map((diagnostic) => diagnostic.code);
```

Promoted native types use stable RDF classes in type indexes and discovery where natural: for example `Photo` uses `schema:ImageObject`, `Event` uses `schema:Event`, `Note` uses ActivityStreams `Note`, `Task` maps iCalendar `Vtodo`, and `Person` accepts schema.org, FOAF, and vCard classes. Explicit `schema:additionalType` remains preferred. Original `rdf:type` facts are preserved even when the catalog normalizes them to a runtime type. Runtime-owned app concepts such as `Area`, `Bookmark`, `Conversation`, `HealthLog`, and `Meal` use runtime-owned classes.

Register an app-owned type before creating Things when the app owns the RDF class:

```ts
runtime.types.register({
  type: "AgentSession",
  classUri: "https://cairn.dev/ns#AgentSession",
});
```

Created `AgentSession` Things use that class URI in both their RDF description and
type-index registrations instead of a runtime-owned fallback class. Registration
also accepts declarative `fields`; `types.get()` returns resolved definitions and
`types.view()` provides a synchronous typed projection. See the [custom profile
example](MIGRATION_2.md#register-fields-and-use-typed-views).

`runtime.diagnostics.typeIndexes(runtimeType)` returns read-only type-index registrations and failures for inspection.

## App-Owned Layouts

Use a layout descriptor when an app owns multiple containers and type profiles. Define layouts after boot so relative container paths resolve from the active pod URL.

```ts
const cairnLayout = runtime.layouts.define({
  namespace: "https://cairn.dev/ns#",
  containers: {
    sessions: "cairn/sessions/",
    memories: "cairn/memories/",
  },
  types: {
    AgentSession: {
      container: "sessions",
      defaultStatus: "active",
    },
    AgentMemory: {
      container: "memories",
    },
  },
});

const session = await runtime.things.create({
  profile: cairnLayout.types.AgentSession,
  facets: {
    title: "Planning session",
  },
});
```

When a layout has a namespace, type entries without an explicit `classUri` register `${namespace}${type}` for type-index writes. Use `classUri` when an app type has a different RDF class URI.

For apps with their own durable ids, define the container and RDF vocabulary in the runtime, then pass `target.resourceName` to place the RDF metadata resource at a stable pod URL. Also store the app id as an explicit RDF fact so discovery and queries do not depend on URL parsing.

```ts
const sp = {
  id: "https://super-productivity.com/ns#id",
  isDone: "https://super-productivity.com/ns#isDone",
};

const superProductivityLayout = runtime.layouts.define({
  namespace: "https://super-productivity.com/ns#",
  containers: {
    tasks: "super-productivity/tasks/",
  },
  types: {
    Task: {
      container: "tasks",
      defaultStatus: "active",
    },
  },
});

await runtime.things.create({
  profile: superProductivityLayout.types.Task,
  target: {
    containerUri: superProductivityLayout.containers.tasks,
    resourceName: task.id,
  },
  facets: {
    title: task.title,
  },
  properties: {
    [sp.id]: [task.id],
    [sp.isDone]: [task.isDone],
  },
});

const existing = await runtime.things.query({
  type: "Task",
  where: [
    hasProperty(sp.id, task.id),
  ],
});
```

With `task.id === "task-1"`, this creates the Thing at `${podUrl}super-productivity/tasks/task-1.ttl#it`. Resource names are sanitized as file names and receive a `.ttl` suffix when needed. Creates fail with `RuntimeError` code `resource-already-exists` if the target RDF resource is already present.

This keeps storage, auth, RDF parsing, discovery, and type-index behavior in the runtime. Application code owns only its vocabulary and projection layer.

## Profiles, Facets, And Views

Semantic profiles govern native classes, field bindings, aliases, validation and
typed views. Write profiles add named placement/default-status conveniences.
Top-level fields, `facets` and `fields` are adapters to one compiler; assigning a
field through more than one adapter is rejected. `properties` and `links` accept
explicit predicates, which must not overlap typed assignments in the same request.

New Task titles use `ical:summary`, Note titles use `as:name`, and Concept titles use
`skos:prefLabel`. Existing legacy bindings remain readable and are preserved when
editing. All new Things assert the profile's primary class plus the runtime hint.

```ts
const task = await runtime.things.create({
  profile: profiles.Task,
  facets: {
    title: "Prepare release notes",
    status: "active",
  },
  links: {
    [vocab.schema.about.uri]: [project.uri],
  },
});
```

Native profiles and views cover the common app layer:

- Workspace: `Note`, `Task`, `Project`, `Goal`, `Area`
- Knowledge and learning: `Concept`, `Topic`, `Skill`, `Course`, `Book`, `Article`
- People and places: `Person`, `Organization`, `Place`, `Event`
- Media and documents: `Photo`, `Document`, `WebPage`, `Bookmark`
- Conversation: `Conversation`, `Message`
- Material records: `Product`, `Invoice`
- Lightweight life records: `PhysicalActivity`, `HealthLog`, `Meal`

Apps can store their own vocabulary without waiting for a native profile. Declare
managed fields for shared typed reads/writes; use explicit RDF for unexpected facts:

```ts
runtime.types.register({
  type: "AgentSession",
  classUri: "https://cairn.dev/ns#AgentSession",
  fields: {
    startedAt: { predicateUri: "https://cairn.dev/ns#startedAt", valueType: "dateTime" },
    workspace: { predicateUri: "https://cairn.dev/ns#workspace", valueType: "uri" },
  },
});

const session = await runtime.things.create({
  type: "AgentSession",
  target: {
    containerUri: `${podUrl}cairn/sessions/`,
  },
  facets: {
    title: "Planning session",
    status: "active",
  },
  fields: {
    startedAt: new Date(),
    workspace: workspaceUri,
  },
});

const { fields } = session.as(runtime.types.view("AgentSession"));
```

Unknown type strings are application vocabulary from the runtime API perspective. Native runtime profiles are for concepts that are broadly useful across Solid applications.

URI-valued fields write RDF links. Use `fields.url` (or an explicit `links` entry),
not a string literal in `properties` for a managed URI field:

```ts
const bookmark = await runtime.things.create({
  profile: profiles.Bookmark,
  facets: {
    title: "Runtime API",
    description: "Saved reference page",
  },
  fields: {
    url: "https://example.com/runtime-api",
  },
  links: {
    [vocab.schema.about.uri]: [topic.uri],
  },
});
```

Field updates replace the selected values. `undefined` leaves them unchanged,
`null` removes an optional field, and `[]` clears a multiple-valued field. Ordinary
typed updates read the actual source and require a supported validator by default.
An ambiguous alias or unsupported encoding stays readable but cannot be silently
rewritten through typed editing.

On updates, `properties` and `links` add facts. Use explicit replace/delete inputs
for exact RDF changes, including ambiguity resolution:

```ts
await runtime.things.update(task.uri, {
  replaceProperties: {
    ["https://super-productivity.com/ns#isDone"]: [task.isDone],
    ["https://super-productivity.com/ns#timeEstimate"]: [task.timeEstimate],
  },
  replaceLinks: {
    ["https://super-productivity.com/ns#tag"]: task.tagUris,
  },
  deleteProperties: {
    ["https://super-productivity.com/ns#plannedAt"]: [],
  },
});
```

An empty array in `deleteProperties` or `deleteLinks` deletes all values for that predicate. A non-empty array deletes only those exact values.

Read views project a `Thing` snapshot into a typed shape for application code.

```ts
const taskView = task.as(views.Task);
const bookmarkView = bookmark.as(views.Bookmark);
const documentView = readme.as(views.Document);
```

## Graph Writes

`graph.link` and `graph.unlink` write RDF predicates directly. Known ergonomic aliases resolve through the vocabulary/policy registry, and absolute URI strings are accepted as arbitrary predicates.
Aliases are convenience labels only; write results and stored facts are expressed as RDF predicate URIs.

```ts
const write = await runtime.graph.link(
  project.uri,
  task.uri,
  "contains",
);

console.info(write.predicateUri, write.inversePredicateUri);
console.info(write.sourceChanged, write.targetChanged);
```

Use absolute predicate URIs for app-owned links:

```ts
await runtime.graph.link(
  session.uri,
  workspaceUri,
  "https://cairn.dev/ns#workspace",
);
```

The native alias set includes common app workflow links such as `contains`, `references`, `dependsOn`, `belongsToArea`, `tracksGoal`, `documentsProject`, `aboutTopic`, `taggedWith`, `authorship`, `membership`, `located`, `attends`, `knows`, `enrolledIn`, `completedCourse`, `requiresSkill`, `teaches`, `learnedFrom`, `owns`, `purchasedProduct`, `boughtFrom`, `billingFor`, `paidBy`, `repliedTo`, `attachedTo`, `savedFrom`, `associatedMood`, and `improves`.

The result shape is predicate-based:

- `predicateUri` is the RDF predicate written on the source.
- `inversePredicateUri` is present when an inverse predicate was written on the target.
- `sourceChanged` and `targetChanged` report which resources changed.
- `repairedExistingDrift` reports whether the write repaired previously inconsistent RDF.

No public graph write API exposes storage-specific field names.

## Write Plans

Use `runtime.writes` when a user or agent needs to review mutations before they happen. Planning does not mutate the pod.

```ts
const plan = await runtime.writes.planCreate({
  profile: cairnLayout.types.AgentSession,
  facets: {
    title: "Planning session",
  },
});

renderReview({
  version: plan.version,
  operations: plan.operations,
  affectedResources: plan.affectedResources,
  preconditions: plan.preconditions,
  diagnostics: plan.diagnostics,
});

const commit = await runtime.writes.commit(plan);
```

Graph links can be planned through the same surface:

```ts
const plan = runtime.writes.planGraphLink(
  project.uri,
  task.uri,
  "contains",
);
```

`planCreate()` and both forms of `planUpdate()` are asynchronous. New plans use
version 4 and bind their effective runtime identity; persisted version-1/2
approvals fail before network access and must be replanned. Unbound legacy contexts
retain their version-3 validation path, while explicitly bound contexts reject
unbound version-3 plans. Typed plans freeze exact RDF effects, metadata timestamps, profile
fingerprints, source identities and validators. For example:

```ts
const plan = await runtime.writes.planUpdate(task.uri, {
  replaceProperties: {
    ["https://super-productivity.com/ns#isDone"]: [task.isDone],
  },
  deleteLinks: {
    ["https://super-productivity.com/ns#dependency"]: [],
  },
}, {});
```

Reviewed Thing updates support typed fields, explicit RDF and content bytes bound
to the Thing's resolved content resource. Use `planResourceReplace()` for an
intentional raw resource replacement. An application may pass
`{ allowUnversioned: true }` to `planUpdate()` or as the third argument of
`things.update()` when the server provides neither validator; the plan records that
risk. Commit never replaces an approved validator or silently chooses new bindings.

Semantic Thing deletion resolves the canonical subject separately from its RDF source, any provably owned distinct content, and its exact type-index instance registrations. It never deletes a whole RDF source merely because the subject lives there:

```ts
const deletion = await runtime.writes.planDelete(task.uri);
renderReview(deletion.operations, deletion.preconditions);
const result = await runtime.writes.commit(deletion);
```

Reviewed deletion requires a strong ETag or Last-Modified validator for every mutable resource. An application may deliberately request `planDelete(uri, { allowUnversioned: true })`, but the runtime records a warning and leaves confirmation policy to that application. Immediate `things.delete()` uses the same semantic deletion executor without adding a review step.

Storage tools that intentionally operate below the Thing model use explicitly named raw operations:

```ts
const replacement = await runtime.writes.planResourceReplace(resourceUri, {
  body: updatedText,
  mediaType: "text/markdown",
});
const exactDeletion = await runtime.writes.planResourceDelete(resourceUri);
const container = await runtime.writes.planContainerCreate(containerUri);
const emptyContainerDeletion = await runtime.writes.planContainerDelete(containerUri);
```

Raw resource operations reject fragment and container URIs. Container operations require a normalized trailing slash. Creation uses `If-None-Match: *`; deletion refuses non-empty containers both when planning and immediately before its conditional request. Replacement bodies are serialized into the plan and represented by a SHA-256 digest in the reviewed operation. Strong ETags are preferred, Last-Modified is the fallback, and unversioned resource writes require explicit `allowUnversioned` permission. Deletion treats HTTP 404 and 410 as already satisfied, while replacement compares the current bytes and media type before retrying.

Plans are versioned, serializable descriptions rather than authorization capabilities. Version 2 introduces subject-safe `rdf.subject.delete`; version-1 plans are rejected and must be replanned. Before a commit, the runtime validates every deserialized URL, resource/container shape, validator, and semantic source identity, then re-derives the reviewed operations from the request. Commit results include an outcome for every operation. A partial failure throws `RuntimeWriteCommitError` with completed, failed, and pending outcomes so an application can explain and retry the approved change without claiming cross-resource atomicity. A non-fatal unavailable type-index registration is reported as `skipped`.

The runtime owns the Solid operation semantics, preconditions, execution, and outcomes. The calling application owns target-container policy, how a proposed change is presented, and whether confirmation is required. In particular, the runtime accepts `target.containerUri`; it does not impose an application workspace.

Thing create/update and graph-link commits reuse their immediate implementations. Immediate and reviewed Thing deletion share one semantic-delete implementation. Explicit raw resource and container plans remain runtime operations, so applications do not need to issue their own authenticated `PUT`, `PATCH`, or `DELETE` requests.

Write failures throw `RuntimeError` or a more specific subclass with stable `code` and optional `details` fields. Write-related codes include `content-write-failed`, `rdf-patch-failed`, `graph-link-write-failed`, `unknown-predicate`, `validation-failed`, `invalid-thing-input`, `resource-already-exists`, `content-update-unavailable`, and `resource-delete-failed`.

## Sharing

Use `share.resolvePermissions(uri)` when permission provenance matters. It returns a `known` WAC result with `resource-acl`, `fallback-acl`, or `mock` provenance, or an `unknown` result classified as `acl-unavailable`, `acl-absent`, or `unsupported-access-model`.

```ts
const resolution = await runtime.share.resolvePermissions(resourceUri);
if (resolution.status === "known") {
  renderPermissions(resolution.permissions, resolution.provenance);
} else {
  renderUnknownPermissions(resolution.reason);
}
```

`share.permissions()` remains as a compatibility wrapper and returns only the permissions array. An empty result is therefore ambiguous; new consumers should use the structured API. The runtime does not present ACP or another unsupported access model as an authoritative WAC result.

A final 429 while reading the resource or any applicable ACL returns `{ status: "unknown", permissions: [], reason: "rate-limited", retryAt? }`. `retryAt`, when available, is the scheduler's current cooldown deadline. This does not establish writable or read-only access; defer the permission decision and try again later. Resource-ACL and inherited fallback-ACL results retain their existing provenance when resolution succeeds.

## Context

`context.get(uri)` returns the root Thing, connected Things grouped by predicate URI, missing references, and omitted references. Catalog link hints live under diagnostics.

```ts
const context = await runtime.context.get(project.uri, { maxNeighbors: 20 });

for (const task of context.connected[vocab.schema.hasPart.uri] ?? []) {
  renderTask(task);
}

for (const hint of context.diagnostics.sources.linkHints) {
  console.info(hint.predicateUri, hint.targetUri, hint.recordStatus);
}
```

Context is built from `Thing.links` and URI-valued facts. Structural RDF predicates are filtered out of ergonomic link groups.

## Validation

Readable validation is the default. It verifies that RDF parses when semantic data is present and reports unsupported content when semantic checks do not apply.

```ts
const readable = await runtime.validation.validate(uri);
```

Runtime-managed validation checks saved RDF against the runtime Thing shape and reports structured issue codes such as `malformed-rdf`, `unsupported-content`, and `runtime-managed-shape`.

```ts
const managed = await runtime.validation.validate(thing.uri, {
  mode: "runtime-managed",
  repairHints: true,
});

for (const issue of managed.issues) {
  renderValidationIssue(issue.code, issue.message, issue.repairHint);
}
```

Runtime-managed `things.create` and `things.update` validate write output before returning.

## Diagnostics And Inspection

Resource reads preserve observed HTTP failures. `resources.metadata(uri)` returns an optional `failure`; `resources.read()` and resolved `things.content()` reads throw `RuntimeError` with `code: "resource-read-failed"` and the same `ResourceReadFailure` shape in `details.failure`. Its `reason` distinguishes missing resources, unauthorized and forbidden responses, negotiation failures, rate limiting, server/network errors, cancellation, and invalid or unavailable bodies. A final 429 includes `retryAt` when known from the runtime scheduler or `Retry-After`.

```ts
const metadata = await runtime.resources.metadata(sharedUri);
if (metadata.failure) {
  showReadFailure(metadata.failure.reason, metadata.httpStatus);
}

const body = await runtime.resources.read(sharedUri, {
  accept: "application/json",
  as: "json",
});
```

`accept` explicitly selects the HTTP `Accept` header; `as` only selects local decoding. Raw text, blob, and byte reads do not require a recognized semantic media type. Invalid JSON is `invalid-body`. A conditional body read returning 304 is `body-unavailable`, not a fabricated body or an automatic second request.

HTTP status `0` means no HTTP response was observed. If reading a body fails after HTTP 200, that status is retained. Errors keep their original exception as `cause`, but failure summaries contain no bodies, credentials, or authorization headers; error target URIs omit credentials, queries, and fragments. Treat `cause` as potentially sensitive debugging information rather than a user-facing diagnostic.

Discovery retains the latest observed read metadata alongside its catalog transition. `inspectThing()` exposes it under `sourceRead`, `contentRead`, or `requestedRead`, with a separate `readAt` timestamp. Older cached records may have no observed HTTP status. Inspection reports `discovery.status: "not-cataloged"` when no Thing is indexed; this is not evidence of a remote 404. Authoritative listing absence can mark a resource missing without inventing an HTTP response for that child. Raw resource reads remain read-only and do not populate the semantic catalog.

Use diagnostics when a UI needs to explain why a Thing did or did not appear.

```ts
const inspection = await runtime.diagnostics.inspectThing(thingOrContentUri);
const explanation = await runtime.diagnostics.explainQuery(queries.photos());
```

`inspectThing()` reports:

- whether the inspected URI resolved to a Thing
- content identity, kind, media type, and whether it is writable
- source identity, source kind, and metadata quality
- source/content/requested read status when the runtime knows it
- Thing identity, aliases, and source discovery state
- RDF predicate summaries
- type-index membership

`explainQuery()` reports matched URIs and per-record inclusion or exclusion decisions.

## Development Checks

From the workspace root:

```sh
npm run verify
npm run verify:release
```

Install the development browser fixtures once with `npx playwright install chromium firefox`.
`npm run verify` aliases `verify:engineering`. It builds the package and exercises
the JSON-LD 9 packed C3 consumer, exact dependency-chain validation, strict
declarations, browser bundling, a zero-finding isolated production audit, unit and
local Pod/CSS suites, live CSS performance, real browsers, and discovery
performance. `npm run verify:release` runs that complete engineering gate first,
then tests the unoverridden packed consumer and workspace production audits. The
known upstream findings make the release command fail by design. `prepublishOnly`
invokes that release command so `npm publish` cannot silently bypass it. Exercise
both minimum Node 22.12.0 and the supported Node 22 line. See
[semantic qualification](SEMANTIC_MIGRATION.md) and the current
[headless and portable handoff](HEADLESS_INTEGRATION.md). The independently runnable
commands are `npm run test:browser` and `npm run test:discovery:performance`.
The timing comparison requires the local baseline commit `ebed7d0`; use a full
history checkout in CI and avoid competing benchmark workloads.

`npm audit --omit=dev` remains the public runtime dependency security gate. The
private override is application policy for the prerelease and does not qualify the
ordinary dependency tree for public release.

## Local Consumer Packages

The supported consumer contract is a pinned packed tarball, rather than a
symlink-specific bundler configuration. Private prerelease applications add the
documented root override, pin the tarball SHA-256 and commit their lockfile. They do
not import Soukai or add duplicate runtime dependencies. The prerelease is an
engineering handoff and is not public production qualification.

## Minimal Flow

```ts
await runtime.boot({ podUrl });

const stopPhotos = runtime.things.subscribe(queries.photos(), renderPhotos);
await runtime.discovery.start();

const context = await runtime.context.get(selectedUri);
const body = await runtime.things.content(context.thing, { as: "blob" });

stopPhotos();
```
## Discovery sessions

Session queries use `{ scope: { kind: "discovery-session", id: session.id } }` and
remain catalog-only, including during restoration. Coverage and progress appear in
`result.metadata.discovery`. Use `diagnostics.inspectDiscoverySession(id, { limit,
workCursor, coverageCursor })` for paginated failed work and coverage explanations;
cursors belong to one session generation.

`discovery.createSession()`, `getSession()`, `listSessions()`, and `deleteSession()`
manage local discovery intent. A session exposes `run()`, `pause()`, `cancel()`,
`refresh()`, `snapshot()`, and `subscribe()`. `DiscoverySessionError` identifies
definition conflicts, concurrent runs, and invalid lifecycle operations.
Read the [complete discovery contract and migration examples](./DISCOVERY.md) for
first-result rendering, explicit restart/resume, coverage boundaries, automatic
fallback, cross-Pod defaults, identity keys, and browser persistence limitations.
Durable progressive discovery and portable checkpoint qualification are recorded
in the [headless and portable handoff](./HEADLESS_INTEGRATION.md) and its linked
machine-readable reports.
