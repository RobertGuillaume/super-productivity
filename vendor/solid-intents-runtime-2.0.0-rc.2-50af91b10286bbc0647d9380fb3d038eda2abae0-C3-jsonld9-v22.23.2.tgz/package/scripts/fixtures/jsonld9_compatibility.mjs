import assert from "node:assert/strict";
import {
  compactJsonLDGraph,
  jsonldToQuads,
  quadsToJsonLD,
} from "@noeldemartin/solid-utils";

const subject = "https://pod.example/things/1#it";
const input = {
  "@id": subject,
  "https://schema.org/name": [{ "@value": "Hola", "@language": "es" }],
  "https://schema.org/position": [{
    "@value": "7",
    "@type": "http://www.w3.org/2001/XMLSchema#integer",
  }],
};
const quads = await jsonldToQuads(input);
assert.equal(quads.length, 2);
assert(quads.some(({ object }) => object.termType === "Literal" && object.language === "es"));
assert(quads.some(({ object }) => object.termType === "Literal" && object.datatype.value.endsWith("#integer")));
const restored = await quadsToJsonLD(quads);
assert.equal(restored["@graph"].length, 1);
const compacted = await compactJsonLDGraph({ "@graph": [input] });
assert.equal(compacted["@graph"][0]["@id"], subject);

console.info(JSON.stringify({
  fixture: "jsonld9-compatibility",
  status: "passed",
  quads: quads.length,
  language: "es",
  datatype: "http://www.w3.org/2001/XMLSchema#integer",
}));
