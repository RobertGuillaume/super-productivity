# Discovery performance qualification

Run `npm run test:discovery:performance` from the workspace root on Node 22.12.0
or the supported Node 22 line. The read comparison needs commit `ebed7d0` locally;
CI checkouts must retain that baseline (do not silently substitute another one).
Run the gate without other benchmark/build workloads on the same machine.

The command builds once, then runs these checks sequentially:

1. Ten isolated read measurements: five for the migration baseline and five for
   the working tree, interleaved in alternating order. Medians must show at least
   a 50% cold-query improvement and warm queries no more than 10% slower. Both
   paths query 10,000 identical records and make zero Pod requests. The report
   includes Node and tested commit. Retained projection heap is **not total heap**.
2. Public-API discovery of 10,000 resources in 100-job turns. Later reads are held
   until the first ten results have been delivered through a scoped subscription.
   The gate requires complete coverage, one read per resource plus its listing,
   exact job completion/dispatch counts, and at most 14 materialized pending/active
   jobs. Indexed journal counts are used only as read-only internal instrumentation;
   all discovery is executed via the public runtime API.
3. Structural catalog and work tests, including 10,000-record fake-IndexedDB
   migration, zero startup Thing/resource rewrites, no normal store clears,
   bounded one-resource deltas, rollback, narrow candidate access, projection
   invalidation, and indexed selection from a 10,000-entry work journal.

The end-to-end scenario is explicitly memory-only Node, not a simulated claim of
browser persistence. Its memory report retains the full catalog, indexes, source
aliases, listing pages, and session journal; fixture heap is measured separately.
It reports heap both with and without the fixture's request log, plus process RSS.
`runtimeAndJournalDelta` includes fixture growth and runtime caches beyond pure
record storage. It is not an allocation-per-Thing guarantee. JavaScript heap does
not account for every native allocation; browser storage bytes are not Node heap.
The separate real-browser suite proves restart and multi-tab persistence.

Elapsed/first-result/public-query timings are reported, not presented as browser
latency guarantees. Structural gates are independent of host scheduling noise.
The first-result timeout only bounds a stuck test with deliberately held responses.
Existing live CSS performance/request-budget tests remain a separate gate.

No audit result is waived by passing performance checks. See the current
qualification record in [the headless and portable handoff](../HEADLESS_INTEGRATION.md)
and its linked machine-readable reports.

## Slice-15 measurement

Node 22.23.2, working tree based on `8585247`, five interleaved isolated samples:

| Read path | Cold median | Warm median | Retained projection heap |
| --- | ---: | ---: | ---: |
| Migration baseline `ebed7d0` | 702.71 ms | 34.69 ms | 2,441,688 bytes |
| Progressive reads | 236.02 ms | 31.35 ms | 2,499,184 bytes |

Cold improved 66.4%; warm improved 9.6%; both made zero Pod requests. An earlier
run missed the warm gate (48.76 ms versus 42.56 ms). The implementation now avoids
per-record duplicate-group arrays, flattening, and a second sort when identities
are unique; alias promotion and multiple semantic subjects have regression tests.
Neither timing threshold was relaxed.

The public-runtime run completed all 10,000 Things in 111 bounded turns:
11,001 dispatches (including expansion batches), 10,002 completed jobs, 10,001
GETs, complete coverage, and a peak of 12 materialized pending/active jobs. The
first ten results appeared at 954 ms while subsequent reads remained blocked;
the complete run took 76.99 seconds. Public unscoped queries measured 48.52 ms cold
and 32.14 ms warm. These are local fake-storage timings with real parsing/catalog
work, not network or browser performance predictions.

GC-measured heap: initial 19,329,456 bytes; fixture 23,553,344; before execution
23,760,248; final with request log 135,254,856; without request log 131,332,000.
The runtime/catalog/journal delta beyond the fixture was **107,778,656 bytes**;
RSS was 225,615,872 bytes. This deliberately retains current discovery receipts,
membership and listing pages, not only projected results. Browser on-disk storage
is tested for correctness separately and is not included in this heap number.

## Final two-version qualification

Measured at `0e91e3a`, with five interleaved samples per read path on each Node
version. Each row compares the historical baseline and current code within the
same run; cross-row timings are not a controlled comparison of Node releases or
a browser latency guarantee. Both runs pass the unchanged 50% cold/10% warm gates.

| Node | Baseline cold / warm | Current cold / warm | Cold / warm improvement |
| --- | ---: | ---: | ---: |
| 22.23.2 | 243.37 / 18.33 ms | 75.19 / 11.97 ms | 69.1% / 34.7% |
| 22.12.0 | 525.45 / 37.60 ms | 244.63 / 26.16 ms | 53.4% / 30.4% |

Both public-runtime runs process 10,000 Things with complete coverage in 111
100-job turns: 10,001 GETs, 11,001 dispatches, 10,002 completed jobs, and a peak of
12 materialized pending/active jobs. All 46 structural checks pass on both versions.

| Node | First ten / complete run | Public cold / warm query | Retained heap without request log | Runtime/catalog/journal delta | RSS |
| --- | ---: | ---: | ---: | ---: | ---: |
| 22.23.2 | 318 ms / 26.83 s | 46.77 / 33.77 ms | 133,111,056 bytes | 109,568,752 bytes | 248,266,752 bytes |
| 22.12.0 | 865 ms / 84.06 s | 94.46 / 95.44 ms | 132,799,496 bytes | 109,563,600 bytes | 227,041,280 bytes |

The first ten results arrived while later reads were deliberately blocked, not
after the full collection had been processed. These complete-runtime memory
measurements include journal and index costs; they do not imply the roughly
2.5 MB projection-only heap is the entire cost of discovery.
