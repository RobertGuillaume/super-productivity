# Semantic profiles: migration to runtime 2.0

This branch implements the 2.0 semantic contract as an unpublished `2.0.0-rc.2`
private prerelease. Public release qualification remains blocked by the unmodified
upstream dependency audit; see [qualification status](SEMANTIC_MIGRATION.md). Do not
publish intermediate slices.

## One semantic system

The runtime is a catalog-first platform for fast, reliable Solid applications:
both broad type-index discovery (for example, all photos) and bounded graph walking.
Profiles provide opinionated semantic defaults without closing the graph to unknown
types, predicates, subjects or connections. Cached stale and degraded knowledge
remains available; only confirmed absence is hidden from ordinary Thing reads.

Soukai supplies isolated internal schemas and serialization of supported field
values. Runtime code owns source reads, arbitrary RDF preservation, catalog
projections, HTTP scheduling, conditional mutations and operation outcomes.
Applications use runtime APIs and declarative profiles, with no Soukai imports.
There is no generic-model fallback, global authenticated engine, experimental flag,
automatic schema migration, history merge or offline edit queue.

## Register fields and use typed views

```ts
runtime.types.register({
  type: "Agent",
  classUri: "https://example.org/app#Agent",
  classUris: ["https://example.org/legacy#Agent"],
  fields: {
    score: {
      predicateUri: "https://example.org/app#score",
      valueType: "number",
      required: true,
    },
    url: { predicateUri: "https://example.org/app#homepage", valueType: "uri" },
    peers: {
      predicateUri: "https://example.org/app#peer",
      readAliases: ["https://example.org/legacy#peer"],
      valueType: "uri",
      multiple: true,
    },
  },
});

const agent = await runtime.things.create({
  type: "Agent",
  fields: { title: "Research assistant", score: 4.5, url: "https://example.org/", peers: ["urn:agent:reviewer"] },
  target: { containerUri: "agents/", resourceName: "research" },
});
const { fields } = agent.as(runtime.types.view("Agent"));
if (typeof fields.score === "number") console.log(fields.score);
```

`types.get(type)` returns the resolved class mappings, common fields, default
status and profile-specific fields. Field value types are `string`, `number`,
`boolean`, `dateTime` and `uri`; `multiple` and `required` default to false.
Multiple values are unordered RDF values, not RDF lists. Duplicate values are
deduplicated. Dates accept valid `Date` objects or ISO date-times with a timezone
and at most millisecond precision. No string-to-number/boolean coercion occurs.

Custom profiles inherit common fields. Ordinary bindings can be overridden;
identity, runtime type selection and managed timestamps cannot. Registration
rejects overlapping predicates/aliases, unsafe names, invalid IRIs and conflicting
class mappings. Public fields such as `url` cannot collide with Soukai identity.
Registration is synchronous and runtime-local. Identical definitions are
idempotent; changed definitions invalidate compiled projections and old approvals.
Nothing is migrated on the Pod. Previously returned snapshots retain their binding
definitions; subsequent queries reinterpret cached RDF before matching.

Built-in `views.Task`, `views.Photo` and the other existing views stay synchronous
and keep their result shapes. Their selectors share the profile registry; computed
presentation fields remain view code. URI fields write forward facts only. Use
`graph.link()` when maintained inverse relationships are required.

## Input adapters and edits

Top-level conveniences and `facets` remain adapters to the field compiler. Do not
assign one logical field in more than one form, even with equal values:

```ts
await runtime.things.update(agent.uri, { fields: { score: 5, peers: [] } });
await runtime.things.update(agent.uri, { description: "Updated description" });
// Rejected: { title: "A", fields: { title: "A" } }
```

An undefined value means unchanged. Null removes an optional field; an empty array
clears a multiple-valued field. Unknown fields fail explicitly. Required fields
cannot be explicitly removed. Creation validates the complete managed profile;
editing foreign or incomplete RDF validates requested fields, without demanding
unrelated missing fields.

Arbitrary facts remain available through `properties`, `links`, `replaceProperties`,
`replaceLinks`, `deleteProperties` and `deleteLinks`. Typed and explicit RDF edits
must not overlap the same field or any of its aliases in one request. Explicit
raw-RDF operations are the escape hatch for unsupported or ambiguous encodings.
Raw facts are not synthesized from normalized facets or model metadata. Inferred
file titles/types remain in facets; they are not observations of RDF predicates.

## Native defaults; existing bindings remain intact

New Things assert their profile's primary RDF class and retain
`schema:additionalType` as a compatibility hint. They no longer rely on
`schema:Thing` plus a hint as their sole classification.

| Profile | Default class | Changed default field bindings |
| --- | --- | --- |
| Task | `ical:Vtodo` | title → `ical:summary`; description → `ical:description`; dueDate → `ical:due`; startDate → `ical:dtstart` |
| Note | `as:Note` | title → `as:name`; description → `as:summary` |
| Concept | `skos:Concept` | title → `skos:prefLabel` |
| Other built-ins | `types.get(type).primaryClassUri` | Existing bindings, with declarative native view selectors |

Changed bindings retain their legacy read aliases. Typed updates read the actual
writable RDF source, separately from the canonical subject URI. Existing bindings
win over native defaults. Absent fields use native defaults, except legacy generic
records retain their legacy defaults. External subjects, content aliases and
multi-Thing documents are supported.

Only selected predicates and permitted metadata subjects are patched. The runtime
never replaces an existing RDF document with model serialization. Unrelated
subjects, predicates, language tags, datatypes, blank-node structures and links
survive. Explicit replacement/removal is emitted even when a cached or requested
value appears unchanged.

Multiple aliases, multiple values of a scalar, language-tagged scalar bindings and
unsupported date/structured encodings are not silently collapsed. The Thing stays
readable; typed editing of the affected field fails. Inspect
`diagnostics.inspectThing(uri)` for field-binding/projection issues, and use exact
RDF operations to resolve ambiguity. Queries include aggregate degradation
diagnostics, not a public catalog-status filter or `Thing.recordStatus`.

Workflow status is not iCalendar status. Description is not document content.
Record timestamps are not publication, activity or other domain-event dates.
New records carry explicit, separate `crdt:Metadata` timestamps, frozen when the
write is planned. Existing timestamp encodings remain readable. Automatic updates
touch only the Thing's recognized record timestamp or one verified, same-source
metadata subject. Ambiguous/unsupported metadata is preserved and diagnosed.

Explicitly changing `type` reclassifies the Thing: recognized old primary-class
assertions and the runtime hint are replaced, unrelated classes/properties remain,
and exact type-index instance changes are planned. Other fields are not converted
to a different vocabulary. Mixed-class type-index registrations that cannot be
changed safely are rejected before mutation. Same-index changes use one PATCH.

## Async planning and version-four approvals

```ts
const creation = await runtime.writes.planCreate({ type: "Task", fields: { title: "Review" } });
const update = await runtime.writes.planUpdate(agent.uri, { fields: { score: 6 } });
const restored = JSON.parse(JSON.stringify(update));
const result = await runtime.writes.commit(restored);
```

Both forms of `planUpdate()` and `planCreate()` are asynchronous. New plan kinds,
including raw resource/container and graph plans, use version 4 and include their
effective runtime identity. Persisted v1/v2 plans are rejected before network
access. Unbound legacy contexts retain their existing version-three validation
path; explicitly bound contexts reject unbound version-three plans. Replan to gain
the current identity binding.

Plans contain resolved semantic input, profile fingerprints, canonical subject and
source identities, selected bindings, frozen timestamps, exact serialized changes
and payload hashes. `rdf.create` names one exact resource. Content bytes survive
JSON serialization, including binary input. Type-index classes, registration
subjects, index sources and validators are pinned during planning.

Commit checks envelope shape, URL guards, payload consistency, profile revision and
resolved source identity. Reviewed source/index reads must still match the approved
validator and source bytes. Commit never silently changes that validator, selects a
different index, or regenerates the approved effect. Hashes are consistency checks,
not signatures or authorization tokens: applications must protect stored approvals.

Ordinary and reviewed typed updates require a strong ETag or supported
Last-Modified validator by default. Explicit unversioned consent is possible:

```ts
await runtime.things.update(agent.uri, { fields: { score: 7 } }, { allowUnversioned: true });
const unversioned = await runtime.writes.planUpdate(agent.uri, { fields: { score: 8 } }, { allowUnversioned: true });
```

Such plans include a diagnostic; concurrent changes cannot be excluded. Strong
ETags are preferred over the coarser Last-Modified fallback. A registration without
a supported index validator is skipped by default, rather than written
unconditionally; explicitly unversioned reclassification can opt in.

## Content ownership and partial results

Content-backed creation is: conditional content PUT → conditional complete RDF PUT
→ pinned registration. Both creates use `If-None-Match: *`. Ownership metadata is
written only for content created by that operation. To reference an existing/shared
file, supply an explicit content link instead of asking to create its bytes; do not
supply `runtime:ownsContent` yourself.

Every successful network mutation is recorded before reconciliation or the next
operation. Outcomes distinguish completed, already-satisfied, skipped, failed and
pending work. A later failure may leave content or RDF in place; no automatic
rollback deletion occurs. Unavailable registration is skipped and diagnosed, not
reported as completed. Inspect `RuntimeWriteCommitError.outcomes` before deciding
what to replan. A reconciliation error can report completed mutations with later
operations pending; retrying the whole old plan is not a rollback strategy.

Semantic deletion remains subject-safe: delete the target subject, then proven
owned distinct content, then its instance registrations. Shared/legacy content and
neighboring subjects remain. Raw resource/container APIs retain their exact,
explicit meanings. Application layout/provisioning and reverse-link policy are not
expanded by this migration.

## Catalog and release qualification

IndexedDB stays on schema 2. Existing cached Things, statuses, membership and
completeness survive restart. Registration changes reinterpret cached facts without
remote reads or startup record rewrites. Missing historical metadata is recovered
on a later source refresh, not invented. Queries do not hydrate Soukai models or
convert JSON-LD; profile classes compile once per definition revision.

Run `npm run verify`, plus the minimum Node 22.12.0 and supported Node 22 packed
consumer checks. This engineering gate uses the application-owned JSON-LD 9
profile and covers baseline through C3 behavior, JSON-LD term preservation, strict
declarations, browser build, a single Soukai instance and a zero-finding isolated
production audit. Run `npm run verify:release` for the public gate; it completes
engineering verification before testing the ordinary packed and workspace audits.

The pinned upstream Soukai/Soukai Solid 0.7.1 chain still reaches JSON-LD 8 through
solid-utils and fails the production audit. The private prerelease works around
that chain through a root-consumer JSON-LD 9 override documented in
`PRIVATE_2_PRERELEASE.md`; npm library overrides do not propagate to applications.
Only a supported ordinary upstream tree can qualify final public 2.0. Do not call
the prerelease publicly production-qualified or publish while this gate fails.
Publishing requires separate authorization.

Upstream references: [Soukai interoperability](https://soukai.js.org/guide/advanced/interoperability.html),
[Solid models](https://soukai.js.org/guide/solid-protocol/solid-models.html),
[solid-utils manifest](https://github.com/NoelDeMartin/solid-utils/blob/main/package.json).
