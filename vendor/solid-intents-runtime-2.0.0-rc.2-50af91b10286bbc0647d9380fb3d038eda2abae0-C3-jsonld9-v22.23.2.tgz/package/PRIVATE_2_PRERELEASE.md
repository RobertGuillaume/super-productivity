# Adopt the private 2.0 prerelease

`@solid-intents/runtime@2.0.0-rc.2` is an unpublished engineering prerelease for
private applications. Install one immutable C3 tarball, verify its published
SHA-256, and keep the dependency override in the application root. The runtime
package does not contain an override, and npm does not propagate library overrides
to consuming applications.

## Application manifest

Vendor the qualified archive under a stable application path and replace the
placeholders with the exact source commit used by the artifact report:

```json
{
  "dependencies": {
    "@solid-intents/runtime": "file:vendor/solid-intents-runtime-2.0.0-rc.2-<commit>-C3-jsonld9-v22.23.2.tgz"
  },
  "overrides": {
    "@noeldemartin/solid-utils": {
      "jsonld": "9.0.0"
    }
  }
}
```

The qualified dependency profile is exact at its meaningful boundaries:

```text
@noeldemartin/solid-utils 0.6.1
jsonld 9.0.0
@digitalbazaar/http-client 4.4.x
undici >=6.28.0 <7
```

Do not add Soukai, JSON-LD, HTTP-client, or Undici as duplicate direct application
dependencies merely to influence resolution. The root override is the one explicit
temporary policy.

## Adoption checklist

1. Copy the selected `.tgz`, its `.sha256`, and its machine-readable report into
   the application's vendor or release-input directory.
2. Verify the archive before installation. On macOS, run
   `shasum -a 256 -c <archive>.sha256`; use the platform's equivalent SHA-256
   checker elsewhere.
3. Add the exact file dependency and root override shown above. Run `npm install`
   with the application's supported npm 10 release and commit the resulting
   lockfile.
4. Run `npm ls @noeldemartin/solid-utils jsonld @digitalbazaar/http-client undici`
   and compare the resolved chain with the artifact report. A different JSON-LD,
   HTTP-client, or Undici version is outside this qualification.
5. Run the application's build, type checks, unit and integration tests, browser
   build where applicable, and `npm audit --omit=dev`.
6. Record unrelated application audit findings separately. The runtime profile is
   qualified only when its isolated production audit is zero; it does not assert
   that every dependency in a larger application is clean.
7. Retain the source commit, archive digest, Node/npm versions, dependency profile,
   resolved versions, and test results in the application's handoff record.

Workspace-linked development and tarball-based installations use the same root
override and resolved-chain checks. Use the tarball for a reproducible deployment
or handoff because a workspace link does not identify immutable package bytes.

## Existing application overrides

Cairn currently pins `@digitalbazaar/http-client@4.3.0` directly. Replace that
entry with the JSON-LD-level override above. Do not retain both overrides: the
qualified chain intentionally allows HTTP-client 4.4.x and requires its patched
Undici 6.28.x resolution.

If another application already has overrides, preserve unrelated entries and add
the nested `@noeldemartin/solid-utils` rule. Investigate any conflict rather than
loosening the exact JSON-LD version or forcing a second HTTP-client version.

## Status and removal

This profile is suitable for the five private applications after their own gates
pass. It does not make the prerelease a public production release. The ordinary
unoverridden runtime tree remains the `npm run verify:release` gate, and the
package's `prepublishOnly` script enforces that gate before any npm publication.

Remove the application override when the final runtime adopts and qualifies a
supported upstream dependency release. Regenerate the application lockfile and run
the same resolved-chain, behavior, browser, and production-audit checks before
shipping that change.
